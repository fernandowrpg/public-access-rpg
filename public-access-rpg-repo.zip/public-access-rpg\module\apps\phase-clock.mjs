import { PA, SYSTEM_ID } from "../config.mjs";

const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;
const L = key => game.i18n.localize(key);

/** Clockwise order around the dial: Dawn (9 o'clock) → Day (12) → Dusk (3) → Night (6). */
const DIAL = [
  { id: "dawn", angle: 270, icon: "fa-sun-plant-wilt", color: "#ffb38a" },
  { id: "day", angle: 0, icon: "fa-sun", color: "#ffd23f" },
  { id: "dusk", angle: 90, icon: "fa-cloud-sun", color: "#ff4fa3" },
  { id: "night", angle: 180, icon: "fa-moon", color: "#36e2e6" }
];

const C = 100;          // dial center (viewBox 0 0 200 200)
const R_OUT = 94;
const R_IN = 58;

function polar(r, deg) {
  const rad = (deg - 90) * Math.PI / 180;
  return [C + r * Math.cos(rad), C + r * Math.sin(rad)];
}

/** SVG path of a ring segment spanning 90° centered on `angle`. */
function segmentPath(angle) {
  const a0 = angle - 44, a1 = angle + 44;
  const [x0, y0] = polar(R_OUT, a0), [x1, y1] = polar(R_OUT, a1);
  const [x2, y2] = polar(R_IN, a1), [x3, y3] = polar(R_IN, a0);
  const f = n => n.toFixed(2);
  return `M${f(x0)},${f(y0)} A${R_OUT},${R_OUT} 0 0 1 ${f(x1)},${f(y1)} L${f(x2)},${f(y2)} A${R_IN},${R_IN} 0 0 0 ${f(x3)},${f(y3)} Z`;
}

/**
 * Floating "phase clock": shows everyone the current phase of play; the GM changes it right here.
 */
export class PhaseClock extends HandlebarsApplicationMixin(ApplicationV2) {
  /** Cumulative hand angle so the hand always turns forward (Night → Dawn doesn't spin backwards). */
  #handAngle = null;

  static DEFAULT_OPTIONS = {
    id: "pa-phase-clock",
    classes: ["public-access", "pa-phase-clock"],
    window: { title: "PA.Clock.title", icon: "fa-solid fa-clock", minimizable: true, resizable: false },
    position: { width: 240, height: "auto" },
    actions: {
      setPhase: PhaseClock.#onSetPhase,
      stepPhase: PhaseClock.#onStepPhase,
      tapes: PhaseClock.#onTapes
    }
  };

  static PARTS = {
    clock: { template: `systems/${SYSTEM_ID}/templates/apps/phase-clock.hbs` }
  };

  static #instance = null;

  /** The shared instance (one clock per client). */
  static get instance() {
    return this.#instance ??= new PhaseClock();
  }

  static async toggle(force) {
    const app = this.instance;
    const show = force ?? !app.rendered;
    if (show) await app.render({ force: true });
    else await app.close();
    await game.settings.set(SYSTEM_ID, "phaseClockVisible", show);
  }

  /** Re-render when the phase or tape count changes (called from the settings' onChange). */
  static refresh() {
    if (this.#instance?.rendered) this.#instance.render();
  }

  _initializeApplicationOptions(options) {
    options = super._initializeApplicationOptions(options);
    const saved = game.settings.get(SYSTEM_ID, "phaseClockPosition");
    if (saved?.left !== undefined) Object.assign(options.position, { left: saved.left, top: saved.top });
    else Object.assign(options.position, { left: 120, top: 80 });
    return options;
  }

  async _prepareContext() {
    const phase = game.settings.get(SYSTEM_ID, "phase");
    const current = DIAL.find(d => d.id === phase) ?? DIAL[1];
    this._handFrom = this.#handAngle ?? current.angle;
    if (this.#handAngle === null) this.#handAngle = current.angle;
    else {
      const from = ((this.#handAngle % 360) + 360) % 360;
      const delta = ((current.angle - from) % 360 + 360) % 360;
      this.#handAngle += delta;
    }
    const isGM = game.user.isGM;
    return {
      isGM,
      phase,
      phaseLabel: L(PA.phases[phase]),
      hint: L(`PA.Clock.hint.${phase}`),
      color: current.color,
      handAngle: this.#handAngle,
      tapes: game.settings.get(SYSTEM_ID, "tapesWatched"),
      segments: DIAL.map(d => {
        const [ix, iy] = polar((R_OUT + R_IN) / 2, d.angle);
        return {
          ...d,
          label: L(PA.phases[d.id]),
          path: segmentPath(d.angle),
          active: d.id === phase,
          // Icon position as a percentage of the dial box.
          left: (ix / 2).toFixed(1),
          top: (iy / 2).toFixed(1)
        };
      })
    };
  }

  /** Animate the hand from the previous phase to the current one. */
  _onRender(context, options) {
    super._onRender(context, options);
    const hand = this.element.querySelector(".pa-clock-hand");
    if (!hand) return;
    hand.style.transition = "none";
    hand.style.transform = `rotate(${this._handFrom}deg)`;
    requestAnimationFrame(() => requestAnimationFrame(() => {
      hand.style.transition = "";
      hand.style.transform = `rotate(${context.handAngle}deg)`;
    }));
  }

  setPosition(position) {
    const pos = super.setPosition(position);
    if (pos && this.rendered) {
      clearTimeout(this._saveTimer);
      this._saveTimer = setTimeout(() => {
        game.settings.set(SYSTEM_ID, "phaseClockPosition", { left: this.position.left, top: this.position.top });
      }, 400);
    }
    return pos;
  }

  async close(options) {
    // Closing from the window header remembers that this client hid the clock.
    if (!options?.paToggle) game.settings.set(SYSTEM_ID, "phaseClockVisible", false);
    return super.close(options);
  }

  static async #onSetPhase(event, target) {
    if (!game.user.isGM) return;
    const phase = target.dataset.phase;
    if (phase && phase !== game.settings.get(SYSTEM_ID, "phase")) await game.settings.set(SYSTEM_ID, "phase", phase);
  }

  static async #onStepPhase(event, target) {
    if (!game.user.isGM) return;
    const order = DIAL.map(d => d.id);
    const i = order.indexOf(game.settings.get(SYSTEM_ID, "phase"));
    const step = Number(target.dataset.step) || 1;
    await game.settings.set(SYSTEM_ID, "phase", order[(i + step + order.length) % order.length]);
  }

  static async #onTapes(event, target) {
    if (!game.user.isGM) return;
    const value = Math.max(0, game.settings.get(SYSTEM_ID, "tapesWatched") + Number(target.dataset.step));
    await game.settings.set(SYSTEM_ID, "tapesWatched", value);
  }
}

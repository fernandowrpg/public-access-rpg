import { PA, SYSTEM_ID } from "../config.mjs";
import { getRawTemplate, defaultRawTemplate } from "../defaults.mjs";

const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;
const L = key => game.i18n.localize(key);

/** GM menu to define the Dawn Questions, Keys, Advancements and starting abilities new Latchkeys get. */
export class TemplateConfig extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "pa-template-config",
    tag: "form",
    classes: ["public-access", "pa-template-config"],
    window: { title: "PA.Template.menuTitle", icon: "fa-solid fa-id-card", resizable: true },
    position: { width: 720, height: 820 },
    form: { handler: TemplateConfig.#onSubmit, closeOnSubmit: true },
    actions: { reset: TemplateConfig.#onReset, applyAll: TemplateConfig.#onApplyAll }
  };

  static PARTS = {
    form: { template: `systems/${SYSTEM_ID}/templates/apps/template-config.hbs`, scrollable: [""] }
  };

  async _prepareContext() {
    const raw = this._raw ?? getRawTemplate();
    return {
      raw,
      abilities: Object.entries(PA.abilities).map(([k, label]) => ({ key: k, label: L(label), value: raw.abilities[k] ?? 0 }))
    };
  }

  static async #onSubmit(event, form, formData) {
    const data = foundry.utils.expandObject(formData.object);
    const abilities = Object.fromEntries(Object.keys(PA.abilities).map(k => [
      k, Math.clamp(Number(data.abilities?.[k]) || 0, PA.abilityMin, PA.abilityMax)
    ]));
    await game.settings.set(SYSTEM_ID, "sheetTemplate", {
      dawn: data.dawn ?? "", child: data.child ?? "", desolation: data.desolation ?? "",
      advancements: data.advancements ?? "", abilities
    });
    ui.notifications.info(L("PA.Template.saved"));
  }

  static #onReset() {
    this._raw = defaultRawTemplate();
    this.render();
  }

  /** Overwrite the lists of every Latchkey (after confirmation). */
  static async #onApplyAll() {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: L("PA.Template.applyAll") },
      content: `<p>${L("PA.Template.applyAllConfirm")}</p>`,
      rejectClose: false
    });
    if (!ok) return;
    await this.submit();
    const { getSheetTemplate } = await import("../defaults.mjs");
    const tpl = getSheetTemplate();
    for (const actor of game.actors.filter(a => a.type === "latchkey")) {
      await actor.update({
        "system.dawnQuestions": tpl.dawnQuestions,
        "system.keysChild": tpl.keysChild,
        "system.keysDesolation": tpl.keysDesolation,
        "system.advancements": tpl.advancements
      });
    }
    ui.notifications.info(L("PA.Template.appliedAll"));
  }
}

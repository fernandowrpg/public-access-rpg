/**
 * Small shims so the system runs on Foundry v13 and v14.
 */

/**
 * Apply the user's current chat visibility to message data.
 * v14 replaced core.rollMode / ChatMessage.applyRollMode with core.messageMode / ChatMessage.applyMode.
 */
export function applyMessageMode(data) {
  const hasMessageMode = game.settings.settings.has("core.messageMode");
  if (hasMessageMode && typeof ChatMessage.applyMode === "function") {
    return ChatMessage.applyMode(data, game.settings.get("core", "messageMode"));
  }
  return ChatMessage.applyRollMode(data, game.settings.get("core", "rollMode"));
}

/**
 * Create a chat card. In v14 the "In Character" mode turns messages with a speaker into token
 * speech bubbles; system cards are never speech, so bubbles are disabled (ignored by v13).
 */
export function createChat(data, options = {}) {
  return ChatMessage.create(data, { chatBubble: false, ...options });
}

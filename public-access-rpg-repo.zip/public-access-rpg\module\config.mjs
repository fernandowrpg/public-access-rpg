export const SYSTEM_ID = "public-access";

export const PA = {
  abilities: {
    vitality: "PA.Ability.vitality",
    composure: "PA.Ability.composure",
    reason: "PA.Ability.reason",
    presence: "PA.Ability.presence",
    sensitivity: "PA.Ability.sensitivity"
  },

  /** Success tiers, from worst to best. Turning a Key moves one step up. */
  tiers: ["miss", "partial", "strong", "critical"],
  tierLabels: {
    miss: "PA.Tier.miss",
    partial: "PA.Tier.partial",
    strong: "PA.Tier.strong",
    critical: "PA.Tier.critical"
  },

  moveTypes: {
    basic: "PA.MoveType.basic",
    latchkey: "PA.MoveType.latchkey",
    custom: "PA.MoveType.custom"
  },

  rollTypes: {
    choose: "PA.RollType.choose",
    ability: "PA.RollType.ability",
    flat: "PA.RollType.flat",
    question: "PA.RollType.question",
    none: "PA.RollType.none"
  },

  forceModes: {
    none: "PA.ForceMode.none",
    advantage: "PA.ForceMode.advantage",
    disadvantage: "PA.ForceMode.disadvantage"
  },

  /** Special automation hooks a basic move can carry. */
  moveKeys: {
    "": "PA.MoveKey.none",
    day: "PA.MoveKey.day",
    night: "PA.MoveKey.night",
    meddling: "PA.MoveKey.meddling",
    nostalgic: "PA.MoveKey.nostalgic",
    question: "PA.MoveKey.question"
  },

  dawnKinds: {
    always: "PA.DawnKind.always",
    unlockable: "PA.DawnKind.unlockable",
    elective: "PA.DawnKind.elective"
  },

  keyEffects: {
    none: "PA.KeyEffect.none",
    unlockDawn: "PA.KeyEffect.unlockDawn",
    abilityDown: "PA.KeyEffect.abilityDown",
    retire: "PA.KeyEffect.retire"
  },

  /** Which move a companion ("hook") Latchkey move can be applied to from the roll dialog. */
  hookMoves: {
    "": "PA.Hook.none",
    any: "PA.Hook.any",
    day: "PA.MoveKey.day",
    night: "PA.MoveKey.night",
    meddling: "PA.MoveKey.meddling",
    nostalgic: "PA.MoveKey.nostalgic"
  },
  hookEffects: {
    note: "PA.HookEffect.note",
    advantage: "PA.HookEffect.advantage",
    critical: "PA.HookEffect.critical"
  },
  usesReset: {
    none: "PA.UsesReset.none",
    session: "PA.UsesReset.session",
    day: "PA.UsesReset.day"
  },

  advancementEffects: {
    none: "PA.AdvEffect.none",
    ability: "PA.AdvEffect.ability",
    move: "PA.AdvEffect.move"
  },

  phases: {
    dawn: "PA.Phase.dawn",
    day: "PA.Phase.day",
    dusk: "PA.Phase.dusk",
    night: "PA.Phase.night"
  },

  maxConditions: 3,
  maxXP: 6,
  maxElectiveDawn: 2,
  abilityMin: -3,
  abilityMax: 3
};

/** Translate every value of a label map. */
export function localizeMap(map) {
  return Object.fromEntries(Object.entries(map).map(([k, v]) => [k, game.i18n.localize(v)]));
}

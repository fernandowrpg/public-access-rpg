import { PA, SYSTEM_ID } from "../config.mjs";

/** Apply a newly added move's ability boost and Corner of the House items. */
async function applyMoveGrant(actor, item) {
  const sys = item.system;
  const L = k => game.i18n.localize(k);
  const F = (k, d) => game.i18n.format(k, d);
  const notes = [];

  if (sys.moveType === "latchkey") {
    const clash = game.actors.find(a => a !== actor && a.type === "latchkey"
      && a.items.some(i => i.type === "move" && i.system.moveType === "latchkey" && i.name === item.name));
    if (clash) ui.notifications.warn(F("PA.Move.duplicate", { name: item.name, other: clash.name }));
  }

  const key = sys.abilityBoost.ability;
  if (key && sys.abilityBoost.value) {
    const before = actor.system.abilities[key];
    const after = Math.clamp(before + sys.abilityBoost.value, PA.abilityMin, PA.abilityMax);
    if (after !== before) {
      await actor.update({ [`system.abilities.${key}`]: after });
      notes.push(F("PA.Adv.abilityUp", { ability: L(PA.abilities[key]), value: after }));
    }
    await item.setFlag(SYSTEM_ID, "boostApplied", after - before);
  }

  const lines = sys.grantsItems.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  if (lines.length) {
    await actor.createEmbeddedDocuments("Item", lines.map(line => {
      const reusable = line.startsWith("*");
      return { name: reusable ? line.slice(1).trim() : line, type: "gear", img: "icons/svg/item-bag.svg", system: { reusable } };
    }));
    notes.push(F("PA.Move.itemsAdded", { items: lines.map(l => l.replace(/^\*/, "").trim()).join(", ") }));
  }
  if (notes.length) ui.notifications.info(`${item.name}: ${notes.join(" · ")}`);
}

const { fields } = foundry.data;

export class MoveData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const html = () => new fields.HTMLField({ initial: "" });
    return {
      moveType: new fields.StringField({ initial: "latchkey", choices: Object.keys(PA.moveTypes) }),
      /** Automation hook for basic moves (day, night, meddling, nostalgic, question). */
      key: new fields.StringField({ initial: "", blank: true, choices: Object.keys(PA.moveKeys) }),
      rollType: new fields.StringField({ initial: "choose", choices: Object.keys(PA.rollTypes) }),
      ability: new fields.StringField({ initial: "reason", choices: Object.keys(PA.abilities) }),
      bonus: new fields.NumberField({ integer: true, initial: 0 }),
      forceMode: new fields.StringField({ initial: "none", choices: Object.keys(PA.forceModes) }),
      allowAdvDis: new fields.BooleanField({ initial: true }),
      allowKeys: new fields.BooleanField({ initial: true }),
      /** Question asked in the roll dialog (e.g. "What do you fear will happen?"). */
      prompt: new fields.StringField({ initial: "", blank: true }),
      trigger: new fields.StringField({ initial: "", blank: true }),
      description: html(),
      results: new fields.SchemaField({
        miss: html(), partial: html(), strong: html(), critical: html()
      }),
      xpOnMiss: new fields.BooleanField({ initial: false }),
      uses: new fields.SchemaField({
        value: new fields.NumberField({ integer: true, min: 0, initial: 0 }),
        max: new fields.NumberField({ integer: true, min: 0, initial: 0 }),
        reset: new fields.StringField({ initial: "none", choices: Object.keys(PA.usesReset) })
      }),

      /* ---- Latchkey move automation ---- */
      /** Permanent ability increase applied when the move is added to a Latchkey (reverted on removal). */
      abilityBoost: new fields.SchemaField({
        ability: new fields.StringField({ initial: "", blank: true, choices: ["", ...Object.keys(PA.abilities)] }),
        value: new fields.NumberField({ integer: true, initial: 0 })
      }),
      /** Items added to Your Corner of the House when the move is taken, one per line ("*" = never marked). */
      grantsItems: new fields.StringField({ initial: "", blank: true }),
      /** Companion move: offered as an option in another move's roll dialog. */
      hook: new fields.SchemaField({
        move: new fields.StringField({ initial: "", blank: true, choices: Object.keys(PA.hookMoves) }),
        effect: new fields.StringField({ initial: "note", choices: Object.keys(PA.hookEffects) }),
        note: new fields.StringField({ initial: "", blank: true })
      }),
      /** Using the move asks for an item and adds it to Your Corner of the House. */
      addsGear: new fields.BooleanField({ initial: false }),
      /** Listed in the "new session" reminder. */
      sessionReminder: new fields.BooleanField({ initial: false }),
      /** Title of a Key of Desolation this move lets you mark whenever you want (out of order). */
      keyAnytime: new fields.StringField({ initial: "", blank: true }),
      /** Title of a Key of Desolation whose ability penalty this move ignores. */
      protectsKey: new fields.StringField({ initial: "", blank: true })
    };
  }

  get isHook() {
    return !!this.hook.move;
  }

  get usesLabel() {
    if (!this.hasUses) return "";
    const per = this.uses.reset === "none" ? "" : game.i18n.localize(`PA.UsesReset.short.${this.uses.reset}`);
    return `${this.uses.max}${per}`;
  }

  /* ---- Lifecycle: apply the move's permanent effects to its Latchkey ---- */

  _onCreate(data, options, userId) {
    super._onCreate(data, options, userId);
    if (userId !== game.user.id || options.paSkipEffects) return;
    const actor = this.parent.actor;
    if (actor?.type !== "latchkey") return;
    applyMoveGrant(actor, this.parent);
  }

  _onDelete(options, userId) {
    super._onDelete(options, userId);
    if (userId !== game.user.id) return;
    const actor = this.parent.actor;
    const applied = this.parent.getFlag(SYSTEM_ID, "boostApplied");
    if (actor?.type !== "latchkey" || !applied || !this.abilityBoost.ability) return;
    const key = this.abilityBoost.ability;
    actor.update({ [`system.abilities.${key}`]: Math.max(PA.abilityMin, actor.system.abilities[key] - applied) });
  }

  get isRollable() {
    return this.rollType !== "none" && this.key !== "nostalgic";
  }

  get hasUses() {
    return this.uses.max > 0;
  }

  /** Result text for a tier; 12+ falls back to the 10+ text when empty. */
  resultFor(tier) {
    if (tier === "critical") return this.results.critical || this.results.strong;
    return this.results[tier] ?? "";
  }
}

export class GearData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      marked: new fields.BooleanField({ initial: false }),
      /** e.g. the blank Odyssey tape: marking it before a roll gives an automatic 12+. */
      autoCritical: new fields.BooleanField({ initial: false }),
      /** Grants advantage without being marked (e.g. the dog from Say Hello to My Little Friend). */
      reusable: new fields.BooleanField({ initial: false }),
      description: new fields.HTMLField({ initial: "" })
    };
  }
}

import { PA } from "../config.mjs";
import { getSheetTemplate, buildBasicMoves } from "../defaults.mjs";

const { fields } = foundry.data;

function abilityField() {
  return new fields.NumberField({
    required: true, nullable: false, integer: true, initial: 0,
    min: PA.abilityMin, max: PA.abilityMax
  });
}

export class LatchkeyData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    const str = () => new fields.StringField({ required: true, blank: true, initial: "" });
    const bool = (initial = false) => new fields.BooleanField({ initial });

    return {
      firstName: str(),
      surname: str(),
      style: str(),
      takesYouBack: new fields.SchemaField({ one: str(), two: str(), three: str() }),
      abilities: new fields.SchemaField(
        Object.fromEntries(Object.keys(PA.abilities).map(k => [k, abilityField()]))
      ),
      conditions: new fields.SchemaField({ c1: str(), c2: str(), c3: str() }),
      xp: new fields.NumberField({ required: true, integer: true, min: 0, max: PA.maxXP, initial: 0 }),

      dawnQuestions: new fields.ArrayField(new fields.SchemaField({
        text: str(),
        kind: new fields.StringField({ initial: "elective", choices: Object.keys(PA.dawnKinds) }),
        marked: bool(),
        unlocked: bool(true)
      })),

      keysChild: new fields.ArrayField(new fields.SchemaField({
        title: str(), text: str(), marked: bool(), resolved: bool()
      })),

      keysDesolation: new fields.ArrayField(new fields.SchemaField({
        title: str(), text: str(), marked: bool(), resolved: bool(),
        effect: new fields.StringField({ initial: "none", choices: Object.keys(PA.keyEffects) }),
        ability: new fields.StringField({ initial: "reason", choices: Object.keys(PA.abilities) })
      })),

      /** Mystery-specific Keys this Latchkey has turned (log). */
      mysteryKeys: new fields.ArrayField(new fields.SchemaField({
        title: str(), text: str(), resolved: bool()
      })),

      advancements: new fields.ArrayField(new fields.SchemaField({
        text: str(), marked: bool(),
        effect: new fields.StringField({ initial: "none", choices: Object.keys(PA.advancementEffects) })
      })),

      retired: bool(),
      /** "At the beginning of the game, add 1 to a single ability." Existing characters count as done. */
      startingBonus: bool(true),
      biography: new fields.HTMLField({ initial: "" }),
      notes: new fields.HTMLField({ initial: "" })
    };
  }

  /** Conditions as a compact list of non-empty strings. */
  get conditionList() {
    return Object.values(this.conditions).map(c => c.trim()).filter(Boolean);
  }

  get fullName() {
    return [this.firstName, this.surname].filter(Boolean).join(" ");
  }

  get canAdvance() {
    return this.xp >= PA.maxXP && this.advancements.some(a => !a.marked);
  }

  get unresolvedKeys() {
    const all = [...this.keysChild, ...this.keysDesolation].filter(k => k.marked && !k.resolved);
    return all.concat(this.mysteryKeys.filter(k => !k.resolved));
  }

  async _preCreate(data, options, user) {
    const allowed = await super._preCreate(data, options, user);
    if (allowed === false) return false;

    const tpl = getSheetTemplate();
    const update = { prototypeToken: { actorLink: true, disposition: CONST.TOKEN_DISPOSITIONS.FRIENDLY } };
    if (sys.startingBonus === undefined) update["system.startingBonus"] = false;
    const sys = data.system ?? {};
    if (!sys.dawnQuestions?.length) update["system.dawnQuestions"] = tpl.dawnQuestions;
    if (!sys.keysChild?.length) update["system.keysChild"] = tpl.keysChild;
    if (!sys.keysDesolation?.length) update["system.keysDesolation"] = tpl.keysDesolation;
    if (!sys.advancements?.length) update["system.advancements"] = tpl.advancements;
    if (!sys.abilities) update["system.abilities"] = tpl.abilities;

    const items = data.items ?? [];
    if (!items.some(i => i.type === "move" && i.system?.moveType === "basic")) {
      update.items = items.concat(buildBasicMoves());
    }
    this.parent.updateSource(update);
  }
}

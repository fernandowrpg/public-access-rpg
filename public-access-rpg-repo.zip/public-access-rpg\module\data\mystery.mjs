const { fields } = foundry.data;

const str = () => new fields.StringField({ required: true, blank: true, initial: "" });
const bool = (initial = false) => new fields.BooleanField({ initial });
const list = schema => new fields.ArrayField(new fields.SchemaField(schema));

/** Blank entries for each list on the mystery sheet (used by "Add"). */
export const MYSTERY_LISTS = {
  questions: () => ({ text: "", complexity: 6, opportunity: "", answered: false, result: "" }),
  moments: () => ({ text: "", used: false }),
  dangers: () => ({ name: "", text: "", rule: "" }),
  locations: () => ({ name: "", description: "", paint: "", rule: "", visited: false }),
  sideCharacters: () => ({ name: "", role: "", details: "", description: "", quote: "", hidden: false, met: false }),
  clues: () => ({ text: "", found: false, foundBy: "" }),
  rewards: () => ({ text: "", gear: "", claimedBy: "" })
};

export const MYSTERY_STATUS = {
  inactive: "PA.Mystery.status.inactive",
  active: "PA.Mystery.status.active",
  resolved: "PA.Mystery.status.resolved"
};

export class MysteryData extends foundry.abstract.TypeDataModel {
  static defineSchema() {
    return {
      status: new fields.StringField({ initial: "inactive", choices: Object.keys(MYSTERY_STATUS) }),
      presentation: new fields.HTMLField({ initial: "" }),
      /** Question posed to one Latchkey when presenting the mystery. */
      hook: str(),

      questions: list({
        text: str(),
        complexity: new fields.NumberField({ integer: true, min: 0, initial: 6 }),
        opportunity: str(),
        answered: bool(),
        result: str()
      }),

      key: new fields.SchemaField({ title: str(), text: str(), used: bool(), usedBy: str() }),
      moments: list({ text: str(), used: bool() }),

      threat: new fields.SchemaField({
        name: str(),
        description: new fields.HTMLField({ initial: "" }),
        ifIgnored: new fields.HTMLField({ initial: "" })
      }),

      dangers: list({ name: str(), text: str(), rule: str() }),
      locations: list({ name: str(), description: str(), paint: str(), rule: str(), visited: bool() }),
      sideCharacters: list({
        name: str(), role: str(), details: str(), description: str(), quote: str(),
        /** Only enters play later (e.g. Elliott Rappaport). */
        hidden: bool(),
        met: bool()
      }),
      clues: list({ text: str(), found: bool(), foundBy: str() }),
      /** gear: "" = no item, "?" = ask for the item name, otherwise that item name is added to the claimer's Corner. */
      rewards: list({ text: str(), gear: str(), claimedBy: str() }),
      notes: new fields.HTMLField({ initial: "" })
    };
  }

  get cluesFound() {
    return this.clues.filter(c => c.found).length;
  }

  /** Public summary that players can read (they can't see the mystery actor itself). */
  get summary() {
    return {
      uuid: this.parent.uuid,
      name: this.parent.name,
      cluesFound: this.cluesFound,
      key: { ...this.key },
      questions: this.questions.map((q, index) => ({ index, text: q.text, complexity: q.complexity, answered: q.answered }))
    };
  }
}

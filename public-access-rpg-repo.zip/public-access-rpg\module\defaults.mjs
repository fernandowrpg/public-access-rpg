import { PA, SYSTEM_ID } from "./config.mjs";

/* -------------------------------------------------------------------------- */
/*  Character sheet template (Dawn Questions, Keys, Advancements)             */
/* -------------------------------------------------------------------------- */

/**
 * Raw template text as edited in the "Latchkey Template" settings menu.
 * Falls back to the localized defaults when the GM hasn't saved one.
 */
export function getRawTemplate() {
  const saved = game.settings.get(SYSTEM_ID, "sheetTemplate") ?? {};
  const fallback = defaultRawTemplate();
  return {
    dawn: saved.dawn ?? fallback.dawn,
    child: saved.child ?? fallback.child,
    desolation: saved.desolation ?? fallback.desolation,
    advancements: saved.advancements ?? fallback.advancements,
    abilities: foundry.utils.mergeObject(fallback.abilities, saved.abilities ?? {}, { inplace: false })
  };
}

export function defaultRawTemplate() {
  const t = key => game.i18n.localize(`PA.Template.Default.${key}`);
  return {
    dawn: t("dawn"),
    child: t("child"),
    desolation: t("desolation"),
    advancements: t("advancements"),
    abilities: Object.fromEntries(Object.keys(PA.abilities).map(k => [k, 0]))
  };
}

const lines = text => (text ?? "").split(/\r?\n/).map(l => l.trim()).filter(Boolean);

function extractTag(line, allowed) {
  const match = line.match(/\[([\w-]+)\]\s*$/);
  if (!match) return { line, tag: null };
  const tag = allowed[match[1].toLowerCase()] ?? null;
  return { line: line.slice(0, match.index).trim(), tag };
}

function splitTitle(line) {
  const idx = line.indexOf("::");
  if (idx < 0) return { title: line, text: "" };
  return { title: line.slice(0, idx).trim(), text: line.slice(idx + 2).trim() };
}

export function parseDawn(text) {
  return lines(text).map(line => {
    if (line.startsWith("!")) return { text: line.slice(1).trim(), kind: "always", marked: true, unlocked: true };
    if (line.startsWith("?")) return { text: line.slice(1).trim(), kind: "unlockable", marked: false, unlocked: false };
    return { text: line, kind: "elective", marked: false, unlocked: true };
  });
}

export function parseKeys(text, withEffects = false) {
  const tags = { "unlock-dawn": "unlockDawn", unlock: "unlockDawn", retire: "retire" };
  return lines(text).map(raw => {
    let line = raw, tag = null, ability = "reason";
    if (withEffects) {
      // [reduce:ability] lowers that ability by 1 when the Key is marked.
      const reduce = raw.match(/\[reduce:(\w+)\]\s*$/i);
      if (reduce && PA.abilities[reduce[1].toLowerCase()]) {
        line = raw.slice(0, reduce.index).trim();
        tag = "abilityDown";
        ability = reduce[1].toLowerCase();
      } else ({ line, tag } = extractTag(raw, tags));
    }
    const entry = { ...splitTitle(line), marked: false, resolved: false };
    if (withEffects) Object.assign(entry, { effect: tag ?? "none", ability });
    return entry;
  });
}

export function parseAdvancements(text) {
  const tags = { ability: "ability", move: "move" };
  return lines(text).map(raw => {
    const { line, tag } = extractTag(raw, tags);
    return { text: line, marked: false, effect: tag ?? "none" };
  });
}

export function getSheetTemplate() {
  const raw = getRawTemplate();
  return {
    dawnQuestions: parseDawn(raw.dawn),
    keysChild: parseKeys(raw.child),
    keysDesolation: parseKeys(raw.desolation, true),
    advancements: parseAdvancements(raw.advancements),
    abilities: raw.abilities
  };
}

/* -------------------------------------------------------------------------- */
/*  Basic moves                                                               */
/* -------------------------------------------------------------------------- */

const BASIC_MOVES = [
  { key: "day", rollType: "choose", icon: "icons/svg/sun.svg" },
  { key: "night", rollType: "choose", icon: "icons/svg/sleep.svg" },
  { key: "meddling", rollType: "choose", icon: "icons/svg/eye.svg" },
  { key: "nostalgic", rollType: "none", icon: "icons/svg/heal.svg" },
  { key: "question", rollType: "question", icon: "icons/svg/book.svg", allowAdvDis: false }
];

export function buildBasicMoves() {
  const L = (key, sub) => {
    const id = `PA.BasicMove.${key}.${sub}`;
    return game.i18n.has(id) ? game.i18n.localize(id) : "";
  };
  // Texts the Keeper imported from the rulebook replace the built-in summaries.
  const overrides = game.settings.get(SYSTEM_ID, "basicMoveTexts") ?? {};
  return BASIC_MOVES.map((m, i) => foundry.utils.mergeObject({
    name: L(m.key, "name"),
    type: "move",
    img: m.icon,
    sort: (i + 1) * 100,
    system: {
      moveType: "basic",
      key: m.key,
      rollType: m.rollType,
      allowAdvDis: m.allowAdvDis ?? true,
      allowKeys: true,
      prompt: L(m.key, "prompt"),
      trigger: L(m.key, "trigger"),
      description: L(m.key, "description"),
      results: {
        miss: L(m.key, "miss"),
        partial: L(m.key, "partial"),
        strong: L(m.key, "strong"),
        critical: L(m.key, "critical")
      }
    }
  }, { system: overrides[m.key] ?? {} }, { inplace: false }));
}

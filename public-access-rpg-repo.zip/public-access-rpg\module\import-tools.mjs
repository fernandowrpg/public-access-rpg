import { SYSTEM_ID } from "./config.mjs";
import { parseMove, parseMystery, segmentByNames, norm, escapeHTML } from "./importer.mjs";
import { ensureKeeperPack, saveToKeeperPack } from "./packs.mjs";
import { MYSTERY_LISTS } from "./data/mystery.mjs";

const { DialogV2 } = foundry.applications.api;
const L = key => game.i18n.localize(key);
const F = (key, data) => game.i18n.format(key, data);

/** English names of the basic moves as printed in the rulebook, plus the localized ones. */
const BASIC_NAMES = {
  day: ["The Day Move", "Day Move"],
  night: ["The Night Move", "Night Move"],
  meddling: ["The Meddling Move", "Meddling Move"],
  nostalgic: ["The Nostalgic Move", "Nostalgic Move"],
  question: ["Answer a Question"]
};
const basicNames = key => [...new Set([...BASIC_NAMES[key], L(`PA.BasicMove.${key}.name`)])];

/* -------------------------------------------------------------------------- */
/*  Shared dialog                                                             */
/* -------------------------------------------------------------------------- */

async function pasteDialog({ title, hint, extra = "" }) {
  const content = `<div class="pa-import">
    <p class="pa-hint">${hint}</p>
    ${extra}
    <textarea name="text" rows="18" placeholder="${escapeHTML(L("PA.Import.placeholder"))}"></textarea>
    <p class="pa-hint">${L("PA.Import.privacy")}</p>
  </div>`;
  return DialogV2.wait({
    window: { title, icon: "fa-solid fa-file-import", resizable: true },
    classes: ["public-access", "pa-dialog", "pa-import-dialog"],
    position: { width: 640 },
    content,
    rejectClose: false,
    buttons: [
      { action: "ok", label: L("PA.Import.apply"), icon: "fa-solid fa-file-import", default: true,
        callback: (ev, btn) => new foundry.applications.ux.FormDataExtended(btn.form).object },
      { action: "cancel", label: L("Cancel"), icon: "fa-solid fa-xmark", callback: () => null }
    ]
  });
}

/* -------------------------------------------------------------------------- */
/*  Moves                                                                     */
/* -------------------------------------------------------------------------- */

/** Build the update for a move item from pasted text (keeps its automation settings). */
export function moveUpdateFromText(moveSystem, text) {
  const p = parseMove(text);
  const update = { "system.description": p.description };
  if (p.trigger) update["system.trigger"] = p.trigger;
  if (p.tiers.length) for (const k of ["miss", "partial", "strong", "critical"]) update[`system.results.${k}`] = p.results[k];
  if (p.ability && moveSystem.rollType === "none") {
    update["system.rollType"] = "ability";
    update["system.ability"] = p.ability;
  }
  return { update, parsed: p };
}

const tierSummary = p => p.tiers.length ? p.tiers.map(t => L(`PA.Import.tier.${t}`)).join(", ") : L("PA.Import.noTiers");

/** "Import official text" on a single move sheet. */
export async function importMoveText(item) {
  const data = await pasteDialog({ title: F("PA.Import.moveTitle", { name: item.name }), hint: L("PA.Import.moveHint") });
  if (!data?.text?.trim()) return;
  const { update, parsed } = moveUpdateFromText(item.system, data.text);
  await item.update(update);
  ui.notifications.info(F("PA.Import.moveDone", { name: item.name, tiers: tierSummary(parsed) }));
}

/** Save a (possibly edited) move into the Keeper's Latchkey Moves compendium. */
export function saveMoveToKeeperPack(item) {
  return saveToKeeperPack("moves", item);
}

/** Texts imported for the basic moves: used by every new Latchkey. */
export function basicMoveOverrides() {
  return game.settings.get(SYSTEM_ID, "basicMoveTexts") ?? {};
}

/* -------------------------------------------------------------------------- */
/*  Bulk import (Latchkey Moves sheet / rulebook pages)                       */
/* -------------------------------------------------------------------------- */

const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;

export class ImportTextsApp extends HandlebarsApplicationMixin(ApplicationV2) {
  static DEFAULT_OPTIONS = {
    id: "pa-import-texts",
    tag: "form",
    classes: ["public-access", "pa-template-config", "pa-import-app"],
    window: { title: "PA.Import.bulkTitle", icon: "fa-solid fa-file-import", resizable: true },
    position: { width: 720, height: 760 },
    form: { handler: ImportTextsApp.#onSubmit, closeOnSubmit: false }
  };

  static PARTS = {
    form: { template: `systems/${SYSTEM_ID}/templates/apps/import-texts.hbs`, scrollable: [""] }
  };

  async _prepareContext() {
    return { report: this._report ?? null };
  }

  static async #onSubmit(event, form, formData) {
    const data = formData.object;
    if (!data.text?.trim()) return ui.notifications.warn(L("PA.Import.empty"));
    this._report = await bulkImportMoves(data.text, {
      keeper: !!data.keeper, world: !!data.world, basic: !!data.basic, actors: !!data.actors
    });
    this.render();
  }
}

/**
 * Split a big paste by move names and apply each chunk to every matching move.
 * @returns {{updated: string[], missing: string[]}}
 */
export async function bulkImportMoves(text, { keeper = true, world = false, basic = true, actors = true } = {}) {
  if (!game.user.isGM) return { updated: [], missing: [] };
  const targets = [];

  if (basic) for (const key of Object.keys(BASIC_NAMES)) targets.push({ key: `basic:${key}`, names: basicNames(key), basic: key });

  const pack = keeper ? await ensureKeeperPack("moves") : null;
  const packDocs = pack ? (await pack.getDocuments()).filter(d => d.type === "move") : [];
  const worldItems = world ? game.items.filter(i => i.type === "move") : [];
  const byName = new Map();
  for (const doc of [...packDocs, ...worldItems]) {
    const k = `name:${norm(doc.name)}`;
    if (!byName.has(k)) { byName.set(k, []); targets.push({ key: k, names: [doc.name] }); }
    byName.get(k).push(doc);
  }
  if (actors && !keeper && !world) {
    // Only the sheets: target the Latchkey moves they carry.
    for (const a of game.actors.filter(x => x.type === "latchkey")) {
      for (const i of a.items.filter(x => x.type === "move" && x.system.moveType !== "basic")) {
        const k = `name:${norm(i.name)}`;
        if (!byName.has(k)) { byName.set(k, []); targets.push({ key: k, names: [i.name] }); }
      }
    }
  }

  const { chunks, missing } = segmentByNames(text, targets);
  const updated = [];
  if (pack?.locked) await pack.configure({ locked: false });

  for (const chunk of chunks) {
    const target = targets.find(t => t.key === chunk.key);
    if (target.basic) {
      const { update } = moveUpdateFromText({ rollType: "choose" }, chunk.text);
      const overrides = foundry.utils.deepClone(basicMoveOverrides());
      overrides[target.basic] = foundry.utils.expandObject(update).system;
      await game.settings.set(SYSTEM_ID, "basicMoveTexts", overrides);
      if (actors) {
        for (const a of game.actors.filter(x => x.type === "latchkey")) {
          const items = a.items.filter(i => i.type === "move" && i.system.moveType === "basic" && i.system.key === target.basic);
          if (items.length) await a.updateEmbeddedDocuments("Item", items.map(i => ({ _id: i.id, ...update })));
        }
      }
      updated.push(target.names[0]);
      continue;
    }
    for (const doc of byName.get(chunk.key) ?? []) await doc.update(moveUpdateFromText(doc.system, chunk.text).update);
    if (actors) {
      for (const a of game.actors.filter(x => x.type === "latchkey")) {
        const items = a.items.filter(i => i.type === "move" && `name:${norm(i.name)}` === chunk.key);
        if (items.length) await a.updateEmbeddedDocuments("Item", items.map(i => ({ _id: i.id, ...moveUpdateFromText(i.system, chunk.text).update })));
      }
    }
    updated.push(target.names[0]);
  }
  ui.notifications.info(F("PA.Import.bulkDone", { n: updated.length }));
  return { updated, missing };
}

/* -------------------------------------------------------------------------- */
/*  Mysteries                                                                 */
/* -------------------------------------------------------------------------- */

const FORCE_SECTIONS = {
  "": "PA.Import.section.auto",
  presenting: "PA.Mystery.presentation",
  questions: "PA.Mystery.questions",
  key: "PA.Mystery.key",
  moments: "PA.Mystery.moments",
  threat: "PA.Mystery.threat",
  dangers: "PA.Mystery.dangers",
  locations: "PA.Mystery.locations",
  sideCharacters: "PA.Mystery.sideCharacters",
  clues: "PA.Mystery.clues",
  rewards: "PA.Mystery.rewards"
};
const HEADINGS = {
  presenting: "PRESENTING THE MYSTERY", questions: "QUESTIONS & OPPORTUNITIES", moments: "MOMENTS",
  dangers: "DANGERS", locations: "LOCATIONS", sideCharacters: "SIDE CHARACTERS", clues: "CLUES", rewards: "REWARDS"
};

/** Prepare pasted text so a single section can be imported without its heading. */
function forceSection(text, section) {
  if (!section) return text;
  if (HEADINGS[section]) return `IMPORTED MYSTERY\n${HEADINGS[section]}\n${text}`;
  const [first, ...rest] = text.trim().split("\n");
  if (section === "key") return `IMPORTED MYSTERY\n${/^the key of/i.test(first) ? first.toUpperCase() : `THE KEY OF ${first.toUpperCase()}`}\n${rest.join("\n")}`;
  if (section === "threat") return `IMPORTED MYSTERY\n${first.toUpperCase()}\n${rest.join("\n")}`;
  return text;
}

/** Merge parsed lists into the current ones, keeping play-state flags (found, visited, claimed…). */
function mergeList(current, parsed, listName, keepFields, matchByName = false) {
  const blank = MYSTERY_LISTS[listName];
  return parsed.map((entry, i) => {
    const old = matchByName
      ? current.find(c => norm(c.name) && norm(c.name) === norm(entry.name))
      : (current.length === parsed.length ? current[i] : null);
    const kept = old ? Object.fromEntries(keepFields.map(f => [f, old[f]])) : {};
    return { ...blank(), ...entry, ...kept };
  });
}

export function mysteryUpdateFromParsed(system, p) {
  const u = {};
  if (p.presentation) u["system.presentation"] = p.presentation;
  if (p.hook) u["system.hook"] = p.hook;
  if (p.questions.length) u["system.questions"] = mergeList(system.questions, p.questions, "questions", ["answered", "result"]);
  if (p.key.title || p.key.text) u["system.key"] = { ...system.key, title: p.key.title || system.key.title, text: p.key.text || system.key.text };
  if (p.moments.length) u["system.moments"] = mergeList(system.moments, p.moments, "moments", ["used"]);
  if (p.threat.name) u["system.threat.name"] = p.threat.name;
  if (p.threat.description) u["system.threat.description"] = p.threat.description;
  if (p.threat.ifIgnored) u["system.threat.ifIgnored"] = p.threat.ifIgnored;
  if (p.dangers.length) u["system.dangers"] = mergeList(system.dangers, p.dangers, "dangers", []);
  if (p.locations.length) u["system.locations"] = mergeList(system.locations, p.locations, "locations", ["visited"], true);
  if (p.sideCharacters.length) u["system.sideCharacters"] = mergeList(system.sideCharacters, p.sideCharacters, "sideCharacters", ["met"], true);
  if (p.clues.length) u["system.clues"] = mergeList(system.clues, p.clues, "clues", ["found", "foundBy"]);
  if (p.rewards.length) u["system.rewards"] = mergeList(system.rewards, p.rewards, "rewards", ["claimedBy"]);
  return u;
}

export async function importMysteryText(actor) {
  const options = Object.entries(FORCE_SECTIONS).map(([k, v]) => `<option value="${k}">${L(v)}</option>`).join("");
  const extra = `<div class="form-group"><label>${L("PA.Import.section.label")}</label><select name="section">${options}</select></div>
    <label class="pa-check-label"><input type="checkbox" name="rename"> ${L("PA.Import.rename")}</label>`;
  const data = await pasteDialog({ title: F("PA.Import.mysteryTitle", { name: actor.name }), hint: L("PA.Import.mysteryHint"), extra });
  if (!data?.text?.trim()) return;

  const parsed = parseMystery(forceSection(data.text, data.section));
  const update = mysteryUpdateFromParsed(actor.system, parsed);
  if (data.rename && parsed.title && !data.section) update.name = parsed.title;
  if (!Object.keys(update).length) return ui.notifications.warn(L("PA.Import.nothing"));

  const c = parsed.counts;
  const rows = [
    [L("PA.Mystery.presentation"), parsed.presentation ? "✔" : "—"],
    [L("PA.Mystery.hook"), parsed.hook ? "✔" : "—"],
    [L("PA.Mystery.questions"), c.questions],
    [L("PA.Mystery.key"), parsed.key.title || "—"],
    [L("PA.Mystery.moments"), c.moments],
    [L("PA.Mystery.threat"), parsed.threat.name || (parsed.threat.description ? "✔" : "—")],
    [L("PA.Mystery.dangers"), c.dangers],
    [L("PA.Mystery.locations"), c.locations],
    [L("PA.Mystery.sideCharacters"), c.sideCharacters],
    [L("PA.Mystery.clues"), c.clues],
    [L("PA.Mystery.rewards"), c.rewards]
  ];
  const content = `<p>${L("PA.Import.preview")}</p><table class="pa-import-preview">${rows.map(([k, v]) => `<tr><th>${k}</th><td>${escapeHTML(v)}</td></tr>`).join("")}</table>
    <p class="pa-hint">${L("PA.Import.previewHint")}</p>`;
  const ok = await DialogV2.confirm({ window: { title: L("PA.Import.apply") }, content, rejectClose: false });
  if (!ok) return;
  await actor.update(update);
  ui.notifications.info(F("PA.Import.mysteryDone", { name: actor.name }));
}

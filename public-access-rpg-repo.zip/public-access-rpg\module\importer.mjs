/**
 * Parsers that turn text pasted from the rulebook PDFs into structured move / mystery data.
 * Pure functions (no Foundry globals) so they can be tested outside the VTT.
 * The text itself is whatever the user pastes; nothing here ships book content.
 */

/* -------------------------------------------------------------------------- */
/*  Text helpers                                                              */
/* -------------------------------------------------------------------------- */

const ABILITIES = {
  vitality: ["vitality", "vitalidade"],
  composure: ["composure", "compostura"],
  reason: ["reason", "razao"],
  presence: ["presence", "presenca"],
  sensitivity: ["sensitivity", "sensibilidade"]
};

export const stripAccents = s => (s ?? "").normalize("NFKD").replace(/[̀-ͯ]/g, "");
/** Letters and digits only, lower case: tolerant to quotes, spacing and letter-spaced PDF headings. */
export const norm = s => stripAccents(s).toLowerCase().replace(/[^a-z0-9]/g, "");

export function escapeHTML(s) {
  return String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/** Normalize line endings, PDF ligatures and non-breaking spaces. */
export function cleanText(text) {
  return String(text ?? "")
    .replace(/\r\n?/g, "\n")
    .replace(/ /g, " ")
    .replace(/ﬁ/g, "fi").replace(/ﬂ/g, "fl")
    .replace(/\f/g, "\n\n")
    .replace(/[ \t]+\n/g, "\n");
}

/** Join wrapped lines into one string, repairing hyphenated line breaks. */
export function joinLines(lines) {
  let out = "";
  for (let line of lines) {
    line = line.trim();
    if (!line) continue;
    if (out.endsWith("-") && !out.endsWith("--") && /^[a-z]/.test(line)) out = out.slice(0, -1) + line;
    else out += (out ? " " : "") + line;
  }
  return out;
}

/** Split on blank lines; each paragraph has its wrapped lines joined. */
export function toParagraphs(text) {
  return cleanText(text).split(/\n\s*\n/).map(block => joinLines(block.split("\n"))).filter(Boolean);
}

export const paragraphsHTML = paras => paras.filter(Boolean).map(p => `<p>${escapeHTML(p)}</p>`).join("");

const endsSentence = line => /[.!?"'”’)\]]\s*$/.test(line.trim());
const startsUpper = line => /^[\s>•*\-–"“(]*[A-Z0-9]/.test(stripAccents(String(line ?? "").trim()));

/* -------------------------------------------------------------------------- */
/*  Moves                                                                     */
/* -------------------------------------------------------------------------- */

// Tier markers only count at the start of a sentence ("…even on a miss." is not a tier).
const TIER_RE = /(?:^|(?<=[.!?;:"”)]\s{1,3}))(?:on|em|com|no|num|numa)\s+(?:an?\s+|uma?\s+)?(10\s*\+|7\s*[-–—]\s*9|12\s*\+|6\s*-|miss|hit|falha|acerto)\s*[,:]?/gi;

/**
 * The rulebook often follows a move with commentary in the same paragraph
 * ("The Meddling Move is the main way…"). A tier's text stops at the first later sentence that
 * reads as commentary: it opens with The/This/Importantly… and doesn't address "you".
 * (The full text is always kept in the move description.)
 */
function trimCommentary(segment) {
  const sentences = segment.match(/[^.!?]+[.!?]+["”)]?\s*|[^.!?]+$/g) ?? [segment];
  const keep = [sentences[0]];
  for (const s of sentences.slice(1)) {
    const t = s.trim();
    const commentary = /^(the|this|these|importantly|note|in public access|o|a|este|esta|isso|importante)\b/i.test(t)
      && !/\b(you|your|voc[eê]|seu|sua)\b/i.test(t);
    if (commentary) break;
    keep.push(s);
  }
  return keep.join("").trim();
}

function tierKey(raw) {
  const k = raw.replace(/\s/g, "").toLowerCase();
  if (k.startsWith("10")) return "strong";
  if (k.startsWith("12")) return "critical";
  if (k.startsWith("7")) return "partial";
  if (k === "hit" || k === "acerto") return "hit";
  return "miss";
}

/**
 * Parse one move's text.
 * @returns {{description:string, trigger:string, results:object, ability:string|null, rollsAnyAbility:boolean, tiers:string[]}}
 */
export function parseMove(text) {
  const paras = toParagraphs(text);
  const found = { miss: [], partial: [], strong: [], critical: [], hit: [] };

  for (const para of paras) {
    const marks = [...para.matchAll(TIER_RE)];
    marks.forEach((m, i) => {
      const start = m.index;
      const end = i + 1 < marks.length ? marks[i + 1].index : para.length;
      found[tierKey(m[1])].push(trimCommentary(para.slice(start, end).trim()));
    });
  }

  // "On a hit" (7+) applies to both 10+ and 7-9.
  const results = {
    miss: found.miss,
    partial: [...found.hit, ...found.partial],
    strong: [...found.hit, ...found.strong],
    critical: found.critical
  };
  const html = Object.fromEntries(Object.entries(results).map(([k, v]) => [k, paragraphsHTML(v)]));

  const first = paras[0] ?? "";
  const triggerMatch = first.match(/^((?:when|whenever|once per|if you|quando|sempre que|uma vez por)[^.]*[.!?]?)/i);

  const plain = stripAccents(paras.join(" ")).toLowerCase();
  let ability = null;
  for (const [key, words] of Object.entries(ABILITIES)) {
    if (words.some(w => new RegExp(`\\b(?:roll|rolls|rolling|role|rolar|rola)\\s+(?:with|\\+|com)\\s+${w}\\b`).test(plain))) { ability = key; break; }
  }
  const rollsAnyAbility = /\b(?:roll|role|rolar)\s+(?:with|com)\s+(?:an?\s+|uma?\s+)?(?:appropriate|apropriada)/.test(plain);

  return {
    description: paragraphsHTML(paras),
    trigger: triggerMatch ? triggerMatch[1].trim() : "",
    results: html,
    ability,
    rollsAnyAbility,
    tiers: Object.entries(found).filter(([, v]) => v.length).map(([k]) => k)
  };
}

/** Build a regex that finds a move name at the start of a line, tolerant to quotes/punctuation. */
function nameRegex(name) {
  const words = stripAccents(name).split(/[^A-Za-z0-9]+/).filter(Boolean);
  if (!words.length) return null;
  return new RegExp(`^[^A-Za-z0-9]*${words.join("[^A-Za-z0-9]*")}(?![A-Za-z0-9])`, "i");
}

/**
 * Split a big paste (e.g. the whole Latchkey Moves sheet) into one chunk per known move name.
 * @param {string} text
 * @param {Array<{key:string, names:string[]}>} targets
 * @returns {{chunks: Array<{key:string, text:string}>, missing: string[]}}
 */
export function segmentByNames(text, targets) {
  const lines = cleanText(text).split("\n");
  const matchers = targets.flatMap(t => t.names.map(n => ({ key: t.key, len: norm(n).length, re: nameRegex(n) })))
    .filter(m => m.re).sort((a, b) => b.len - a.len);

  const hits = [];
  lines.forEach((raw, index) => {
    const line = stripAccents(raw);
    for (const m of matchers) {
      const match = line.match(m.re);
      if (match) { hits.push({ key: m.key, index, rest: raw.slice(match[0].length) }); break; }
    }
  });

  const seen = new Set();
  const chunks = [];
  hits.forEach((h, i) => {
    if (seen.has(h.key)) return;
    seen.add(h.key);
    const end = i + 1 < hits.length ? hits[i + 1].index : lines.length;
    const body = [h.rest.replace(/^[\s:.\-–—]+/, ""), ...lines.slice(h.index + 1, end)].join("\n").trim();
    if (body) chunks.push({ key: h.key, text: body });
  });
  const missing = targets.filter(t => !seen.has(t.key)).map(t => t.names[0]);
  return { chunks, missing };
}

/* -------------------------------------------------------------------------- */
/*  Mysteries                                                                 */
/* -------------------------------------------------------------------------- */

const SECTIONS = {
  presenting: ["presentingthemystery", "apresentandoomisterio", "apresentacao"],
  questions: ["questionsopportunities", "questionsandopportunities", "perguntasoportunidades", "perguntaseoportunidades"],
  moments: ["moments", "momentos"],
  dangers: ["dangers", "perigos"],
  locations: ["locations", "locais", "locacoes"],
  sideCharacters: ["sidecharacters", "personagenscoadjuvantes", "personagens"],
  clues: ["clues", "pistas"],
  rewards: ["rewards", "recompensas"],
  notes: ["notes", "notas", "anotacoes"],
  ignore: ["publicaccess"]
};

const isUpperHeading = line => {
  const letters = stripAccents(line).replace(/[^A-Za-z]/g, "");
  if (letters.length < 3) return false;
  const upper = letters.replace(/[^A-Z]/g, "").length;
  return upper / letters.length >= 0.8 && line.trim().split(/\s+/).length <= 10;
};

function sectionOf(line) {
  const n = norm(line);
  for (const [key, names] of Object.entries(SECTIONS)) if (names.includes(n)) return key;
  if (n.startsWith("thekeyof") || n.startsWith("akeyd") || n.startsWith("akeyof")) return "key";
  return null;
}

const titleCase = s => s.toLowerCase().replace(/(^|[\s\-(])([a-z])/g, (m, a, b) => a + b.toUpperCase());

/** Field labels inside an entry; matched at the start of a line or right after a finished sentence. */
const LABEL_RE = /(?:^|(?<=[.!?"”)]\s{1,3}))(paint\s*the\s*scene\b(?:\s*\([^)]*\))?\s*:|special\s*rule\s*:|regra\s*especial\s*:|quote\s*:|question\s*:|pergunta\s*:)/gim;
const LABEL_LINE_RE = /^\s*(paint\s*the\s*scene\b|special\s*rule\s*:|regra\s*especial\s*:|quote\s*:|question\s*:|pergunta\s*:|o\s*p\s*p\s*o\s*r\s*t\s*u\s*n\s*i\s*t\s*y\s*:)/i;

const isCap = w => /^[("“]?[A-Z0-9]/.test(stripAccents(w));

/** Is this line only a title (short, capitalized, no final punctuation, after a finished sentence)? */
function isTitleLine(line, prevLine) {
  const t = line.trim();
  if (!t || /[.:,;!?]$/.test(t) || LABEL_LINE_RE.test(t)) return false;
  const head = t.split("(")[0].trim();
  if (!head || head.split(/\s+/).length > 7 || head.length > 60 || !startsUpper(head)) return false;
  return prevLine === null || !prevLine.trim() || endsSentence(prevLine);
}

/**
 * A line where the title runs straight into the body ("Stand of trees A copse of…").
 * Returns { title, rest } or null.
 */
function splitMergedTitle(line) {
  const t = line.trim();
  if (!startsUpper(t) || LABEL_LINE_RE.test(t)) return null;
  const words = t.split(/\s+/);
  let cut = -1;
  const commaAt = words.slice(0, 4).findIndex(w => w.endsWith(","));
  if (commaAt >= 0) {
    // "Name, role (note) Body…": the body starts at the first capital after the role / note.
    let depth = 0;
    for (let i = commaAt + 1; i < words.length; i++) {
      depth += (words[i].match(/\(/g) ?? []).length - (words[i].match(/\)/g) ?? []).length;
      if (depth <= 0 && isCap(words[i]) && !words[i].startsWith("(")) { cut = i; break; }
      if (depth <= 0 && words[i].endsWith(")")) { cut = i + 1; break; }
    }
  } else if (words.length > 1 && isCap(words[1])) {
    // "Patience Head Helmet hair…": a run of capitalized words, the last of which starts the body.
    let run = 1;
    while (run < words.length && isCap(words[run])) run++;
    cut = run >= 2 ? run - 1 : -1;
  } else {
    // "Kitchen and dining room A small kitchen…": title until the next capitalized word.
    cut = words.findIndex((w, i) => i > 0 && isCap(w));
  }
  if (cut <= 0 || cut >= words.length) return null;
  const title = words.slice(0, cut).join(" ");
  if (/[.!?:]/.test(title.replace(/\([^)]*\)/g, "")) || title.split("(")[0].trim().split(/\s+/).length > 7) return null;
  return { title, rest: words.slice(cut).join(" ") };
}

/** Split a section into entries (title + body), whether titles sit on their own line or are merged with the body. */
function splitEntries(lines) {
  const entries = [];
  let current = null;
  let prev = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) { if (current) current.body.push(""); prev = line; continue; }
    const newEntryAllowed = prev === null || !prev.trim() || endsSentence(prev);
    if (isTitleLine(line, prev)) {
      let title = line.trim();
      while (title.includes("(") && !title.includes(")") && i + 1 < lines.length) title += " " + lines[++i].trim();
      current = { title, body: [] };
      entries.push(current);
    } else if (newEntryAllowed && splitMergedTitle(line) && (!current || !LABEL_LINE_RE.test(line))) {
      const { title, rest } = splitMergedTitle(line);
      current = { title, body: [rest] };
      entries.push(current);
    } else if (current) current.body.push(line);
    prev = line;
  }
  return entries;
}

/** Break an entry body into labelled fields (Paint the Scene, Special Rule, Quote, Question), inline or on their own lines. */
function splitFields(bodyLines) {
  const text = bodyLines.join("\n").split(/\n\s*\n/).map(b => joinLines(b.split("\n"))).filter(Boolean).join("\n\n");
  const out = { main: "", paint: "", rule: "", quote: "", question: "" };
  const marks = [...text.matchAll(LABEL_RE)];
  out.main = text.slice(0, marks[0]?.index ?? text.length).trim();
  marks.forEach((m, i) => {
    const end = i + 1 < marks.length ? marks[i + 1].index : text.length;
    const label = m[1].toLowerCase();
    const value = text.slice(m.index + m[0].length, end).trim();
    if (label.startsWith("paint")) {
      const note = m[1].match(/\([^)]*\)/)?.[0];
      out.paint = [out.paint, note ? `${note} ${value}` : value].filter(Boolean).join(" ");
    } else if (label.startsWith("special") || label.startsWith("regra")) out.rule = [out.rule, value].filter(Boolean).join("\n\n");
    else if (label.startsWith("quote")) out.quote = [out.quote, value].filter(Boolean).join("\n\n");
    else out.question = [out.question, value].filter(Boolean).join(" ");
  });
  return out;
}

/** Items (clues, rewards, moments): blank-line paragraphs, else a new item after each finished sentence. */
function splitItems(lines) {
  const text = lines.join("\n");
  const bullet = /^\s*(?:>|•|\*|-|–)\s+/;
  if (lines.some(l => bullet.test(l))) {
    const items = [];
    for (const l of lines) {
      if (bullet.test(l)) items.push([l.replace(bullet, "")]);
      else if (items.length && l.trim()) items[items.length - 1].push(l);
    }
    return items.map(joinLines).filter(Boolean);
  }
  if (/\n\s*\n/.test(text.trim())) return toParagraphs(text);
  const items = [];
  let prev = null;
  for (const l of lines) {
    if (!l.trim()) continue;
    if (!items.length || (endsSentence(prev) && startsUpper(l))) items.push([l]);
    else items[items.length - 1].push(l);
    prev = l;
  }
  return items.map(joinLines).filter(Boolean);
}

const QUESTION_RE = /(?:question|pergunta)\s*:\s*(.+?)\s*\(\s*(?:complexity|complexidade)\s*:?\s*(\d+)\s*\)\s*(?:o\s*p\s*p\s*o\s*r\s*t\s*u\s*n\s*i\s*t\s*y|oportunidade)?\s*:?\s*(.*?)(?=(?:question|pergunta)\s*:|$)/gis;

function parseQuestions(text) {
  return [...joinLines(cleanText(text).split("\n")).matchAll(QUESTION_RE)].map(m => ({
    text: m[1].trim(),
    complexity: Number(m[2]),
    opportunity: m[3].trim()
  }));
}

/**
 * Parse a whole mystery sheet pasted from the PDF.
 * @returns {object} partial MysteryData source + `title` + `counts`
 */
export function parseMystery(text) {
  const lines = cleanText(text).split("\n");
  const buckets = { presenting: [], questions: [], key: [], moments: [], threat: [], ifIgnored: [], dangers: [], locations: [], sideCharacters: [], clues: [], rewards: [], notes: [], ignore: [] };
  let section = null;
  let title = "";
  let keyTitle = "";
  let threatName = "";

  for (const raw of lines) {
    const line = raw.trim();
    if (line && isUpperHeading(line)) {
      const s = sectionOf(line);
      if (s === "key") { section = "key"; keyTitle = titleCase(line.replace(/\s+/g, " ")); continue; }
      if (s) { section = s; continue; }
      if (!title) { title = titleCase(line); section = section ?? "presenting"; continue; }
      if (norm(line) === norm(title)) continue;
      // Any other capitalized heading is the central threat (e.g. "THE HOUSE").
      section = "threat"; threatName = titleCase(line); continue;
    }
    if (/^(if the latchkeys ignore|se os latchkeys ignorarem)/i.test(line)) section = "ifIgnored";
    if (section) buckets[section].push(raw);
  }

  // Presenting: the "Pose the following…" paragraph is the hook for one Latchkey.
  const presParas = toParagraphs(buckets.presenting.join("\n"));
  let hook = "";
  const hookRe = /(?:^|(?<=[.!?"”]\s{1,3}))(pose the following|fa[cç]a a seguinte)/i;
  const hookIndex = presParas.findIndex(p => hookRe.test(p));
  if (hookIndex >= 0) {
    const p = presParas[hookIndex];
    const at = p.search(hookRe);
    hook = p.slice(at).trim();
    presParas.splice(hookIndex, 1, ...[p.slice(0, at).trim()].filter(Boolean));
  }

  const questions = parseQuestions(buckets.questions.join("\n"));

  const dangers = splitEntries(buckets.dangers).map(e => {
    const f = splitFields(e.body);
    const text = [f.main, f.quote ? `Quote: ${f.quote}` : ""].filter(Boolean).join("\n\n");
    return { name: e.title, text, rule: f.rule };
  });

  const locations = splitEntries(buckets.locations).map(e => {
    const f = splitFields(e.body);
    return { name: e.title, description: f.main, paint: f.paint, rule: f.rule };
  });

  const sideCharacters = splitEntries(buckets.sideCharacters).map(e => {
    const f = splitFields(e.body);
    const [head, ...paren] = e.title.split("(");
    const [name, ...role] = head.split(",");
    const note = paren.length ? `(${paren.join("(")}` : "";
    // The first short sentences are the three descriptive details.
    const sentences = f.main.match(/[^.!?]+[.!?]+["”]?|[^.!?]+$/g) ?? [f.main];
    const details = [];
    // Details end where the character is first named ("Casey is a nice guy…"); otherwise take short sentences.
    const firstName = stripAccents(name.trim().split(/\s+/)[0]).toLowerCase();
    const namedAt = sentences.slice(0, 4).findIndex(s => stripAccents(s.trim()).toLowerCase().startsWith(firstName));
    if (namedAt > 0) details.push(...sentences.splice(0, namedAt).map(s => s.trim()));
    else while (details.length < 3 && sentences.length && sentences[0].trim().split(/\s+/).length <= 7) details.push(sentences.shift().trim());
    if (f.question) questions.push(...parseQuestions(`Question: ${f.question}`));
    return {
      name: name.trim(),
      role: role.join(",").trim(),
      details: details.join(" "),
      description: [note, sentences.join("").trim(), f.question ? `Question: ${f.question}` : ""].filter(Boolean).join("\n\n"),
      quote: f.quote,
      hidden: /only enters play|s[oó] entra em jogo/i.test(note)
    };
  });

  const rewards = splitItems(buckets.rewards).map(text => {
    let gear = "";
    if (/corner of the house|canto da casa/i.test(text)) {
      const named = text.match(/^(.+?);\s*add (?:it|them) to your corner/i);
      gear = named && !/ask another latchkey/i.test(text) ? named[1].trim() : "?";
    }
    return { text, gear };
  });

  const result = {
    title,
    presentation: paragraphsHTML(presParas),
    hook,
    questions,
    key: { title: keyTitle, text: joinLines(buckets.key) },
    moments: splitItems(buckets.moments).map(text => ({ text })),
    threat: {
      name: threatName,
      description: paragraphsHTML(toParagraphs(buckets.threat.join("\n"))),
      ifIgnored: paragraphsHTML(toParagraphs(buckets.ifIgnored.join("\n")))
    },
    dangers, locations, sideCharacters,
    clues: splitItems(buckets.clues).map(text => ({ text })),
    rewards
  };
  result.counts = {
    questions: questions.length, moments: result.moments.length, dangers: dangers.length,
    locations: locations.length, sideCharacters: sideCharacters.length,
    clues: result.clues.length, rewards: rewards.length
  };
  return result;
}

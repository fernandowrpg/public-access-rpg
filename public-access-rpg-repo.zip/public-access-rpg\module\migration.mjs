import { SYSTEM_ID } from "./config.mjs";
import { getSheetTemplate } from "./defaults.mjs";

/** Current data version of the world. Bump when a migration is added. */
const CURRENT = 2;

/** Placeholder texts shipped before 1.5 ("copy the prompt from your character sheet", "Advancement 1"…). */
const PLACEHOLDER = new RegExp([
  "\\(copy the (?:full )?prompt", "\\(copie o prompt", "copy it from your character sheet", "copie da sua ficha",
  "copy from your character sheet", "Elective Dawn question \\d", "Dawn Question eletiva \\d",
  "^Advancement \\d", "^Avanço \\d", "^Key of the Child \\d", "^Key of Desolation \\d", "Fixed Dawn question", "Dawn Question fixa"
].join("|"), "i");

const hasPlaceholder = list => (list ?? []).some(e => PLACEHOLDER.test(`${e.title ?? ""}`) || PLACEHOLDER.test(`${e.text ?? ""}`));

/** Copy play state (marks) from the old list onto the new one, by position. */
function keepMarks(oldList, newList, fields) {
  return newList.map((entry, i) => {
    const old = oldList[i];
    if (!old) return entry;
    const kept = Object.fromEntries(fields.filter(f => f in old).map(f => [f, old[f]]));
    return { ...entry, ...kept };
  });
}

export async function migrateWorld() {
  if (game.user !== game.users.activeGM) return;
  const version = game.settings.get(SYSTEM_ID, "dataVersion") ?? 0;
  if (version >= CURRENT) return;

  // 1. A saved Latchkey Template still holding placeholders falls back to the new defaults.
  const saved = foundry.utils.deepClone(game.settings.get(SYSTEM_ID, "sheetTemplate") ?? {});
  let templateChanged = false;
  for (const k of ["dawn", "child", "desolation", "advancements"]) {
    if (typeof saved[k] === "string" && PLACEHOLDER.test(saved[k].split("\n").join(" "))) { delete saved[k]; templateChanged = true; }
  }
  if (saved.abilities && Object.values(saved.abilities).every(v => Number(v) === 0)) { delete saved.abilities; templateChanged = true; }
  if (templateChanged) await game.settings.set(SYSTEM_ID, "sheetTemplate", saved);

  // 2. Latchkeys whose lists are still placeholders get the real lists, keeping their marks.
  const tpl = getSheetTemplate();
  let migrated = 0;
  for (const actor of game.actors.filter(a => a.type === "latchkey")) {
    const sys = actor.system;
    const update = {};
    if (hasPlaceholder(sys.dawnQuestions)) {
      const unlocked = sys.dawnQuestions.some(q => q.kind === "unlockable" && q.unlocked);
      const electives = sys.dawnQuestions.filter(q => q.kind === "elective");
      let e = 0;
      update["system.dawnQuestions"] = tpl.dawnQuestions.map(q => {
        if (q.kind === "unlockable") return { ...q, unlocked, marked: unlocked };
        if (q.kind === "elective") return { ...q, marked: !!electives[e++]?.marked };
        return q;
      });
    }
    if (hasPlaceholder(sys.keysChild)) update["system.keysChild"] = keepMarks(sys.keysChild, tpl.keysChild, ["marked", "resolved"]);
    if (hasPlaceholder(sys.keysDesolation)) update["system.keysDesolation"] = keepMarks(sys.keysDesolation, tpl.keysDesolation, ["marked", "resolved"]);
    if (hasPlaceholder(sys.advancements)) update["system.advancements"] = keepMarks(sys.advancements, tpl.advancements, ["marked"]);
    if (Object.keys(update).length) {
      await actor.update(update);
      migrated++;
    }
  }

  await game.settings.set(SYSTEM_ID, "dataVersion", CURRENT);
  if (migrated) ui.notifications.info(game.i18n.format("PA.Migration.done", { n: migrated }), { permanent: true });
}


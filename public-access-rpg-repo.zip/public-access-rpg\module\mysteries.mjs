import { PA, SYSTEM_ID } from "./config.mjs";
import { createChat } from "./compat.mjs";
import { escapeHTML } from "./importer.mjs";
import { keeperPack, ensureKeeperPack, saveToKeeperPack } from "./packs.mjs";

const { DialogV2 } = foundry.applications.api;
const renderTemplate = (...args) => foundry.applications.handlebars.renderTemplate(...args);
const L = key => game.i18n.localize(key);
const F = (key, data) => game.i18n.format(key, data);
const esc = s => escapeHTML(String(s ?? ""));


/* -------------------------------------------------------------------------- */
/*  Active-mystery summary (readable by players)                              */
/* -------------------------------------------------------------------------- */

/** Summaries of active mysteries, kept in a world setting so players can use Questions and Keys. */
export function getActiveMysteries() {
  return game.settings.get(SYSTEM_ID, "activeMysteries") ?? [];
}

export async function refreshActiveMysteries() {
  if (game.user !== game.users.activeGM) return;
  const summaries = game.actors.filter(a => a.type === "mystery" && a.system.status === "active").map(a => a.system.summary);
  const current = getActiveMysteries();
  if (JSON.stringify(current) === JSON.stringify(summaries)) return;
  await game.settings.set(SYSTEM_ID, "activeMysteries", summaries);
}

export function registerMysteryHooks() {
  const refresh = doc => { if (doc.type === "mystery") refreshActiveMysteries(); };
  Hooks.on("createActor", refresh);
  Hooks.on("updateActor", refresh);
  Hooks.on("deleteActor", refresh);
  Hooks.once("ready", async () => {
    await refreshActiveMysteries();
    await ensureKeeperPack("mysteries");
    await ensureKeeperPack("moves");
  });
}

/** Socket messages players send to the GM about mysteries. */
export async function handleMysterySocket(payload) {
  if (game.user !== game.users.activeGM) return;
  if (payload.type === "mysteryKey") return markMysteryKey(payload.uuid, payload.actorName);
}

export async function markMysteryKey(uuid, actorName) {
  const mystery = await fromUuid(uuid);
  if (!mystery || mystery.system.key.used) return;
  await mystery.update({ "system.key.used": true, "system.key.usedBy": actorName ?? "" });
}

/** Called by a player who turned an active mystery's Key. */
export function requestMysteryKey(uuid, actorName) {
  if (game.user.isGM) return markMysteryKey(uuid, actorName);
  game.socket.emit(`system.${SYSTEM_ID}`, { type: "mysteryKey", uuid, actorName });
}

/* -------------------------------------------------------------------------- */
/*  World compendium for the Keeper's own mysteries                           */
/* -------------------------------------------------------------------------- */

export const worldPack = () => keeperPack("mysteries");
export const ensureWorldPack = () => ensureKeeperPack("mysteries");

/** Save (or overwrite) a mystery in the Keeper's world compendium. */
export function exportToWorldPack(actor) {
  return saveToKeeperPack("mysteries", actor, { transform: data => { data.system.status = "inactive"; } });
}

/** Create a blank mystery actor and open its sheet. */
export async function newMystery() {
  if (!game.user.isGM) return;
  const actor = await Actor.create({ name: L("PA.Mystery.new"), type: "mystery", img: "icons/svg/mystery-man.svg" });
  actor?.sheet.render(true);
  return actor;
}

/* -------------------------------------------------------------------------- */
/*  Chat cards                                                                */
/* -------------------------------------------------------------------------- */

async function card(mystery, { title, icon = "fa-solid fa-tv", body = "", rows = [], whisper = false }) {
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/mystery-card.hbs`, {
    mysteryName: mystery.name, img: mystery.img, title, icon, body, rows
  });
  const data = { content, speaker: { alias: mystery.name } };
  if (whisper) data.whisper = ChatMessage.getWhisperRecipients("GM");
  return createChat(data);
}

const TE = () => foundry.applications.ux.TextEditor.implementation;

export async function presentMystery(mystery) {
  const s = mystery.system;
  const rows = [];
  if (s.hook) rows.push({ icon: "fa-solid fa-comment", label: L("PA.Mystery.hook"), text: s.hook });
  for (const q of s.questions.filter(q => q.text)) {
    rows.push({ icon: "fa-solid fa-circle-question", label: `${L("PA.Mystery.question")} (${L("PA.Question.complexity")} ${q.complexity})`, text: q.text });
    if (q.opportunity) rows.push({ icon: "fa-solid fa-door-open", label: L("PA.Mystery.opportunity"), text: q.opportunity });
  }
  if (s.key.title) rows.push({ icon: "fa-solid fa-key", label: s.key.title, text: s.key.text });
  const body = await TE().enrichHTML(s.presentation, { relativeTo: mystery });
  if (s.status === "inactive") await mystery.update({ "system.status": "active" });
  return card(mystery, { title: L("PA.Mystery.presenting"), icon: "fa-solid fa-tower-broadcast", body, rows });
}

export async function postLocation(mystery, index) {
  const loc = mystery.system.locations[index];
  if (!loc) return;
  const rows = [];
  if (loc.paint) rows.push({ icon: "fa-solid fa-paintbrush", label: L("PA.Mystery.paint"), text: loc.paint });
  await card(mystery, { title: loc.name, icon: "fa-solid fa-location-dot", body: `<p>${esc(loc.description)}</p>`, rows });
  if (!loc.visited) await setListField(mystery, "locations", index, "visited", true);
}

export async function postCharacter(mystery, index) {
  const c = mystery.system.sideCharacters[index];
  if (!c) return;
  const rows = [];
  if (c.details) rows.push({ icon: "fa-solid fa-eye", label: L("PA.Mystery.details"), text: c.details });
  await card(mystery, { title: c.role ? `${c.name}, ${c.role}` : c.name, icon: "fa-solid fa-user", body: "", rows });
  if (!c.met) await setListField(mystery, "sideCharacters", index, "met", true);
}

export async function postMoment(mystery, index) {
  const m = mystery.system.moments[index];
  if (!m) return;
  await card(mystery, { title: L("PA.Mystery.moment"), icon: "fa-solid fa-film", body: `<p><em>${esc(m.text)}</em></p>` });
  if (!m.used) await setListField(mystery, "moments", index, "used", true);
}

export async function revealClue(mystery, index, foundBy = "") {
  const c = mystery.system.clues[index];
  if (!c) return;
  const list = foundry.utils.deepClone(mystery.system.clues);
  list[index].found = true;
  list[index].foundBy = foundBy || list[index].foundBy;
  await mystery.update({ "system.clues": list });
  const rows = [{ icon: "fa-solid fa-magnifying-glass", label: L("PA.Mystery.cluesFound"), text: `${mystery.system.cluesFound}` }];
  return card(mystery, {
    title: foundBy ? F("PA.Mystery.clueFoundBy", { name: foundBy }) : L("PA.Mystery.clue"),
    icon: "fa-solid fa-magnifying-glass", body: `<p><strong>${esc(c.text)}</strong></p>`, rows
  });
}

async function setListField(mystery, listName, index, field, value) {
  const list = foundry.utils.deepClone(mystery.system[listName]);
  if (!list[index]) return;
  list[index][field] = value;
  await mystery.update({ [`system.${listName}`]: list });
}

/* -------------------------------------------------------------------------- */
/*  Rewards                                                                   */
/* -------------------------------------------------------------------------- */

export async function claimReward(mystery, index) {
  const reward = mystery.system.rewards[index];
  if (!reward || reward.claimedBy) return;
  const latchkeys = game.actors.filter(a => a.type === "latchkey" && !a.system.retired);
  if (!latchkeys.length) return ui.notifications.warn(L("PA.Warn.noActor"));
  const askGear = reward.gear === "?";
  const content = `<p>${esc(reward.text)}</p>
    <div class="form-group"><label>${L("PA.Mystery.claimWho")}</label><select name="actor">${
      latchkeys.map(a => `<option value="${a.id}">${esc(a.name)}</option>`).join("")}</select></div>
    ${askGear ? `<div class="form-group"><label>${L("PA.Mystery.claimGear")}</label><input type="text" name="gear"></div>` : ""}`;
  const data = await DialogV2.wait({
    window: { title: L("PA.Mystery.claim"), icon: "fa-solid fa-gift" },
    classes: ["public-access", "pa-dialog"],
    content, rejectClose: false,
    buttons: [
      { action: "ok", label: L("PA.Mystery.claim"), icon: "fa-solid fa-gift", default: true,
        callback: (ev, btn) => new foundry.applications.ux.FormDataExtended(btn.form).object },
      { action: "cancel", label: L("Cancel"), callback: () => null }
    ]
  });
  if (!data?.actor) return;
  const actor = game.actors.get(data.actor);
  const gearName = askGear ? data.gear?.trim() : reward.gear.trim();
  if (gearName) await actor.createEmbeddedDocuments("Item", [{ name: gearName, type: "gear", img: "icons/svg/item-bag.svg" }]);
  await setListField(mystery, "rewards", index, "claimedBy", actor.name);
  await card(mystery, {
    title: F("PA.Mystery.claimed", { name: actor.name }), icon: "fa-solid fa-gift",
    body: `<p>${esc(reward.text)}</p>${gearName ? `<p><em>${F("PA.Move.gearAdded", { name: esc(gearName) })}</em></p>` : ""}`
  });
}

/* -------------------------------------------------------------------------- */
/*  Integration with roll cards                                               */
/* -------------------------------------------------------------------------- */

/** GM picks an unfound clue from an active mystery and reveals it on a Meddling roll card. */
export async function revealClueOnMessage(message, updateCard) {
  if (!game.user.isGM) return;
  const flags = foundry.utils.deepClone(message.flags[SYSTEM_ID]);
  const mysteries = game.actors.filter(a => a.type === "mystery" && a.system.status === "active");
  const options = mysteries.flatMap(m => m.system.clues.map((c, i) => ({ m, c, i })).filter(o => !o.c.found));
  if (!options.length) return ui.notifications.warn(L("PA.Mystery.noClues"));
  const content = `<div class="pa-clue-pick">${options.map((o, n) => `
    <label class="pa-radio"><input type="radio" name="pick" value="${n}" ${n === 0 ? "checked" : ""}>
      <span><strong>${esc(o.m.name)}</strong> — ${esc(o.c.text)}</span></label>`).join("")}</div>`;
  const data = await DialogV2.wait({
    window: { title: L("PA.Mystery.revealClue"), icon: "fa-solid fa-magnifying-glass" },
    classes: ["public-access", "pa-dialog"],
    position: { width: 520 },
    content, rejectClose: false,
    buttons: [
      { action: "ok", label: L("PA.Mystery.revealClue"), icon: "fa-solid fa-magnifying-glass", default: true,
        callback: (ev, btn) => new foundry.applications.ux.FormDataExtended(btn.form).object },
      { action: "cancel", label: L("Cancel"), callback: () => null }
    ]
  });
  if (data?.pick === undefined || data?.pick === null) return;
  const o = options[Number(data.pick)];
  if (!o) return;
  const actor = flags.actorUuid ? fromUuidSync(flags.actorUuid) : null;
  const list = foundry.utils.deepClone(o.m.system.clues);
  list[o.i].found = true;
  list[o.i].foundBy = actor?.name ?? "";
  await o.m.update({ "system.clues": list });
  flags.revealed ??= [];
  flags.revealed.push({ mystery: o.m.name, text: o.c.text });
  return updateCard(message, flags);
}

/** GM records the Answer a Question result on the linked mystery. */
export async function recordAnswer(message, updateCard) {
  if (!game.user.isGM) return;
  const flags = foundry.utils.deepClone(message.flags[SYSTEM_ID]);
  const mystery = flags.mysteryUuid ? await fromUuid(flags.mysteryUuid) : null;
  if (!mystery) return ui.notifications.warn(L("PA.Mystery.missing"));
  const tierIndex = Math.min(3, flags.baseTier + flags.shifts.length);
  const tier = PA.tiers[tierIndex];
  const list = foundry.utils.deepClone(mystery.system.questions);
  const q = list[flags.questionIndex];
  if (!q) return;
  q.answered = tierIndex >= 1;
  q.result = L(PA.tierLabels[tier]);
  await mystery.update({ "system.questions": list });
  flags.recorded = q.answered ? L("PA.Mystery.recordedHit") : L("PA.Mystery.recordedMiss");
  return updateCard(message, flags);
}

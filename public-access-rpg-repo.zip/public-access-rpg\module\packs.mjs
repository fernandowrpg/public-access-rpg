import { SYSTEM_ID } from "./config.mjs";
import { escapeHTML } from "./importer.mjs";

const L = key => game.i18n.localize(key);
const F = (key, data) => game.i18n.format(key, data);

/** World compendiums the Keeper owns (never overwritten by system updates). */
export const KEEPER_PACKS = {
  mysteries: { name: "pa-mysteries", type: "Actor", label: "PA.Mystery.worldPack", folder: "Mistérios (Mysteries)" },
  moves: { name: "pa-latchkey-moves", type: "Item", label: "PA.Import.movesPack", folder: "Latchkey Moves", seed: "latchkey-moves" }
};

const isPt = () => (game.i18n.lang ?? "en").toLowerCase().startsWith("pt");

export function keeperPack(kind) {
  return game.packs.get(`world.${KEEPER_PACKS[kind].name}`);
}

/** Create the world compendium if needed, file it into its folder and (first time) seed it from the system pack. */
export async function ensureKeeperPack(kind) {
  if (!game.user.isGM) return keeperPack(kind) ?? null;
  const cfg = KEEPER_PACKS[kind];
  let pack = keeperPack(kind);
  let created = false;
  if (!pack) {
    const CC = foundry.documents.collections.CompendiumCollection;
    pack = await CC.createCompendium({ type: cfg.type, label: L(cfg.label), name: cfg.name, package: "world" });
    created = true;
  }

  const folder = game.folders.find(f => f.type === "Compendium" && f.name === cfg.folder);
  if (folder && pack.folder?.id !== folder.id) {
    try {
      if (typeof pack.setFolder === "function") await pack.setFolder(folder);
      else await pack.configure({ folder: folder.id });
    } catch (err) {
      console.warn(`${SYSTEM_ID} | Could not file ${pack.collection} into its folder`, err);
    }
  }

  if (created && cfg.seed) {
    const source = game.packs.get(`${SYSTEM_ID}.${cfg.seed}-${isPt() ? "pt" : "en"}`);
    if (source) {
      const docs = await source.getDocuments();
      const cls = getDocumentClass(cfg.type);
      await cls.createDocuments(docs.map(d => d.toObject()), { pack: pack.collection });
      ui.notifications.info(F("PA.Import.seeded", { pack: pack.metadata.label, n: docs.length }));
    }
  }
  return pack;
}

/** Save a document into a Keeper compendium, replacing an entry with the same name (after confirmation). */
export async function saveToKeeperPack(kind, doc, { transform } = {}) {
  const pack = await ensureKeeperPack(kind);
  if (!pack) return;
  if (pack.locked) await pack.configure({ locked: false });
  const index = await pack.getIndex();
  const existing = index.find(e => e.name === doc.name);
  if (existing) {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: L("PA.Import.save") },
      content: `<p>${F("PA.Mystery.exportReplace", { name: escapeHTML(doc.name) })}</p>`,
      rejectClose: false
    });
    if (!ok) return;
    const old = await pack.getDocument(existing._id);
    await old?.delete();
  }
  const data = doc.toObject();
  delete data._id;
  transform?.(data);
  await getDocumentClass(pack.documentName).create(data, { pack: pack.collection });
  ui.notifications.info(F("PA.Mystery.exported", { name: doc.name, pack: pack.metadata.label }));
}

function getDocumentClass(name) {
  return CONFIG[name].documentClass;
}

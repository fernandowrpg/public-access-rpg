/**
 * Public Access — Foundry VTT system (v13+).
 */
import { PA, SYSTEM_ID } from "./config.mjs";
import { LatchkeyData } from "./data/latchkey.mjs";
import { MoveData, GearData } from "./data/items.mjs";
import { LatchkeySheet } from "./sheets/latchkey-sheet.mjs";
import { PAItemSheet } from "./sheets/item-sheet.mjs";
import { TemplateConfig } from "./apps/template-config.mjs";
import { PhaseClock } from "./apps/phase-clock.mjs";
import * as ImportTools from "./import-tools.mjs";
import { migrateWorld } from "./migration.mjs";
import * as Rolls from "./rolls.mjs";
import * as Mysteries from "./mysteries.mjs";
import { MysteryData } from "./data/mystery.mjs";
import { MysterySheet } from "./sheets/mystery-sheet.mjs";
import { buildBasicMoves, getSheetTemplate } from "./defaults.mjs";

Hooks.once("init", () => {
  console.log(`${SYSTEM_ID} | Initializing Public Access`);

  CONFIG.PA = PA;
  CONFIG.Actor.dataModels.latchkey = LatchkeyData;
  CONFIG.Actor.dataModels.mystery = MysteryData;
  CONFIG.Item.dataModels.move = MoveData;
  CONFIG.Item.dataModels.gear = GearData;
  CONFIG.Actor.trackableAttributes = { latchkey: { bar: [], value: ["xp"] } };

  const DSC = foundry.applications.apps.DocumentSheetConfig;
  DSC.registerSheet(Actor, SYSTEM_ID, LatchkeySheet, { types: ["latchkey"], makeDefault: true, label: "PA.Sheet.latchkey" });
  DSC.registerSheet(Actor, SYSTEM_ID, MysterySheet, { types: ["mystery"], makeDefault: true, label: "PA.Sheet.mystery" });
  DSC.registerSheet(Item, SYSTEM_ID, PAItemSheet, { types: ["move", "gear"], makeDefault: true, label: "PA.Sheet.item" });

  registerSettings();
  registerHelpers();
  Mysteries.registerMysteryHooks();

  foundry.applications.handlebars.loadTemplates([
    `systems/${SYSTEM_ID}/templates/actor/move-row.hbs`,
    `systems/${SYSTEM_ID}/templates/actor/key-list.hbs`,
    `systems/${SYSTEM_ID}/templates/actor/corner.hbs`,
    `systems/${SYSTEM_ID}/templates/mystery/list-edit.hbs`
  ]);

  game.publicAccess = {
    PA, Rolls, buildBasicMoves, getSheetTemplate,
    rollItemMacro,
    useMove: (actor, item) => Rolls.useMove(actor, item),
    turnKey: actor => Rolls.turnKey(actor),
    takeCondition: (actor, name) => Rolls.takeCondition(actor, name),
    addXP: (actor, n) => Rolls.addXP(actor, n),
    setPhase: phase => game.settings.set(SYSTEM_ID, "phase", phase),
    newSession: () => Rolls.newSession(),
    PhaseClock,
    togglePhaseClock: force => PhaseClock.toggle(force),
    Mysteries,
    newMystery: () => Mysteries.newMystery(),
    exportMystery: actor => Mysteries.exportToWorldPack(actor),
    ImportTools,
    importTexts: () => new ImportTools.ImportTextsApp().render(true)
  };
});

Hooks.once("ready", () => {
  migrateWorld();
  if (game.settings.get(SYSTEM_ID, "phaseClockVisible")) PhaseClock.instance.render({ force: true });
  game.socket.on(`system.${SYSTEM_ID}`, payload => {
    Rolls.handleSocket(payload);
    Mysteries.handleMysterySocket(payload);
  });
});

Hooks.on("renderChatMessageHTML", (message, html) => Rolls.onRenderChatMessage(message, html));

/** Drag a move to the hotbar to create a macro. */
Hooks.on("hotbarDrop", (bar, data, slot) => {
  if (data.type !== "Item" || fromUuidSync(data.uuid)?.type !== "move") return;
  createMoveMacro(data, slot);
  return false;
});

/* -------------------------------------------------------------------------- */

function registerSettings() {
  const rerender = () => {
    for (const app of foundry.applications.instances.values()) {
      if (app instanceof LatchkeySheet) app.render();
    }
  };

  game.settings.register(SYSTEM_ID, "phase", {
    name: "PA.Settings.phase.name",
    hint: "PA.Settings.phase.hint",
    scope: "world", config: true, type: String, default: "day",
    choices: PA.phases,
    onChange: phase => {
      rerender();
      PhaseClock.refresh();
      Rolls.onPhaseChange(phase);
      ui.notifications.info(game.i18n.format("PA.Phase.changed", { phase: game.i18n.localize(PA.phases[phase]) }));
    }
  });

  game.settings.register(SYSTEM_ID, "tapesWatched", {
    name: "PA.Settings.tapes.name",
    hint: "PA.Settings.tapes.hint",
    scope: "world", config: true, type: Number, default: 0,
    onChange: () => { rerender(); PhaseClock.refresh(); }
  });

  game.settings.register(SYSTEM_ID, "phaseClockVisible", {
    name: "PA.Clock.settingName",
    hint: "PA.Clock.settingHint",
    scope: "client", config: true, type: Boolean, default: true,
    onChange: visible => { if (visible && !PhaseClock.instance.rendered) PhaseClock.instance.render({ force: true }); }
  });

  game.settings.register(SYSTEM_ID, "phaseClockPosition", {
    scope: "client", config: false, type: Object, default: {}
  });

  game.keybindings.register(SYSTEM_ID, "togglePhaseClock", {
    name: "PA.Clock.keybinding",
    editable: [{ key: "KeyP", modifiers: ["Shift"] }],
    onDown: () => { PhaseClock.toggle(); return true; }
  });

  game.settings.register(SYSTEM_ID, "lastComplexity", {
    scope: "world", config: false, type: Number, default: 6
  });

  game.settings.register(SYSTEM_ID, "activeMysteries", {
    scope: "world", config: false, type: Array, default: []
  });

  game.settings.register(SYSTEM_ID, "dataVersion", {
    scope: "world", config: false, type: Number, default: 0
  });

  game.settings.register(SYSTEM_ID, "basicMoveTexts", {
    scope: "world", config: false, type: Object, default: {}
  });

  game.settings.registerMenu(SYSTEM_ID, "importMenu", {
    name: "PA.Import.bulkTitle",
    label: "PA.Import.menuLabel",
    hint: "PA.Import.menuHint",
    icon: "fa-solid fa-file-import",
    type: ImportTools.ImportTextsApp,
    restricted: true
  });

  game.settings.register(SYSTEM_ID, "sheetTemplate", {
    scope: "world", config: false, type: Object, default: {}
  });

  game.settings.registerMenu(SYSTEM_ID, "templateMenu", {
    name: "PA.Template.menuTitle",
    label: "PA.Template.menuLabel",
    hint: "PA.Template.menuHint",
    icon: "fa-solid fa-id-card",
    type: TemplateConfig,
    restricted: true
  });
}

function registerHelpers() {
  Handlebars.registerHelper("pa-signed", n => (Number(n) >= 0 ? `+${Number(n)}` : `${Number(n)}`));
  Handlebars.registerHelper("pa-inc", n => Number(n) + 1);
  // Core provides these; keep fallbacks so templates never break.
  const fallbacks = {
    eq: (a, b) => a === b,
    ne: (a, b) => a !== b,
    not: a => !a,
    or: (...args) => args.slice(0, -1).some(Boolean),
    and: (...args) => args.slice(0, -1).every(Boolean)
  };
  for (const [name, fn] of Object.entries(fallbacks)) {
    if (!Handlebars.helpers[name]) Handlebars.registerHelper(name, fn);
  }
}

/* -------------------------------------------------------------------------- */

async function createMoveMacro(data, slot) {
  const item = await fromUuid(data.uuid);
  if (!item || item.type !== "move") return;
  const command = `game.publicAccess.rollItemMacro("${item.uuid}");`;
  let macro = game.macros.find(m => m.name === item.name && m.command === command);
  if (!macro) {
    macro = await Macro.create({ name: item.name, type: "script", img: item.img, command, flags: { [SYSTEM_ID]: { itemMacro: true } } });
  }
  game.user.assignHotbarMacro(macro, slot);
}

async function rollItemMacro(uuid) {
  const item = await fromUuid(uuid);
  if (!item) return ui.notifications.warn(game.i18n.localize("PA.Warn.macroMissing"));
  // Moves in the world directory: use the selected token / assigned character.
  const actor = item.actor
    ?? canvas.tokens?.controlled[0]?.actor
    ?? game.user.character;
  if (!actor || actor.type !== "latchkey") return ui.notifications.warn(game.i18n.localize("PA.Warn.noActor"));
  const owned = item.actor ? item : actor.items.find(i => i.type === "move" && i.name === item.name) ?? item;
  return Rolls.useMove(actor, owned);
}

import { PA, SYSTEM_ID } from "./config.mjs";
import { applyMessageMode, createChat } from "./compat.mjs";
import { escapeHTML } from "./importer.mjs";
import * as Mysteries from "./mysteries.mjs";

const { DialogV2 } = foundry.applications.api;
const renderTemplate = (...args) => foundry.applications.handlebars.renderTemplate(...args);
const FormDataExtended = () => foundry.applications.ux.FormDataExtended;
const TextEditor = () => foundry.applications.ux.TextEditor.implementation;
const L = key => game.i18n.localize(key);
const F = (key, data) => game.i18n.format(key, data);
const esc = s => escapeHTML(s ?? "");

/* -------------------------------------------------------------------------- */
/*  Helpers                                                                   */
/* -------------------------------------------------------------------------- */

export function tierFromTotal(total) {
  if (total >= 12) return 3;
  if (total >= 10) return 2;
  if (total >= 7) return 1;
  return 0;
}

/** "Feeling Good" (Thank You for Being a Friend) is a positive Condition: clear it for advantage. */
export function isFeelingGood(name) {
  const n = (name ?? "").trim().toLowerCase();
  return n === L("PA.Condition.feelingGood").toLowerCase() || n === "feeling good";
}

/** Latchkey moves that can be applied from this move's roll dialog. */
export function companionMoves(actor, item) {
  const key = item.system.key;
  return actor.items.filter(i => i.type === "move" && i.id !== item.id && i.system.isHook
    && i.system.hook.move !== "nostalgic"
    && (i.system.hook.move === "any" || (key && i.system.hook.move === key))
    && (!i.system.hasUses || i.system.uses.value > 0));
}

export function currentPhase() {
  return game.settings.get(SYSTEM_ID, "phase");
}

function formData(button) {
  return new (FormDataExtended())(button.form).object;
}

async function dialog({ title, content, okLabel, okIcon = "fa-solid fa-dice", extraButtons = [], render }) {
  return DialogV2.wait({
    render,
    window: { title, icon: "fa-solid fa-tv" },
    classes: ["public-access", "pa-dialog"],
    position: { width: 440 },
    content,
    rejectClose: false,
    buttons: [
      { action: "ok", label: okLabel ?? L("PA.Roll.roll"), icon: okIcon, default: true, callback: (ev, btn) => formData(btn) },
      ...extraButtons,
      { action: "cancel", label: L("Cancel"), icon: "fa-solid fa-xmark", callback: () => null }
    ]
  });
}

/** Update a chat message, routing through an active GM when the user lacks permission. */
export async function updateMessage(message, data) {
  if (message.canUserModify(game.user, "update")) return message.update(data);
  if (!game.users.activeGM) return ui.notifications.warn(L("PA.Warn.noGM"));
  game.socket.emit(`system.${SYSTEM_ID}`, { type: "updateMessage", messageId: message.id, data });
}

/** Handle a player's Key turn on Answer a Question (needs GM authority to edit the shared card). */
export async function handleSocket(payload) {
  if (game.user !== game.users.activeGM) return;
  const message = game.messages.get(payload.messageId);
  if (!message?.flags?.[SYSTEM_ID]) return;
  if (payload.type === "updateMessage") {
    // Only card content and this system's flags may be changed on a player's behalf.
    const allowed = Object.keys(payload.data ?? {}).every(k => k === "content" || k === `flags.${SYSTEM_ID}`);
    if (allowed) return message.update(payload.data);
    return;
  }
  if (payload.type === "questionKey") return registerQuestionKey(message, payload.actorUuid, payload.keyTitle);
}

/* -------------------------------------------------------------------------- */
/*  Moves                                                                     */
/* -------------------------------------------------------------------------- */

/** Entry point: use a move item owned by an actor. */
export async function useMove(actor, item) {
  if (!actor?.isOwner) return ui.notifications.warn(L("PA.Warn.notOwner"));
  const move = item.system;
  if (actor.system.retired) ui.notifications.info(L("PA.Warn.retired"));

  if (move.hasUses && move.uses.value <= 0) return ui.notifications.warn(F("PA.Warn.noUses", { name: item.name }));

  if (move.key === "nostalgic") return nostalgicMove(actor, item);
  if (move.rollType === "question" || move.key === "question") return answerQuestion(actor, item);
  if (move.rollType === "none") return postMoveCard(actor, item);
  return rollMove(actor, item);
}

async function spendUse(item) {
  if (item.system.hasUses) await item.update({ "system.uses.value": Math.max(0, item.system.uses.value - 1) });
}

/** Post a non-rolled move to chat. */
export async function postMoveCard(actor, item) {
  let addedGear = "";
  if (item.system.addsGear) {
    const data = await dialog({
      title: item.name,
      content: `<div class="form-group stacked"><label>${L("PA.Move.addsGearPrompt")}</label>
        <input type="text" name="name" autofocus></div>`,
      okLabel: L("PA.Gear.add"), okIcon: "fa-solid fa-couch"
    });
    addedGear = data?.name?.trim();
    if (!addedGear) return null;
    await actor.createEmbeddedDocuments("Item", [{ name: addedGear, type: "gear", img: "icons/svg/item-bag.svg" }]);
  }
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/move-card.hbs`, {
    actor, item, addedGear,
    trigger: item.system.trigger,
    description: await enrich(item.system.description, actor)
  });
  await spendUse(item);
  return createChat({ speaker: ChatMessage.getSpeaker({ actor }), content });
}

async function enrich(html, actor) {
  if (!html) return "";
  return TextEditor().enrichHTML(html, { relativeTo: actor, secrets: actor?.isOwner });
}

/** Standard roll dialog + roll. */
export async function rollMove(actor, item, { skipDialog = false } = {}) {
  const move = item.system;
  const sys = actor.system;
  const phase = currentPhase();
  const gear = actor.items.filter(i => i.type === "gear" && (!i.system.marked || i.system.reusable));
  const allConditions = Object.entries(sys.conditions)
    .filter(([, v]) => v?.trim())
    .map(([slot, name]) => ({ slot, name, positive: isFeelingGood(name) }));
  const conditions = allConditions.filter(c => !c.positive);
  const goodConditions = allConditions.filter(c => c.positive);
  const hooks = companionMoves(actor, item);
  const abilityChoices = Object.entries(PA.abilities).map(([k, label]) => ({
    key: k, label: L(label), value: sys.abilities[k], selected: k === move.ability
  }));

  let data = { ability: move.ability, bonus: 0, prompt: "", gear: "", advOther: false, disKeeper: false, cond: {}, good: {}, hook: {} };
  if (!skipDialog) {
    const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/dialog/roll.hbs`, {
      move, item, abilityChoices, gear, conditions, goodConditions,
      hooks: hooks.map(h => ({
        id: h.id, name: h.name, note: h.system.hook.note, usesLabel: h.system.usesLabel,
        effect: h.system.hook.effect, effectLabel: L(PA.hookEffects[h.system.hook.effect]),
        disabled: h.system.hook.effect === "advantage" && !move.allowAdvDis
      })),
      showAbility: move.rollType === "choose",
      fixedAbility: move.rollType === "ability" ? L(PA.abilities[move.ability]) : null,
      allowAdvDis: move.allowAdvDis,
      forced: move.forceMode !== "none" ? L(PA.forceModes[move.forceMode]) : null,
      isNight: move.key === "night",
      phaseMismatch: (move.key === "day" && phase === "night") || (move.key === "night" && phase === "day"),
      phaseLabel: L(PA.phases[phase])
    });
    const result = await dialog({ title: `${item.name} — ${actor.name}`, content });
    if (!result) return null;
    data = foundry.utils.mergeObject(data, foundry.utils.expandObject(result));
  }

  // Advantage / disadvantage: they never stack and cancel each other out.
  const gearItem = data.gear ? actor.items.get(data.gear) : null;
  const usedHooks = hooks.filter(h => data.hook?.[h.id]);
  const notes = usedHooks.filter(h => h.system.hook.effect === "note")
    .map(h => ({ name: h.name, note: h.system.hook.note }));
  const clearedGood = goodConditions.filter(c => data.good?.[c.slot]);
  let adv = false, dis = false;
  const advSources = [], disSources = [];
  if (move.allowAdvDis) {
    if (move.forceMode === "advantage") { adv = true; advSources.push(item.name); }
    if (move.forceMode === "disadvantage") { dis = true; disSources.push(item.name); }
    if (gearItem && !gearItem.system.autoCritical) { adv = true; advSources.push(gearItem.name); }
    for (const h of usedHooks.filter(h => h.system.hook.effect === "advantage")) { adv = true; advSources.push(h.name); }
    for (const c of clearedGood) { adv = true; advSources.push(c.name); }
    if (data.advOther) { adv = true; advSources.push(L("PA.Roll.otherAdvantage")); }
    const hindering = conditions.filter(c => data.cond?.[c.slot]).map(c => c.name);
    if (hindering.length) { dis = true; disSources.push(...hindering); }
    if (data.disKeeper) { dis = true; disSources.push(L("PA.Roll.keeperDisadvantage")); }
  }
  const critHook = usedHooks.find(h => h.system.hook.effect === "critical");
  const mode = adv && dis ? "normal" : adv ? "advantage" : dis ? "disadvantage" : "normal";

  // Modifier
  let abilityKey = null, abilityValue = 0;
  if (move.rollType === "choose" || move.rollType === "ability") {
    abilityKey = move.rollType === "choose" ? (data.ability || move.ability) : move.ability;
    abilityValue = sys.abilities[abilityKey] ?? 0;
  }
  const bonus = (Number(move.bonus) || 0) + (Number(data.bonus) || 0);

  const dice = { normal: "2d6", advantage: "3d6kh2", disadvantage: "3d6kl2" }[mode];
  const formula = `${dice} + @ability + @bonus`;
  const roll = await new Roll(formula, { ability: abilityValue, bonus }).evaluate();

  const autoCritical = !!gearItem?.system.autoCritical || !!critHook;
  const critSource = gearItem?.system.autoCritical ? gearItem.name : critHook?.name ?? "";
  let baseTier = tierFromTotal(roll.total);
  if (autoCritical) baseTier = 3;

  if (gearItem && !gearItem.system.reusable) await gearItem.update({ "system.marked": true });
  for (const c of clearedGood) await clearCondition(actor, c.slot);
  for (const h of usedHooks) await spendUse(h);
  await spendUse(item);

  const flags = {
    kind: "move",
    actorUuid: actor.uuid,
    itemUuid: item.uuid,
    moveName: item.name,
    moveKey: move.key,
    ability: abilityKey,
    mode, advSources, disSources,
    prompt: data.prompt ?? "",
    gearName: critSource,
    autoCritical,
    notes,
    allowKeys: move.allowKeys,
    baseTier,
    shifts: []
  };

  if (move.xpOnMiss && baseTier === 0) await addXP(actor, 1, { silent: true });

  const content = await renderRollCard(flags, roll);
  const msgData = {
    speaker: ChatMessage.getSpeaker({ actor }),
    content,
    rolls: [roll],
    sound: CONFIG.sounds.dice,
    flags: { [SYSTEM_ID]: flags }
  };
  applyMessageMode(msgData);
  return createChat(msgData);
}

/** Answer a Question: roll + clues incorporated − Complexity. Never with advantage/disadvantage. */
export async function answerQuestion(actor, item) {
  // Open Questions of active mysteries (from the public summary, so players can pick them too).
  const open = Mysteries.getActiveMysteries().flatMap(m => m.questions.filter(q => !q.answered && q.text)
    .map(q => ({ value: `${m.uuid}::${q.index}`, label: `${m.name} — ${q.text}`, text: q.text, complexity: q.complexity, cluesFound: m.cluesFound })));
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/dialog/question.hbs`, {
    item, open, complexity: open[0]?.complexity ?? game.settings.get(SYSTEM_ID, "lastComplexity") ?? 6,
    gathered: open[0]?.cluesFound ?? 0, question: open[0]?.text ?? ""
  });
  const data = await dialog({
    title: `${item.name}`, content,
    // Selecting a mystery Question fills in its Complexity, Clues found and text.
    render: (event, app) => {
      const root = app.element ?? event?.target?.element;
      const select = root?.querySelector("select[name=mysteryQuestion]");
      select?.addEventListener("change", () => {
        const q = open.find(o => o.value === select.value);
        if (!q) return;
        root.querySelector("input[name=complexity]").value = q.complexity;
        root.querySelector("input[name=gathered]").value = q.cluesFound;
        root.querySelector("input[name=question]").value = q.text;
      });
    }
  });
  if (!data) return null;
  const [mysteryUuid, questionIndex] = (data.mysteryQuestion ?? "").split("::");

  const complexity = Math.max(0, Number(data.complexity) || 0);
  const gathered = Math.max(0, Number(data.gathered) || 0);
  const clues = Math.max(0, Number(data.clues) || 0);
  if (game.user.isGM) game.settings.set(SYSTEM_ID, "lastComplexity", complexity);

  if (gathered < Math.ceil(complexity / 2)) {
    const go = await DialogV2.confirm({
      window: { title: item.name },
      content: `<p>${F("PA.Question.notEnough", { needed: Math.ceil(complexity / 2), gathered })}</p>`,
      rejectClose: false
    });
    if (!go) return null;
  }

  const roll = await new Roll("2d6 + @clues - @complexity", { clues, complexity }).evaluate();
  const required = game.actors
    .filter(a => a.type === "latchkey" && a.hasPlayerOwner && !a.system.retired)
    .map(a => a.uuid);
  if (!required.includes(actor.uuid)) required.push(actor.uuid);

  await spendUse(item);
  const flags = {
    kind: "question",
    actorUuid: actor.uuid,
    itemUuid: item.uuid,
    moveName: item.name,
    moveKey: "question",
    question: data.question ?? "",
    mysteryUuid: mysteryUuid || null,
    questionIndex: questionIndex !== undefined ? Number(questionIndex) : null,
    complexity, clues, gathered,
    mode: "normal", advSources: [], disSources: [],
    allowKeys: item.system.allowKeys,
    baseTier: tierFromTotal(roll.total),
    shifts: [],
    turnedBy: [],
    required
  };
  const msgData = {
    speaker: ChatMessage.getSpeaker({ actor }),
    content: await renderRollCard(flags, roll),
    rolls: [roll],
    sound: CONFIG.sounds.dice,
    flags: { [SYSTEM_ID]: flags }
  };
  applyMessageMode(msgData);
  return createChat(msgData);
}

/** Build the chat card HTML from the message flags. */
export async function renderRollCard(flags, roll) {
  const item = flags.itemUuid ? await fromUuid(flags.itemUuid) : null;
  const actor = flags.actorUuid ? await fromUuid(flags.actorUuid) : null;
  const tierIndex = Math.min(3, flags.baseTier + flags.shifts.length);
  const tier = PA.tiers[tierIndex];
  const history = [];
  for (let i = 0; i < flags.shifts.length; i++) {
    history.push({ label: L(PA.tierLabels[PA.tiers[Math.min(3, flags.baseTier + i)]]), key: flags.shifts[i] });
  }

  let resultText = item?.system?.resultFor?.(tier) ?? "";
  // Basic moves: 12+ also grants the 10+ outcome.
  const baseResult = tier === "critical" && item?.system?.results?.critical && item.system.results.strong
    ? item.system.results.strong : "";

  const turned = (flags.turnedBy ?? []).map(t => t.name);
  const required = flags.required ?? [];
  const waiting = [];
  for (const uuid of required) {
    if (!(flags.turnedBy ?? []).some(t => t.uuid === uuid)) {
      const a = await fromUuid(uuid);
      if (a) waiting.push(a.name);
    }
  }

  return renderTemplate(`systems/${SYSTEM_ID}/templates/chat/roll-card.hbs`, {
    flags,
    img: item?.img ?? actor?.img,
    abilityLabel: flags.ability ? L(PA.abilities[flags.ability]) : null,
    modeLabel: flags.mode !== "normal" ? L(`PA.Mode.${flags.mode}`) : null,
    tier,
    tierLabel: L(PA.tierLabels[tier]),
    history,
    baseResult: await enrich(baseResult, actor),
    resultText: await enrich(resultText, actor),
    rollHTML: await roll.render(),
    canTurnKey: flags.allowKeys && tierIndex < 3,
    isQuestion: flags.kind === "question",
    canRevealClue: flags.moveKey === "meddling" && tierIndex >= 1,
    canRecord: flags.kind === "question" && !!flags.mysteryUuid,
    turned, waiting
  });
}

export async function refreshCard(message, flags) {
  const roll = message.rolls[0];
  const content = await renderRollCard(flags, roll);
  return updateMessage(message, { content, [`flags.${SYSTEM_ID}`]: flags });
}

/* -------------------------------------------------------------------------- */
/*  Keys                                                                      */
/* -------------------------------------------------------------------------- */

/**
 * Ask which Key to turn and mark it. Returns the key title or null.
 * @param {Actor} actor
 * @param {object} [opts]
 * @param {string} [opts.reason]   Shown at the top of the dialog.
 */
export async function turnKey(actor, { reason = "" } = {}) {
  const sys = actor.system;
  const child = sys.keysChild.map((k, i) => ({ ...k, index: i })).filter(k => !k.marked);
  const desoIndex = sys.keysDesolation.findIndex(k => !k.marked);
  const deso = desoIndex >= 0 ? { ...sys.keysDesolation[desoIndex], index: desoIndex } : null;
  // Moves like I Am Error let a specific Key of Desolation be marked whenever you want.
  const anytimeTitles = actor.items.filter(i => i.type === "move" && i.system.keyAnytime)
    .map(i => ({ title: i.system.keyAnytime.trim().toLowerCase(), move: i.name }));
  const desoAnytime = sys.keysDesolation.map((k, i) => ({ ...k, index: i }))
    .filter(k => !k.marked && k.index !== desoIndex)
    .map(k => ({ ...k, via: anytimeTitles.find(a => a.title === k.title.trim().toLowerCase())?.move }))
    .filter(k => k.via);

  const mysteryKeys = Mysteries.getActiveMysteries().filter(m => m.key?.title && !m.key.used)
    .map(m => ({ uuid: m.uuid, mystery: m.name, title: m.key.title, text: m.key.text }));
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/dialog/turn-key.hbs`, {
    reason, child, deso, desoAnytime, mysteryKeys, allowMystery: true
  });
  const data = await dialog({ title: F("PA.Key.turnTitle", { name: actor.name }), content, okLabel: L("PA.Key.turn"), okIcon: "fa-solid fa-key" });
  if (!data?.choice) return null;

  let title = "", text = "", effect = "none", entry = null;
  if (data.choice.startsWith("child-")) {
    const i = Number(data.choice.slice(6));
    const list = foundry.utils.deepClone(sys.keysChild);
    list[i].marked = true; list[i].resolved = false;
    ({ title, text } = list[i]);
    await actor.update({ "system.keysChild": list });
  } else if (data.choice.startsWith("deso-")) {
    const i = Number(data.choice.slice(5));
    const list = foundry.utils.deepClone(sys.keysDesolation);
    list[i].marked = true; list[i].resolved = false;
    entry = list[i];
    ({ title, text, effect } = entry);
    await actor.update({ "system.keysDesolation": list });
  } else if (data.choice.startsWith("mkey::")) {
    const m = mysteryKeys.find(k => k.uuid === data.choice.slice(6));
    if (!m) return null;
    title = m.title; text = m.text;
    await actor.update({ "system.mysteryKeys": [...sys.mysteryKeys, { title: `${m.title} (${m.mystery})`, text, resolved: false }] });
    Mysteries.requestMysteryKey(m.uuid, actor.name);
  } else if (data.choice === "mystery") {
    title = data.mysteryTitle?.trim() || L("PA.Key.mystery");
    text = data.mysteryText?.trim() ?? "";
    await actor.update({ "system.mysteryKeys": [...sys.mysteryKeys, { title, text, resolved: false }] });
  } else return null;

  const effectNote = await applyKeyEffect(actor, effect, entry);

  const content2 = await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/key-card.hbs`, {
    actor, title, text, reason, effect, effectNote, retire: effect === "retire", unlock: effect === "unlockDawn"
  });
  await createChat({ speaker: ChatMessage.getSpeaker({ actor }), content: content2 });
  return title;
}

async function applyKeyEffect(actor, effect, entry) {
  if (effect === "abilityDown" && entry) {
    const key = entry.ability;
    const shield = actor.items.find(i => i.type === "move" && i.system.protectsKey
      && i.system.protectsKey.trim().toLowerCase() === entry.title.trim().toLowerCase());
    if (shield) return F("PA.Key.protected", { move: shield.name, ability: L(PA.abilities[key]) });
    const value = Math.max(PA.abilityMin, actor.system.abilities[key] - 1);
    await actor.update({ [`system.abilities.${key}`]: value });
    return F("PA.Key.abilityDown", { ability: L(PA.abilities[key]), value });
  }
  if (effect === "unlockDawn") {
    const list = foundry.utils.deepClone(actor.system.dawnQuestions);
    for (const q of list) if (q.kind === "unlockable") { q.unlocked = true; q.marked = true; }
    await actor.update({ "system.dawnQuestions": list });
  } else if (effect === "retire") {
    await actor.update({ "system.retired": true });
  }
}

/** "Turn a Key" button on a roll card. */
export async function turnKeyOnMessage(message, actor) {
  const flags = foundry.utils.deepClone(message.getFlag(SYSTEM_ID, "kind") ? message.flags[SYSTEM_ID] : null);
  if (!flags) return;
  if (!actor?.isOwner) return ui.notifications.warn(L("PA.Warn.notOwner"));

  if (flags.kind === "question") {
    if ((flags.turnedBy ?? []).some(t => t.uuid === actor.uuid)) return ui.notifications.info(L("PA.Question.alreadyTurned"));
    const title = await turnKey(actor, { reason: F("PA.Key.reasonQuestion", { move: flags.moveName }) });
    if (!title) return;
    if (message.canUserModify(game.user, "update")) return registerQuestionKey(message, actor.uuid, title);
    if (!game.users.activeGM) return ui.notifications.warn(L("PA.Warn.noGM"));
    game.socket.emit(`system.${SYSTEM_ID}`, { type: "questionKey", messageId: message.id, actorUuid: actor.uuid, keyTitle: title });
    return;
  }

  if (flags.actorUuid !== actor.uuid) return ui.notifications.warn(L("PA.Warn.notYourRoll"));
  if (flags.baseTier + flags.shifts.length >= 3) return;
  const title = await turnKey(actor, { reason: F("PA.Key.reasonRoll", { move: flags.moveName }) });
  if (!title) return;
  flags.shifts.push(title);
  return refreshCard(message, flags);
}

async function registerQuestionKey(message, actorUuid, keyTitle) {
  const flags = foundry.utils.deepClone(message.flags[SYSTEM_ID]);
  const actor = await fromUuid(actorUuid);
  flags.turnedBy ??= [];
  if (flags.turnedBy.some(t => t.uuid === actorUuid)) return;
  flags.turnedBy.push({ uuid: actorUuid, name: actor?.name ?? "?", key: keyTitle });
  const everyone = flags.required.every(u => flags.turnedBy.some(t => t.uuid === u));
  if (everyone && flags.baseTier + flags.shifts.length < 3) {
    flags.shifts.push(flags.turnedBy.map(t => `${t.name}: ${t.key}`).join(" · "));
    flags.turnedBy = [];
  }
  return refreshCard(message, flags);
}

/** GM override: apply a tier shift on Answer a Question even if not everyone turned. */
export async function forceQuestionShift(message) {
  if (!game.user.isGM) return;
  const flags = foundry.utils.deepClone(message.flags[SYSTEM_ID]);
  if (flags.baseTier + flags.shifts.length >= 3) return;
  flags.shifts.push(flags.turnedBy?.length ? flags.turnedBy.map(t => `${t.name}: ${t.key}`).join(" · ") : L("PA.Question.keeperShift"));
  flags.turnedBy = [];
  return refreshCard(message, flags);
}

/* -------------------------------------------------------------------------- */
/*  Conditions                                                                */
/* -------------------------------------------------------------------------- */

export async function takeCondition(actor, name = null) {
  if (!name) {
    const data = await dialog({
      title: L("PA.Condition.take"),
      content: `<div class="form-group"><label>${L("PA.Condition.name")}</label>
        <input type="text" name="name" autofocus placeholder="${esc(L("PA.Condition.placeholder"))}"></div>`,
      okLabel: L("PA.Condition.take"), okIcon: "fa-solid fa-heart-crack"
    });
    name = data?.name?.trim();
    if (!name) return;
  }
  const slots = actor.system.conditions;
  const free = ["c1", "c2", "c3"].find(k => !slots[k]?.trim());
  if (free) {
    await actor.update({ [`system.conditions.${free}`]: name });
    return createChat({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<div class="pa-card pa-small"><i class="fa-solid fa-heart-crack"></i> ${F("PA.Condition.taken", { name: esc(name) })}</div>`
    });
  }
  // A fourth Condition: turn a Key instead.
  ui.notifications.info(L("PA.Condition.fourth"));
  return turnKey(actor, { reason: F("PA.Condition.fourthReason", { name }) });
}

export async function clearCondition(actor, slot) {
  const name = actor.system.conditions[slot];
  if (!name) return;
  await actor.update({ [`system.conditions.${slot}`]: "" });
}

/* -------------------------------------------------------------------------- */
/*  Nostalgic Move                                                            */
/* -------------------------------------------------------------------------- */

export async function nostalgicMove(actor, item) {
  const sys = actor.system;
  const others = game.actors.filter(a => a.type === "latchkey" && a !== actor).map(a => ({ id: a.id, name: a.name }));
  const conditions = Object.entries(sys.conditions).filter(([, v]) => v?.trim()).map(([k, v]) => ({ slot: k, name: v }));
  const takesYouBack = Object.values(sys.takesYouBack).filter(Boolean);
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/dialog/nostalgic.hbs`, {
    item, others, conditions, takesYouBack,
    description: await enrich(item.system.description, actor)
  });
  const data = await dialog({ title: `${item.name} — ${actor.name}`, content, okLabel: L("PA.Nostalgic.go"), okIcon: "fa-solid fa-film" });
  if (!data) return;

  const cleared = [];
  for (const c of conditions) {
    if (data[`clear_${c.slot}`]) { cleared.push(c.name); await clearCondition(actor, c.slot); }
  }
  const partner = data.partner ? game.actors.get(data.partner) : null;
  const waxing = data.role === "waxing";
  await spendUse(item);

  // Companion moves such as Thank You for Being a Friend.
  const hooks = actor.items.filter(i => i.type === "move" && i.system.hook.move === "nostalgic"
    && (!i.system.hasUses || i.system.uses.value > 0));
  for (const h of hooks) await spendUse(h);
  const notes = hooks.map(h => ({ name: h.name, note: h.system.hook.note }));

  const content2 = await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/nostalgic-card.hbs`, {
    actor, item, partner, waxing, topic: data.topic, cleared, notes,
    offerFeelingGood: !!(partner && hooks.length),
    feelingGood: L("PA.Condition.feelingGood"),
    getsClue: !waxing
  });
  return createChat({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: content2,
    flags: { [SYSTEM_ID]: { kind: "nostalgic", actorUuid: actor.uuid, partnerUuid: partner?.uuid ?? null } }
  });
}

/* -------------------------------------------------------------------------- */
/*  XP, Dawn and Advancements                                                 */
/* -------------------------------------------------------------------------- */

export async function addXP(actor, amount = 1, { silent = false } = {}) {
  const before = actor.system.xp;
  const after = Math.min(PA.maxXP, before + amount);
  const lost = before + amount - after;
  await actor.update({ "system.xp": after });
  if (after >= PA.maxXP) {
    if (actor.system.advancements.every(a => a.marked)) ui.notifications.info(F("PA.XP.maxedOut", { name: actor.name }));
    else ui.notifications.info(F("PA.XP.full", { name: actor.name }));
  }
  if (lost > 0) ui.notifications.warn(F("PA.XP.lost", { n: lost }));
  if (!silent && after !== before) {
    await createChat({
      speaker: ChatMessage.getSpeaker({ actor }),
      content: `<div class="pa-card pa-small"><i class="fa-solid fa-star"></i> ${F("PA.XP.gained", { n: after - before, xp: after, max: PA.maxXP })}</div>`
    });
  }
}

export async function dawnPhase(actor) {
  const sys = actor.system;
  const questions = sys.dawnQuestions.map((q, i) => ({ ...q, index: i })).filter(q => q.marked && q.unlocked);
  if (!questions.length) return ui.notifications.warn(L("PA.Dawn.none"));
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/dialog/dawn.hbs`, { questions });
  const data = await dialog({ title: F("PA.Dawn.title", { name: actor.name }), content, okLabel: L("PA.Dawn.confirm"), okIcon: "fa-solid fa-sun" });
  if (!data) return;
  const yes = questions.filter(q => data[`q${q.index}`]);
  const content2 = await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/dawn-card.hbs`, {
    actor, yes, no: questions.filter(q => !data[`q${q.index}`])
  });
  await createChat({ speaker: ChatMessage.getSpeaker({ actor }), content: content2 });
  if (yes.length) await addXP(actor, yes.length, { silent: true });
  const unresolved = actor.system.unresolvedKeys;
  if (unresolved.length) ui.notifications.info(F("PA.Key.unresolvedReminder", { n: unresolved.length }));
}

/** Latchkey moves nobody has taken yet (a move can never belong to two Latchkeys). */
async function availableLatchkeyMoves() {
  const key = n => n.toLowerCase().replace(/[^a-z0-9]/g, "");
  const taken = new Set(game.actors.filter(a => a.type === "latchkey")
    .flatMap(a => a.items.filter(i => i.type === "move" && i.system.moveType === "latchkey").map(i => key(i.name))));
  const lang = (game.i18n.lang ?? "en").toLowerCase().startsWith("pt") ? "pt" : "en";
  const packs = [game.packs.get("world.pa-latchkey-moves"), game.packs.get(`${SYSTEM_ID}.latchkey-moves-${lang}`)].filter(Boolean);
  const out = [];
  const add = (uuid, name) => {
    if (taken.has(key(name)) || out.some(o => key(o.name) === key(name))) return;
    out.push({ uuid, name });
  };
  for (const pack of packs) for (const e of await pack.getIndex()) add(e.uuid, e.name);
  for (const i of game.items.filter(i => i.type === "move" && i.system.moveType === "latchkey")) add(i.uuid, i.name);
  return out.sort((x, y) => x.name.localeCompare(y.name));
}

export async function advance(actor) {
  const sys = actor.system;
  if (sys.xp < PA.maxXP) return ui.notifications.warn(L("PA.Adv.needXP"));
  const options = sys.advancements.map((a, i) => ({ ...a, index: i, effectLabel: a.effect !== "none" ? L(PA.advancementEffects[a.effect]) : "" }))
    .filter(a => !a.marked);
  if (!options.length) return ui.notifications.warn(L("PA.Adv.none"));
  const abilities = Object.entries(PA.abilities).map(([k, label]) => ({
    key: k, label: L(label), value: sys.abilities[k], capped: sys.abilities[k] >= PA.abilityMax
  }));
  const moves = options.some(o => o.effect === "move") ? await availableLatchkeyMoves() : [];
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/dialog/advance.hbs`, {
    options, abilities, moves,
    needsAbility: options.some(o => o.effect === "ability"),
    needsMove: options.some(o => o.effect === "move")
  });
  const data = await dialog({ title: F("PA.Adv.title", { name: actor.name }), content, okLabel: L("PA.Adv.confirm"), okIcon: "fa-solid fa-arrow-up" });
  if (!data || data.choice === undefined || data.choice === "") return;

  const index = Number(data.choice);
  const list = foundry.utils.deepClone(sys.advancements);
  const adv = list[index];
  if (!adv) return;
  const update = { "system.xp": 0 };
  let extra = "";
  let afterUpdate = null;

  if (adv.effect === "ability") {
    const key = data.ability;
    if (!key || sys.abilities[key] >= PA.abilityMax) return ui.notifications.warn(L("PA.Adv.pickAbility"));
    update[`system.abilities.${key}`] = sys.abilities[key] + 1;
    extra = F("PA.Adv.abilityUp", { ability: L(PA.abilities[key]), value: sys.abilities[key] + 1 });
  } else if (adv.effect === "move") {
    const source = data.move ? await fromUuid(data.move) : null;
    if (!source) return ui.notifications.warn(L("PA.Adv.pickMove"));
    afterUpdate = async () => {
      const itemData = source.toObject();
      delete itemData._id;
      await actor.createEmbeddedDocuments("Item", [itemData]);
    };
    extra = F("PA.Adv.moveAdded", { name: source.name });
  } else if (adv.effect === "customMove") {
    afterUpdate = async () => {
      const [item] = await actor.createEmbeddedDocuments("Item", [{ name: L("PA.Move.new"), type: "move", system: { moveType: "latchkey", rollType: "none" } }]);
      item?.sheet.render(true);
    };
    extra = L("PA.Adv.customMoveCreated");
  } else if (adv.effect === "unmarkGear") {
    const marked = actor.items.filter(i => i.type === "gear" && i.system.marked);
    afterUpdate = async () => {
      if (marked.length) await actor.updateEmbeddedDocuments("Item", marked.map(i => ({ _id: i.id, "system.marked": false })));
    };
    extra = F("PA.Adv.gearUnmarked", { n: marked.length });
  }

  adv.marked = true;
  update["system.advancements"] = list;
  await actor.update(update);
  if (afterUpdate) await afterUpdate();
  await createChat({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<div class="pa-card pa-small"><h3><i class="fa-solid fa-arrow-up"></i> ${L("PA.Adv.advanced")}</h3><p>${esc(adv.text)}</p>${extra ? `<p><em>${esc(extra)}</em></p>` : ""}</div>`
  });
}

/* -------------------------------------------------------------------------- */
/*  Chat card listeners                                                       */
/* -------------------------------------------------------------------------- */

export function onRenderChatMessage(message, html) {
  const flags = message.flags?.[SYSTEM_ID];
  if (!flags?.kind) return;
  const el = html instanceof HTMLElement ? html : html[0];
  if (!el) return;

  for (const btn of el.querySelectorAll("[data-pa-action]")) {
    const action = btn.dataset.paAction;
    if (action === "turnKey") {
      let actor = null;
      if (flags.kind === "question") {
        actor = game.user.character?.type === "latchkey" ? game.user.character
          : game.actors.find(a => a.type === "latchkey" && a.isOwner && flags.required?.includes(a.uuid) && !game.user.isGM);
        if (!actor && !game.user.isGM) { btn.remove(); continue; }
      } else {
        actor = fromUuidSync(flags.actorUuid);
        if (!actor?.isOwner) { btn.remove(); continue; }
      }
      btn.addEventListener("click", async ev => {
        ev.preventDefault();
        if (!actor && game.user.isGM) actor = await pickLatchkey(flags.required);
        if (actor) turnKeyOnMessage(message, actor);
      });
    } else if (action === "revealClue" || action === "recordAnswer") {
      if (!game.user.isGM) { btn.remove(); continue; }
      btn.addEventListener("click", ev => {
        ev.preventDefault();
        if (action === "revealClue") Mysteries.revealClueOnMessage(message, refreshCard);
        else Mysteries.recordAnswer(message, refreshCard);
      });
    } else if (action === "feelingGood") {
      const partner = flags.partnerUuid ? fromUuidSync(flags.partnerUuid) : null;
      if (!partner?.isOwner) { btn.remove(); continue; }
      btn.addEventListener("click", ev => { ev.preventDefault(); takeCondition(partner, L("PA.Condition.feelingGood")); });
    } else if (action === "forceShift") {
      if (!game.user.isGM) { btn.remove(); continue; }
      btn.addEventListener("click", ev => { ev.preventDefault(); forceQuestionShift(message); });
    }
  }
}

async function pickLatchkey(uuids = []) {
  const actors = uuids.map(u => fromUuidSync(u)).filter(Boolean);
  if (!actors.length) return null;
  const content = `<div class="form-group"><label>${L("PA.Question.whichLatchkey")}</label><select name="actor">${
    actors.map(a => `<option value="${a.uuid}">${esc(a.name)}</option>`).join("")}</select></div>`;
  const data = await dialog({ title: L("PA.Key.turn"), content, okLabel: L("PA.Key.turn"), okIcon: "fa-solid fa-key" });
  return data?.actor ? fromUuidSync(data.actor) : null;
}

/* -------------------------------------------------------------------------- */
/*  Sessions and per-phase uses                                               */
/* -------------------------------------------------------------------------- */

async function resetUses(kind) {
  const touched = [];
  for (const actor of game.actors.filter(a => a.type === "latchkey")) {
    const updates = actor.items
      .filter(i => i.type === "move" && i.system.hasUses && i.system.uses.reset === kind && i.system.uses.value < i.system.uses.max)
      .map(i => ({ _id: i.id, "system.uses.value": i.system.uses.max }));
    if (updates.length) { await actor.updateEmbeddedDocuments("Item", updates); touched.push(actor.name); }
  }
  return touched;
}

/** Keeper: start a new session — refresh "once per session" moves and post reminders. */
export async function newSession() {
  if (!game.user.isGM) return ui.notifications.warn(L("PA.Session.gmOnly"));
  await resetUses("session");
  const rows = [];
  for (const actor of game.actors.filter(a => a.type === "latchkey" && !a.system.retired)) {
    const reminders = actor.items.filter(i => i.type === "move" && i.system.sessionReminder).map(i => i.name);
    const pending = actor.system.unresolvedKeys.map(k => k.title);
    if (reminders.length || pending.length) rows.push({ name: actor.name, reminders, pending });
  }
  const content = await renderTemplate(`systems/${SYSTEM_ID}/templates/chat/session-card.hbs`, { rows });
  await createChat({ content, speaker: { alias: L("PA.Session.keeper") } });
}

/** Called when the phase changes to Day: refresh "once per Day phase" moves. */
export async function onPhaseChange(phase) {
  if (game.user !== game.users.activeGM || phase !== "day") return;
  const touched = await resetUses("day");
  if (touched.length) ui.notifications.info(F("PA.Session.dayReset", { names: touched.join(", ") }));
}

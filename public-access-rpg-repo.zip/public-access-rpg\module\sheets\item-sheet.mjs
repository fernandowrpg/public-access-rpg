import { PA, SYSTEM_ID, localizeMap } from "../config.mjs";
import * as ImportTools from "../import-tools.mjs";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ItemSheetV2 } = foundry.applications.sheets;

export class PAItemSheet extends HandlebarsApplicationMixin(ItemSheetV2) {
  static DEFAULT_OPTIONS = {
    classes: ["public-access", "sheet", "item"],
    position: { width: 600, height: 720 },
    window: { resizable: true, icon: "fa-solid fa-tv" },
    form: { submitOnChange: true, closeOnSubmit: false },
    actions: {
      editImage: PAItemSheet.#onEditImage,
      importText: PAItemSheet.#onImportText,
      saveKeeper: PAItemSheet.#onSaveKeeper
    }
  };

  static PARTS = {
    body: { template: `systems/${SYSTEM_ID}/templates/item/item-sheet.hbs`, scrollable: [""] }
  };

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const item = this.document;
    const TE = foundry.applications.ux.TextEditor.implementation;
    const enrich = html => TE.enrichHTML(html ?? "", { relativeTo: item, secrets: item.isOwner });
    Object.assign(context, {
      item,
      system: item.system,
      source: item._source.system,
      fields: item.system.schema.fields,
      isMove: item.type === "move",
      isGear: item.type === "gear",
      isGM: game.user.isGM,
      canSaveKeeper: game.user.isGM && item.type === "move" && item.system.moveType !== "basic",
      editable: this.isEditable,
      moveTypes: localizeMap(PA.moveTypes),
      rollTypes: localizeMap(PA.rollTypes),
      abilities: localizeMap(PA.abilities),
      forceModes: localizeMap(PA.forceModes),
      moveKeys: localizeMap(PA.moveKeys),
      hookMoves: localizeMap(PA.hookMoves),
      hookEffects: localizeMap(PA.hookEffects),
      usesReset: localizeMap(PA.usesReset),
      boostAbilities: { "": "—", ...localizeMap(PA.abilities) },
      showAbility: ["ability", "choose"].includes(item.system.rollType),
      enrichedDescription: await enrich(item.system.description)
    });
    return context;
  }

  static #onImportText() {
    return ImportTools.importMoveText(this.document);
  }

  static #onSaveKeeper() {
    return ImportTools.saveMoveToKeeperPack(this.document);
  }

  static async #onEditImage() {
    if (!this.isEditable) return;
    const FP = foundry.applications.apps.FilePicker.implementation;
    return new FP({ type: "image", current: this.document.img, callback: path => this.document.update({ img: path }) }).browse();
  }
}

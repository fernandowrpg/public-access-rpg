import { PA, SYSTEM_ID } from "../config.mjs";
import { getSheetTemplate, buildBasicMoves } from "../defaults.mjs";
import * as Rolls from "../rolls.mjs";
import { PhaseClock } from "../apps/phase-clock.mjs";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
const L = key => game.i18n.localize(key);
const F = (key, data) => game.i18n.format(key, data);

const LIST_DEFAULTS = {
  dawnQuestions: () => ({ text: "", kind: "elective", marked: false, unlocked: true }),
  keysChild: () => ({ title: "", text: "", marked: false, resolved: false }),
  keysDesolation: () => ({ title: "", text: "", marked: false, resolved: false, effect: "none", ability: "reason" }),
  mysteryKeys: () => ({ title: "", text: "", resolved: false }),
  advancements: () => ({ text: "", marked: false, effect: "none" })
};

export class LatchkeySheet extends HandlebarsApplicationMixin(ActorSheetV2) {
  /** Whether list structures (questions, keys, advancements) are being edited. */
  #editMode = false;
  /** Expanded move descriptions (by item id). */
  #expanded = new Set();

  static DEFAULT_OPTIONS = {
    classes: ["public-access", "sheet", "actor", "latchkey"],
    position: { width: 820, height: 860 },
    window: { resizable: true, icon: "fa-solid fa-tv" },
    form: { submitOnChange: true, closeOnSubmit: false },
    actions: {
      editImage: LatchkeySheet.#onEditImage,
      toggleEdit: LatchkeySheet.#onToggleEdit,
      useMove: LatchkeySheet.#onUseMove,
      toggleMove: LatchkeySheet.#onToggleMove,
      createItem: LatchkeySheet.#onCreateItem,
      editItem: LatchkeySheet.#onEditItem,
      deleteItem: LatchkeySheet.#onDeleteItem,
      toggleGear: LatchkeySheet.#onToggleGear,
      useUse: LatchkeySheet.#onUseUse,
      takeCondition: LatchkeySheet.#onTakeCondition,
      clearCondition: LatchkeySheet.#onClearCondition,
      turnKey: LatchkeySheet.#onTurnKey,
      toggleListFlag: LatchkeySheet.#onToggleListFlag,
      addListEntry: LatchkeySheet.#onAddListEntry,
      removeListEntry: LatchkeySheet.#onRemoveListEntry,
      moveListEntry: LatchkeySheet.#onMoveListEntry,
      setXP: LatchkeySheet.#onSetXP,
      dawn: LatchkeySheet.#onDawn,
      advance: LatchkeySheet.#onAdvance,
      applyTemplate: LatchkeySheet.#onApplyTemplate,
      restoreBasics: LatchkeySheet.#onRestoreBasics,
      cyclePhase: LatchkeySheet.#onCyclePhase,
      unretire: LatchkeySheet.#onUnretire,
      newSession: () => Rolls.newSession()
    }
  };

  static PARTS = {
    header: { template: `systems/${SYSTEM_ID}/templates/actor/header.hbs` },
    tabs: { template: "templates/generic/tab-navigation.hbs" },
    main: { template: `systems/${SYSTEM_ID}/templates/actor/main.hbs`, scrollable: [""] },
    keys: { template: `systems/${SYSTEM_ID}/templates/actor/keys.hbs`, scrollable: [""] },
    growth: { template: `systems/${SYSTEM_ID}/templates/actor/growth.hbs`, scrollable: [""] },
    corner: { template: `systems/${SYSTEM_ID}/templates/actor/corner.hbs`, scrollable: [""] },
    bio: { template: `systems/${SYSTEM_ID}/templates/actor/bio.hbs`, scrollable: [""] }
  };

  static TABS = {
    primary: {
      tabs: [
        { id: "main", icon: "fa-solid fa-dice" },
        { id: "keys", icon: "fa-solid fa-key" },
        { id: "growth", icon: "fa-solid fa-sun" },
        { id: "corner", icon: "fa-solid fa-couch" },
        { id: "bio", icon: "fa-solid fa-book-open" }
      ],
      initial: "main",
      labelPrefix: "PA.Tabs"
    }
  };

  get title() {
    return this.document.name;
  }

  /* ------------------------------------------------------------------------ */

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const actor = this.document;
    const sys = actor.system;
    const phase = Rolls.currentPhase();

    const moves = actor.items.filter(i => i.type === "move").sort((a, b) => (a.sort || 0) - (b.sort || 0));
    const decorate = async m => ({
      id: m.id, name: m.name, img: m.img, system: m.system,
      rollable: m.system.rollType !== "none" || m.system.key === "nostalgic",
      abilityLabel: m.system.rollType === "ability" ? L(PA.abilities[m.system.ability]) : m.system.rollType === "choose" ? L("PA.RollType.chooseShort") : "",
      expanded: this.#expanded.has(m.id),
      phaseMatch: (m.system.key === "day" && phase === "day") || (m.system.key === "night" && phase === "night"),
      phaseOff: (m.system.key === "day" && phase === "night") || (m.system.key === "night" && phase === "day"),
      usesLabel: m.system.usesLabel,
      hookLabel: m.system.isHook ? `${L(PA.hookMoves[m.system.hook.move])} · ${L(PA.hookEffects[m.system.hook.effect])}` : "",
      pips: m.system.hasUses ? Array.from({ length: m.system.uses.max }, (_, i) => i < m.system.uses.value) : null,
      enrichedDescription: this.#expanded.has(m.id)
        ? await foundry.applications.ux.TextEditor.implementation.enrichHTML(m.system.description, { relativeTo: m, secrets: actor.isOwner })
        : ""
    });
    const all = await Promise.all(moves.map(decorate));

    const electiveMarked = sys.dawnQuestions.filter(q => q.kind === "elective" && q.marked).length;
    const desoNext = sys.keysDesolation.findIndex(k => !k.marked);

    context.tabs ??= this._prepareTabs("primary");

    Object.assign(context, {
      actor, system: sys, source: actor._source.system,
      fields: sys.schema.fields,
      editMode: this.#editMode,
      editable: this.isEditable,
      isGM: game.user.isGM,
      phase, phaseLabel: L(PA.phases[phase]),
      tapesWatched: game.settings.get(SYSTEM_ID, "tapesWatched"),
      abilities: Object.entries(PA.abilities).map(([k, label]) => ({
        key: k, label: L(label), value: sys.abilities[k],
        hint: L(`PA.AbilityHint.${k}`)
      })),
      conditionSlots: ["c1", "c2", "c3"].map(k => ({ key: k, value: sys.conditions[k] })),
      conditionsFull: sys.conditionList.length >= PA.maxConditions,
      basicMoves: all.filter(m => m.system.moveType === "basic"),
      latchkeyMoves: all.filter(m => m.system.moveType === "latchkey"),
      customMoves: all.filter(m => m.system.moveType === "custom"),
      gear: actor.items.filter(i => i.type === "gear").sort((a, b) => (a.sort || 0) - (b.sort || 0)),
      xpBoxes: Array.from({ length: PA.maxXP }, (_, i) => ({ value: i + 1, filled: i < sys.xp })),
      canAdvance: sys.canAdvance,
      dawnQuestions: sys.dawnQuestions.map((q, i) => ({
        ...q, index: i,
        locked: q.kind === "always" || (q.kind === "unlockable" && q.unlocked),
        hidden: q.kind === "unlockable" && !q.unlocked && !this.#editMode,
        kindLabel: L(PA.dawnKinds[q.kind])
      })),
      electiveMarked, maxElective: PA.maxElectiveDawn,
      keysChild: sys.keysChild.map((k, i) => ({ ...k, index: i })),
      keysDesolation: sys.keysDesolation.map((k, i) => ({
        ...k, index: i, next: i === desoNext,
        effectLabel: k.effect === "abilityDown" ? `${L(PA.keyEffects[k.effect])}: ${L(PA.abilities[k.ability])}` : k.effect !== "none" ? L(PA.keyEffects[k.effect]) : ""
      })),
      mysteryKeys: sys.mysteryKeys.map((k, i) => ({ ...k, index: i })),
      advancements: sys.advancements.map((a, i) => ({
        ...a, index: i, effectLabel: a.effect !== "none" ? L(PA.advancementEffects[a.effect]) : ""
      })),
      unresolvedCount: sys.unresolvedKeys.length,
      dawnKinds: Object.fromEntries(Object.entries(PA.dawnKinds).map(([k, v]) => [k, L(v)])),
      abilityChoices: Object.fromEntries(Object.entries(PA.abilities).map(([k, v]) => [k, L(v)])),
      keyEffects: Object.fromEntries(Object.entries(PA.keyEffects).map(([k, v]) => [k, L(v)])),
      advEffects: Object.fromEntries(Object.entries(PA.advancementEffects).map(([k, v]) => [k, L(v)])),
      enrichedBio: await foundry.applications.ux.TextEditor.implementation.enrichHTML(sys.biography, { relativeTo: actor, secrets: actor.isOwner }),
      enrichedNotes: await foundry.applications.ux.TextEditor.implementation.enrichHTML(sys.notes, { relativeTo: actor, secrets: actor.isOwner })
    });
    return context;
  }

  async _preparePartContext(partId, context, options) {
    context = await super._preparePartContext(partId, context, options);
    if (context.tabs?.[partId]) context.tab = context.tabs[partId];
    return context;
  }

  /** Array-field inputs are not named form fields: update the whole array on change. */
  _onRender(context, options) {
    super._onRender(context, options);
    // Partial re-renders keep untouched parts, so only bind each element once.
    for (const input of this.element.querySelectorAll("[data-list][data-field]:not([data-pa-bound])")) {
      input.dataset.paBound = "1";
      input.addEventListener("change", this.#onListFieldChange.bind(this));
    }
    for (const input of this.element.querySelectorAll("input[data-item-field]:not([data-pa-bound])")) {
      input.dataset.paBound = "1";
      input.addEventListener("change", this.#onItemFieldChange.bind(this));
    }
  }

  async #onListFieldChange(event) {
    event.stopPropagation();
    const el = event.currentTarget;
    const { list, index, field } = el.dataset;
    const arr = foundry.utils.deepClone(this.document.system[list]);
    if (!arr[index]) return;
    arr[index][field] = el.type === "checkbox" ? el.checked : el.value;
    await this.document.update({ [`system.${list}`]: arr });
  }

  async #onItemFieldChange(event) {
    event.stopPropagation();
    const el = event.currentTarget;
    const item = this.document.items.get(el.closest("[data-item-id]")?.dataset.itemId);
    if (!item) return;
    const value = el.type === "checkbox" ? el.checked : el.type === "number" ? Number(el.value) : el.value;
    await item.update({ [el.dataset.itemField]: value });
  }

  /** Only accept this system's item types. */
  async _onDropItem(event, item) {
    if (!["move", "gear"].includes(item.type)) return null;
    return super._onDropItem(event, item);
  }

  /* ------------------------------------------------------------------------ */
  /*  Actions                                                                 */
  /* ------------------------------------------------------------------------ */

  static #item(target) {
    return this.document.items.get(target.closest("[data-item-id]")?.dataset.itemId);
  }

  static async #onEditImage(event, target) {
    if (!this.isEditable) return;
    const FP = foundry.applications.apps.FilePicker.implementation;
    const fp = new FP({
      type: "image",
      current: this.document.img,
      callback: path => this.document.update({ img: path })
    });
    return fp.browse();
  }

  static #onToggleEdit() {
    this.#editMode = !this.#editMode;
    this.render();
  }

  static async #onUseMove(event, target) {
    const item = LatchkeySheet.#item.call(this, target);
    if (!item) return;
    if (event.shiftKey && item.system.isRollable && item.system.rollType !== "question") {
      return Rolls.rollMove(this.document, item, { skipDialog: true });
    }
    return Rolls.useMove(this.document, item);
  }

  static #onToggleMove(event, target) {
    const id = target.closest("[data-item-id]")?.dataset.itemId;
    if (this.#expanded.has(id)) this.#expanded.delete(id); else this.#expanded.add(id);
    this.render({ parts: ["main"] });
  }

  static async #onCreateItem(event, target) {
    const type = target.dataset.type;
    const moveType = target.dataset.moveType;
    const name = type === "gear" ? L("PA.Gear.new") : L("PA.Move.new");
    const data = { name, type };
    if (type === "move") data.system = { moveType: moveType ?? "latchkey" };
    const [item] = await this.document.createEmbeddedDocuments("Item", [data]);
    if (type === "move") item?.sheet.render(true);
  }

  static #onEditItem(event, target) {
    LatchkeySheet.#item.call(this, target)?.sheet.render(true);
  }

  static async #onDeleteItem(event, target) {
    const item = LatchkeySheet.#item.call(this, target);
    if (!item) return;
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: L("PA.Delete") },
      content: `<p>${F("PA.DeleteConfirm", { name: item.name })}</p>`,
      rejectClose: false
    });
    if (ok) await item.delete();
  }

  static async #onToggleGear(event, target) {
    const item = LatchkeySheet.#item.call(this, target);
    if (item) await item.update({ "system.marked": !item.system.marked });
  }

  static async #onUseUse(event, target) {
    const item = LatchkeySheet.#item.call(this, target);
    if (!item) return;
    const i = Number(target.dataset.index);
    const value = item.system.uses.value === i + 1 ? i : i + 1;
    await item.update({ "system.uses.value": value });
  }

  static #onTakeCondition() {
    return Rolls.takeCondition(this.document);
  }

  static #onClearCondition(event, target) {
    return Rolls.clearCondition(this.document, target.dataset.slot);
  }

  static #onTurnKey() {
    return Rolls.turnKey(this.document);
  }

  /** Toggle a boolean on an array entry, enforcing the game's rules outside edit mode. */
  static async #onToggleListFlag(event, target) {
    const { list, field } = target.dataset;
    const index = Number(target.dataset.index);
    const sys = this.document.system;
    const arr = foundry.utils.deepClone(sys[list]);
    const entry = arr[index];
    if (!entry) return;

    if (!this.#editMode) {
      if (list === "dawnQuestions" && field === "marked") {
        if (entry.kind !== "elective") return ui.notifications.info(L("PA.Dawn.fixed"));
        const count = arr.filter(q => q.kind === "elective" && q.marked).length;
        if (!entry.marked && count >= PA.maxElectiveDawn) return ui.notifications.warn(F("PA.Dawn.maxElective", { n: PA.maxElectiveDawn }));
      }
      if ((list === "keysChild" || list === "keysDesolation") && field === "marked") {
        if (entry.marked) return ui.notifications.info(L("PA.Key.cannotUnmark"));
        return Rolls.turnKey(this.document);
      }
      if (list === "advancements" && field === "marked") {
        if (entry.marked) return;
        return Rolls.advance(this.document);
      }
    }
    entry[field] = !entry[field];
    await this.document.update({ [`system.${list}`]: arr });
  }

  static async #onAddListEntry(event, target) {
    const list = target.dataset.list;
    const arr = foundry.utils.deepClone(this.document.system[list]);
    arr.push(LIST_DEFAULTS[list]());
    await this.document.update({ [`system.${list}`]: arr });
  }

  static async #onRemoveListEntry(event, target) {
    const list = target.dataset.list;
    const arr = foundry.utils.deepClone(this.document.system[list]);
    arr.splice(Number(target.dataset.index), 1);
    await this.document.update({ [`system.${list}`]: arr });
  }

  static async #onMoveListEntry(event, target) {
    const list = target.dataset.list;
    const i = Number(target.dataset.index);
    const j = i + Number(target.dataset.dir);
    const arr = foundry.utils.deepClone(this.document.system[list]);
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    await this.document.update({ [`system.${list}`]: arr });
  }

  static async #onSetXP(event, target) {
    const value = Number(target.dataset.value);
    const xp = this.document.system.xp === value ? value - 1 : value;
    await this.document.update({ "system.xp": Math.max(0, xp) });
  }

  static #onDawn() {
    return Rolls.dawnPhase(this.document);
  }

  static #onAdvance() {
    return Rolls.advance(this.document);
  }

  static async #onApplyTemplate() {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: L("PA.Template.apply") },
      content: `<p>${L("PA.Template.applyConfirm")}</p>`,
      rejectClose: false
    });
    if (!ok) return;
    const tpl = getSheetTemplate();
    await this.document.update({
      "system.dawnQuestions": tpl.dawnQuestions,
      "system.keysChild": tpl.keysChild,
      "system.keysDesolation": tpl.keysDesolation,
      "system.advancements": tpl.advancements
    });
  }

  static async #onRestoreBasics() {
    const ok = await foundry.applications.api.DialogV2.confirm({
      window: { title: L("PA.Move.restoreBasics") },
      content: `<p>${L("PA.Move.restoreConfirm")}</p>`,
      rejectClose: false
    });
    if (!ok) return;
    const ids = this.document.items.filter(i => i.type === "move" && i.system.moveType === "basic").map(i => i.id);
    await this.document.deleteEmbeddedDocuments("Item", ids);
    await this.document.createEmbeddedDocuments("Item", buildBasicMoves());
  }

  /** The phase badge opens the shared phase clock (the GM changes the phase there). */
  static #onCyclePhase() {
    return PhaseClock.toggle(true);
  }

  static async #onUnretire() {
    if (!game.user.isGM) return;
    await this.document.update({ "system.retired": false });
  }
}

import { SYSTEM_ID } from "../config.mjs";
import { MYSTERY_LISTS, MYSTERY_STATUS } from "../data/mystery.mjs";
import * as Mysteries from "../mysteries.mjs";
import * as ImportTools from "../import-tools.mjs";

const { HandlebarsApplicationMixin } = foundry.applications.api;
const { ActorSheetV2 } = foundry.applications.sheets;
const L = key => game.i18n.localize(key);

/** Editable columns for each list (edit mode). */
const COLUMNS = {
  questions: [["text", "text"], ["complexity", "number"], ["opportunity", "textarea"], ["answered", "checkbox"]],
  moments: [["text", "textarea"], ["used", "checkbox"]],
  dangers: [["name", "text"], ["text", "textarea"], ["rule", "textarea"]],
  locations: [["name", "text"], ["description", "textarea"], ["paint", "textarea"], ["rule", "textarea"], ["visited", "checkbox"]],
  sideCharacters: [["name", "text"], ["role", "text"], ["details", "text"], ["description", "textarea"], ["quote", "textarea"], ["hidden", "checkbox"], ["met", "checkbox"]],
  clues: [["text", "textarea"], ["found", "checkbox"], ["foundBy", "text"]],
  rewards: [["text", "textarea"], ["gear", "text"], ["claimedBy", "text"]]
};

export class MysterySheet extends HandlebarsApplicationMixin(ActorSheetV2) {
  #editMode = false;

  static DEFAULT_OPTIONS = {
    classes: ["public-access", "sheet", "actor", "mystery"],
    position: { width: 860, height: 880 },
    window: { resizable: true, icon: "fa-solid fa-house-chimney-crack" },
    form: { submitOnChange: true, closeOnSubmit: false },
    actions: {
      editImage: MysterySheet.#onEditImage,
      toggleEdit: MysterySheet.#onToggleEdit,
      present: MysterySheet.#onPresent,
      exportPack: MysterySheet.#onExport,
      addEntry: MysterySheet.#onAddEntry,
      removeEntry: MysterySheet.#onRemoveEntry,
      moveEntry: MysterySheet.#onMoveEntry,
      toggleFlag: MysterySheet.#onToggleFlag,
      postLocation: MysterySheet.#onPostLocation,
      postCharacter: MysterySheet.#onPostCharacter,
      postMoment: MysterySheet.#onPostMoment,
      revealClue: MysterySheet.#onRevealClue,
      claimReward: MysterySheet.#onClaimReward,
      resetKey: MysterySheet.#onResetKey,
      importText: MysterySheet.#onImportText
    }
  };

  static PARTS = {
    header: { template: `systems/${SYSTEM_ID}/templates/mystery/header.hbs` },
    tabs: { template: "templates/generic/tab-navigation.hbs" },
    overview: { template: `systems/${SYSTEM_ID}/templates/mystery/overview.hbs`, scrollable: [""] },
    clues: { template: `systems/${SYSTEM_ID}/templates/mystery/clues.hbs`, scrollable: [""] },
    places: { template: `systems/${SYSTEM_ID}/templates/mystery/places.hbs`, scrollable: [""] },
    threats: { template: `systems/${SYSTEM_ID}/templates/mystery/threats.hbs`, scrollable: [""] },
    rewards: { template: `systems/${SYSTEM_ID}/templates/mystery/rewards.hbs`, scrollable: [""] }
  };

  static TABS = {
    primary: {
      tabs: [
        { id: "overview", icon: "fa-solid fa-tower-broadcast" },
        { id: "clues", icon: "fa-solid fa-magnifying-glass" },
        { id: "places", icon: "fa-solid fa-location-dot" },
        { id: "threats", icon: "fa-solid fa-skull" },
        { id: "rewards", icon: "fa-solid fa-gift" }
      ],
      initial: "overview",
      labelPrefix: "PA.Mystery.tabs"
    }
  };

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const actor = this.document;
    const sys = actor.system;
    const TE = foundry.applications.ux.TextEditor.implementation;
    const enrich = html => TE.enrichHTML(html ?? "", { relativeTo: actor, secrets: true });
    context.tabs ??= this._prepareTabs("primary");

    const withIndex = arr => arr.map((e, index) => ({ ...e, index }));
    const edit = Object.fromEntries(Object.entries(COLUMNS).map(([list, cols]) => [list, {
      list,
      entries: sys[list].map((entry, index) => ({
        index,
        cells: cols.map(([key, type]) => ({ key, type, value: entry[key], label: L(`PA.Mystery.field.${key}`), wide: type === "textarea" }))
      }))
    }]));

    Object.assign(context, {
      actor, system: sys, source: actor._source.system, fields: sys.schema.fields,
      editMode: this.#editMode,
      isGM: game.user.isGM,
      statusChoices: Object.fromEntries(Object.entries(MYSTERY_STATUS).map(([k, v]) => [k, L(v)])),
      edit,
      questions: withIndex(sys.questions),
      moments: withIndex(sys.moments),
      dangers: withIndex(sys.dangers),
      locations: withIndex(sys.locations),
      sideCharacters: withIndex(sys.sideCharacters),
      clues: withIndex(sys.clues),
      rewards: withIndex(sys.rewards),
      cluesFound: sys.cluesFound,
      cluesTotal: sys.clues.length,
      enrichedPresentation: await enrich(sys.presentation),
      enrichedThreat: await enrich(sys.threat.description),
      enrichedIgnored: await enrich(sys.threat.ifIgnored),
      enrichedNotes: await enrich(sys.notes)
    });
    return context;
  }

  async _preparePartContext(partId, context, options) {
    context = await super._preparePartContext(partId, context, options);
    if (context.tabs?.[partId]) context.tab = context.tabs[partId];
    return context;
  }

  _onRender(context, options) {
    super._onRender(context, options);
    for (const input of this.element.querySelectorAll("[data-list][data-field]:not([data-pa-bound])")) {
      input.dataset.paBound = "1";
      input.addEventListener("change", this.#onListFieldChange.bind(this));
    }
  }

  async #onListFieldChange(event) {
    event.stopPropagation();
    const el = event.currentTarget;
    const { list, index, field } = el.dataset;
    const arr = foundry.utils.deepClone(this.document.system[list]);
    if (!arr[index]) return;
    arr[index][field] = el.type === "checkbox" ? el.checked : el.type === "number" ? Number(el.value) : el.value;
    await this.document.update({ [`system.${list}`]: arr });
  }

  /* ------------------------------------------------------------------------ */

  static async #onEditImage() {
    if (!this.isEditable) return;
    const FP = foundry.applications.apps.FilePicker.implementation;
    return new FP({ type: "image", current: this.document.img, callback: path => this.document.update({ img: path }) }).browse();
  }

  static #onToggleEdit() {
    this.#editMode = !this.#editMode;
    this.render();
  }

  static #onPresent() {
    return Mysteries.presentMystery(this.document);
  }

  static #onExport() {
    return Mysteries.exportToWorldPack(this.document);
  }

  static async #onAddEntry(event, target) {
    const list = target.dataset.list;
    const arr = foundry.utils.deepClone(this.document.system[list]);
    arr.push(MYSTERY_LISTS[list]());
    await this.document.update({ [`system.${list}`]: arr });
  }

  static async #onRemoveEntry(event, target) {
    const list = target.dataset.list;
    const arr = foundry.utils.deepClone(this.document.system[list]);
    arr.splice(Number(target.dataset.index), 1);
    await this.document.update({ [`system.${list}`]: arr });
  }

  static async #onMoveEntry(event, target) {
    const list = target.dataset.list;
    const i = Number(target.dataset.index);
    const j = i + Number(target.dataset.dir);
    const arr = foundry.utils.deepClone(this.document.system[list]);
    if (j < 0 || j >= arr.length) return;
    [arr[i], arr[j]] = [arr[j], arr[i]];
    await this.document.update({ [`system.${list}`]: arr });
  }

  static async #onToggleFlag(event, target) {
    const { list, field } = target.dataset;
    const arr = foundry.utils.deepClone(this.document.system[list]);
    const entry = arr[Number(target.dataset.index)];
    if (!entry) return;
    entry[field] = !entry[field];
    await this.document.update({ [`system.${list}`]: arr });
  }

  static #onPostLocation(event, target) {
    return Mysteries.postLocation(this.document, Number(target.dataset.index));
  }

  static #onPostCharacter(event, target) {
    return Mysteries.postCharacter(this.document, Number(target.dataset.index));
  }

  static #onPostMoment(event, target) {
    return Mysteries.postMoment(this.document, Number(target.dataset.index));
  }

  static #onRevealClue(event, target) {
    return Mysteries.revealClue(this.document, Number(target.dataset.index));
  }

  static #onClaimReward(event, target) {
    return Mysteries.claimReward(this.document, Number(target.dataset.index));
  }

  static #onImportText() {
    return ImportTools.importMysteryText(this.document);
  }

  static async #onResetKey() {
    await this.document.update({ "system.key.used": false, "system.key.usedBy": "" });
  }
}

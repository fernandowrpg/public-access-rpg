/**
 * Builds the Latchkey Moves compendiums (LevelDB) from tools/latchkey-moves.mjs.
 *   npm i -D @foundryvtt/foundryvtt-cli && node tools/build-packs.mjs
 */
import fs from "node:fs";
import path from "node:path";
import os from "node:os";
import { fileURLToPath } from "node:url";
import { compilePack } from "@foundryvtt/foundryvtt-cli";
import { MOVES } from "./latchkey-moves.mjs";
import { MYSTERIES } from "./mysteries.mjs";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const pick = (v, lang) => (v && typeof v === "object" && !Array.isArray(v) && ("en" in v || "pt" in v)) ? v[lang] : v;
const resolve = (obj, lang) => {
  if (Array.isArray(obj)) return obj.map(o => resolve(o, lang));
  if (obj && typeof obj === "object") {
    if ("en" in obj || "pt" in obj) return obj[lang];
    return Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, resolve(v, lang)]));
  }
  return obj;
};

async function build(name, docs) {
  const src = path.join(root, "packs-src", name);
  fs.rmSync(src, { recursive: true, force: true });
  fs.mkdirSync(src, { recursive: true });
  for (const doc of docs) fs.writeFileSync(path.join(src, `${doc._id}.json`), JSON.stringify(doc, null, 2));
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "pa-pack-"));
  await compilePack(src, tmp, { log: false });
  const dest = path.join(root, "packs", name);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.cpSync(tmp, dest, { recursive: true });
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.rmSync(path.join(dest, "LOCK"), { force: true });
  console.log(`Built packs/${name} (${docs.length})`);
}

const LIST_DEFAULTS = {
  questions: { text: "", complexity: 6, opportunity: "", answered: false, result: "" },
  moments: { text: "", used: false },
  dangers: { name: "", text: "", rule: "" },
  locations: { name: "", description: "", paint: "", rule: "", visited: false },
  sideCharacters: { name: "", role: "", details: "", description: "", quote: "", hidden: false, met: false },
  clues: { text: "", found: false, foundBy: "" },
  rewards: { text: "", gear: "", claimedBy: "" }
};

for (const lang of ["pt", "en"]) {
  await build(`mysteries-${lang}`, MYSTERIES.map((m, i) => {
    if (!/^[A-Za-z0-9]{16}$/.test(m.id)) throw new Error(`Bad id ${m.id}`);
    const system = resolve(m.system, lang);
    for (const [list, defaults] of Object.entries(LIST_DEFAULTS)) {
      system[list] = (system[list] ?? []).map(e => ({ ...defaults, ...e }));
    }
    system.key = { title: "", text: "", used: false, usedBy: "", ...(system.key ?? {}) };
    return {
      _id: m.id, _key: `!actors!${m.id}`,
      name: resolve(m.name, lang), type: "mystery", img: m.img, system,
      items: [], effects: [], folder: null, sort: (i + 1) * 100,
      ownership: { default: 0 }, flags: {}, prototypeToken: { name: resolve(m.name, lang), actorLink: true }
    };
  }));
}

for (const lang of ["pt", "en"]) {
  const src = path.join(root, "packs-src", `latchkey-moves-${lang}`);
  fs.rmSync(src, { recursive: true, force: true });
  fs.mkdirSync(src, { recursive: true });
  MOVES.forEach((m, i) => {
    if (!/^[A-Za-z0-9]{16}$/.test(m.id)) throw new Error(`Bad id ${m.id}`);
    const system = foundryMove(resolve(m.system, lang), pick(m[lang], lang));
    const doc = {
      _id: m.id, _key: `!items!${m.id}`,
      name: m.name, type: "move", img: m.img, system,
      effects: [], folder: null, sort: (i + 1) * 100, ownership: { default: 0 }, flags: {}
    };
    fs.writeFileSync(path.join(src, `${m.id}.json`), JSON.stringify(doc, null, 2));
  });
  // LevelDB can't write into some sandboxed/virtualized folders: build in the OS temp dir, then copy.
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "pa-pack-"));
  await compilePack(src, tmp, { log: false });
  const dest = path.join(root, "packs", `latchkey-moves-${lang}`);
  fs.rmSync(dest, { recursive: true, force: true });
  fs.cpSync(tmp, dest, { recursive: true });
  fs.rmSync(tmp, { recursive: true, force: true });
  console.log(`Built ${dest} (${MOVES.length} moves)`);
}

function foundryMove(sys, description) {
  return {
    moveType: "latchkey", key: "", rollType: sys.rollType ?? "none", ability: sys.ability ?? "reason", bonus: 0,
    forceMode: "none", allowAdvDis: true, allowKeys: true,
    prompt: sys.prompt ?? "", trigger: sys.trigger ?? "", description,
    results: { miss: "", partial: "", strong: "", critical: "", ...(sys.results ?? {}) },
    xpOnMiss: false,
    uses: { value: 0, max: 0, reset: "none", ...(sys.uses ?? {}) },
    abilityBoost: { ability: "", value: 0, ...(sys.abilityBoost ?? {}) },
    grantsItems: sys.grantsItems ?? "",
    hook: { move: "", effect: "note", note: "", ...(sys.hook ?? {}) },
    addsGear: !!sys.addsGear, sessionReminder: !!sys.sessionReminder,
    keyAnytime: sys.keyAnytime ?? "", protectsKey: sys.protectsKey ?? ""
  };
}

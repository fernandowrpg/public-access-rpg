/**
 * Source data for the "Latchkey Moves" compendiums.
 * Texts are short summaries of each move's effect; paste the official wording into the item if you prefer.
 * Build with: node tools/build-packs.mjs
 */

const none = { rollType: "none" };
const once = reset => ({ uses: { value: 1, max: 1, reset } });

export const MOVES = [
  {
    id: "paLkWheresBeef01", name: "Where's the Beef?", img: "icons/svg/upgrade.svg",
    system: { ...none, abilityBoost: { ability: "vitality", value: 1 } },
    en: "<p>You're a little bigger and stronger than most. <strong>+1 Vitality</strong> (max +3, applied automatically). Rolls for actions connected to the Big Man always use Vitality.</p>",
    pt: "<p>Você é um pouco maior e mais forte que a maioria. <strong>+1 em Vitalidade</strong> (máx. +3, aplicado automaticamente). Rolagens de ações ligadas ao Big Man sempre usam Vitalidade.</p>"
  },
  {
    id: "paLkSightBeyond1", name: "Sight Beyond Sight", img: "icons/svg/eye.svg",
    system: { ...none, trigger: "" },
    en: "<p>You get hunches about what's coming. The first time you enter a Location, ask the Keeper <em>\"What is about to happen?\"</em>: the answer is true, if not complete. With The Sandstone Arch marked, you can also ask <em>\"Why is it about to happen?\"</em></p>",
    pt: "<p>Você tem pressentimentos sobre o que está por vir. Na primeira vez que entra em uma Location, pergunte ao Keeper <em>\"O que está prestes a acontecer?\"</em>: a resposta é verdadeira, ainda que incompleta. Com The Sandstone Arch marcada, você também pode perguntar <em>\"Por que isso vai acontecer?\"</em></p>"
  },
  {
    id: "paLkThisIsBrain1", name: "This is Your Brain", img: "icons/svg/book.svg",
    system: { ...none, abilityBoost: { ability: "reason", value: 1 }, protectsKey: "The Fathomless Well" },
    en: "<p>Your logic stays sharp even when you stare into the dark. <strong>+1 Reason</strong> (max +3, applied automatically). Marking The Fathomless Well doesn't lower your Reason (automated).</p>",
    pt: "<p>Sua lógica continua afiada mesmo encarando o abismo. <strong>+1 em Razão</strong> (máx. +3, aplicado automaticamente). Marcar The Fathomless Well não reduz sua Razão (automatizado).</p>"
  },
  {
    id: "paLkComeWithMe01", name: "Come With Me If You Want to Live", img: "icons/svg/wingfoot.svg",
    system: { ...none, ...once("session") },
    en: "<p>You always know where the exits are. <strong>Once per session</strong>, when you and any number of others face grave harm, you all avoid it: narrate how you lead everyone to safety.</p>",
    pt: "<p>Você sempre sabe onde ficam as saídas. <strong>Uma vez por sessão</strong>, quando você e quaisquer outros enfrentam um dano grave, todos o evitam: narre como você leva todo mundo para um lugar seguro.</p>"
  },
  {
    id: "paLkKnowingHalf1", name: "Knowing is Half the Battle", img: "icons/svg/light.svg",
    system: { ...none, ...once("session") },
    en: "<p>You're full of trivia, some of it useful. <strong>Once per session</strong>, introduce a real-world fact about something in the scene. That fact is a Clue.</p>",
    pt: "<p>Você é uma enciclopédia de curiosidades, algumas até úteis. <strong>Uma vez por sessão</strong>, introduza um fato do mundo real sobre algo na cena. Esse fato é uma Pista.</p>"
  },
  {
    id: "paLkSayHello0001", name: "Say Hello to My Little Friend", img: "icons/svg/regen.svg",
    system: { ...none, grantsItems: { en: "*Dog (give it a name and breed)", pt: "*Cachorro (dê um nome e raça)" } },
    en: "<p>You have a very smart dog you're deeply bonded with; it understands basic commands and does simple tasks. Name it and say what kind of dog it is. It's added to Your Corner of the House as a <strong>reusable</strong> item: using it for advantage never marks it.</p>",
    pt: "<p>Você tem um cachorro muito esperto com quem tem um laço forte; ele entende comandos básicos e faz tarefas simples. Dê um nome e diga a raça. Ele entra no seu Canto da Casa como item <strong>reutilizável</strong>: usá-lo para ter vantagem nunca o marca.</p>"
  },
  {
    id: "paLkWhoYaGonna01", name: "Who Ya Gonna Call?", img: "icons/svg/sound.svg",
    system: {
      rollType: "ability", ability: "presence",
      trigger: { en: "When you post a question about a Deep Lake mystery on the Ghost Bro Mystery Show forums.", pt: "Quando você posta uma pergunta sobre um mistério de Deep Lake nos fóruns do Ghost Bro Mystery Show." },
      prompt: { en: "What do you ask the forum?", pt: "O que você pergunta no fórum?" },
      results: {
        strong: { en: "<p>A commenter has a good answer or a Clue (Keeper's choice) and shares it freely.</p>", pt: "<p>Alguém nos comentários tem uma boa resposta ou uma Pista (escolha do Keeper) e compartilha de graça.</p>" },
        partial: { en: "<p>As above, but they want you to do something for them first.</p>", pt: "<p>Como acima, mas a pessoa quer que você faça algo por ela primeiro.</p>" }
      }
    },
    en: "<p>You're active on the forums of The Ghost Bro Mystery Show, a TV show about young ghost hunters. Roll with <strong>Presence</strong> when you ask the forum about a Deep Lake mystery.</p>",
    pt: "<p>Você é ativo nos fóruns do The Ghost Bro Mystery Show, um programa sobre jovens caçadores de fantasmas. Role com <strong>Presença</strong> quando perguntar ao fórum sobre um mistério de Deep Lake.</p>"
  },
  {
    id: "paLkRobotDisgu01", name: "Robot in Disguise", img: "icons/svg/lightning.svg",
    system: { ...none, grantsItems: { en: "Laptop\nWalkie Talkies\nGPS\nCamcorder\nVoice-Activated Audio Recorder", pt: "Laptop\nWalkie-talkies\nGPS\nFilmadora\nGravador de voz ativado por voz" } },
    en: "<p>You brought a bunch of electronic gadgets to Deep Lake. They are added to Your Corner of the House automatically.</p>",
    pt: "<p>Você trouxe um monte de aparelhos eletrônicos para Deep Lake. Eles são adicionados ao seu Canto da Casa automaticamente.</p>"
  },
  {
    id: "paLkRighteousDu1", name: "They Think He's a Righteous Dude", img: "icons/svg/mystery-man.svg",
    system: {
      ...none, ...once("session"),
      hook: { move: "meddling", effect: "note", note: { en: "+1 extra Clue, even on a miss (place full of outcasts)", pt: "+1 Pista extra, mesmo na falha (lugar cheio de excluídos)" } }
    },
    en: "<p>The town's motorheads, dweebs and wastoids trust you. Why? <strong>Once per session</strong>, when you do the Meddling Move somewhere full of losers and outcasts, you find an extra Clue, even on a miss. <em>(Tick it in the Meddling Move dialog.)</em></p>",
    pt: "<p>Os motorheads, nerds e desajustados da cidade confiam em você. Por quê? <strong>Uma vez por sessão</strong>, ao fazer o Meddling Move num lugar cheio de losers e excluídos, você encontra uma Pista extra, mesmo na falha. <em>(Marque no diálogo do Meddling Move.)</em></p>"
  },
  {
    id: "paLkWinnerIsYou1", name: "A Winner is You", img: "icons/svg/aura.svg",
    system: { ...none, abilityBoost: { ability: "presence", value: 1 } },
    en: "<p>You were a loser back then; now people respect you. Why? <strong>+1 Presence</strong> (max +3, applied automatically).</p>",
    pt: "<p>Você era um loser naquela época; agora as pessoas te respeitam. Por quê? <strong>+1 em Presença</strong> (máx. +3, aplicado automaticamente).</p>"
  },
  {
    id: "paLkIAmError0001", name: "I Am Error", img: "icons/svg/daze.svg",
    system: { ...none, keyAnytime: "The Chromatic Desert" },
    en: "<p>You can mark The Chromatic Desert whenever you want (it shows up in the Turn a Key dialog even out of order). While it's marked, the other Latchkeys don't forget you, and you can keep interacting with them as long as a TV is nearby: you appear on whatever is playing and hear people who talk to you through the screen. When the Latchkeys watch an Odyssey tape, your scenes can take place inside the tape.</p>",
    pt: "<p>Você pode marcar The Chromatic Desert quando quiser (ela aparece no diálogo de virar Key mesmo fora de ordem). Enquanto marcada, os outros Latchkeys não te esquecem, e você continua interagindo com eles desde que haja uma TV por perto: você aparece no que estiver passando e ouve quem fala com você pela tela. Quando os Latchkeys assistem a uma fita Odyssey, suas cenas podem acontecer dentro da fita.</p>"
  },
  {
    id: "paLkThankYouFri1", name: "Thank You for Being a Friend", img: "icons/svg/heal.svg",
    system: {
      ...none,
      hook: { move: "nostalgic", effect: "note", note: { en: "The other Latchkey may clear a second Condition OR take Feeling Good (clear it any time for advantage).", pt: "O outro Latchkey pode remover uma segunda Condition OU receber Sentindo-se Bem (remova quando quiser para ter vantagem)." } }
    },
    en: "<p>People open up to you easily. When you do the Nostalgic Move, the other Latchkey may clear a second Condition <strong>or</strong> take the Condition <strong>Feeling Good</strong>, which they can clear at any time to get advantage on a roll. <em>(Automated: the card offers Feeling Good, and the roll dialog lets you clear it for advantage.)</em></p>",
    pt: "<p>As pessoas se abrem com você facilmente. Quando você faz o Nostalgic Move, o outro Latchkey pode remover uma segunda Condition <strong>ou</strong> receber a Condition <strong>Sentindo-se Bem</strong>, que pode ser removida a qualquer momento para ter vantagem numa rolagem. <em>(Automatizado: o card oferece Sentindo-se Bem e o diálogo de rolagem permite removê-la para ter vantagem.)</em></p>"
  },
  {
    id: "paLkTruthOutThe1", name: "The Truth is Out There", img: "icons/svg/door-exit.svg",
    system: { ...none, sessionReminder: true },
    en: "<p>Someone who knows what happened to TV Odyssey is helping you in secret. When you take this move, the Latchkeys gain an Odyssey tape, a gift from your benefactor. At the start of each session they leave you something: say what it is or ask the Keeper. It works as a Clue not tied to any mystery; use it now or save it. The Keeper may reveal who they are during the Odyssey Mystery. <em>(Reminded on each new session.)</em></p>",
    pt: "<p>Alguém que sabe o que aconteceu com a TV Odyssey te ajuda em segredo. Ao pegar este move, os Latchkeys ganham uma fita Odyssey, presente do seu benfeitor. No início de cada sessão essa pessoa deixa algo para você: diga o que é ou pergunte ao Keeper. Funciona como uma Pista não ligada a nenhum mistério; use agora ou guarde. O Keeper pode revelar quem é durante o Odyssey Mystery. <em>(Lembrado a cada nova sessão.)</em></p>"
  },
  {
    id: "paLkAlwaysGlad01", name: "And They're Always Glad You Came", img: "icons/svg/house.svg",
    system: {
      ...none,
      hook: { move: "any", effect: "advantage", note: { en: "Your family member is helping you", pt: "Seu familiar está te ajudando" } }
    },
    en: "<p>A family member still lives in Deep Lake. Who? Rolls for actions they help you with have <strong>advantage</strong> <em>(tick it in the roll dialog)</em>. If you're in immediate danger and reach their house, you're safe until at least the next morning.</p>",
    pt: "<p>Um familiar seu ainda mora em Deep Lake. Quem? Rolagens de ações em que essa pessoa te ajuda têm <strong>vantagem</strong> <em>(marque no diálogo de rolagem)</em>. Se estiver em perigo imediato e chegar à casa dela, você fica a salvo pelo menos até a manhã seguinte.</p>"
  },
  {
    id: "paLkNeverKnow001", name: "You Never Know What You're Going to Get", img: "icons/svg/book.svg",
    system: {
      ...none, ...once("session"),
      hook: { move: "meddling", effect: "note", note: { en: "+1 extra Clue, even on a miss (books, microfiche, records, archives)", pt: "+1 Pista extra, mesmo na falha (livros, microfilmes, registros, arquivos)" } }
    },
    en: "<p>You have a research background. What is it? <strong>Once per session</strong>, when you do the Meddling Move through books, microfiche, old records or online archives, you find an extra Clue, even on a miss. <em>(Tick it in the Meddling Move dialog.)</em></p>",
    pt: "<p>Você tem experiência com pesquisa. Qual? <strong>Uma vez por sessão</strong>, ao fazer o Meddling Move vasculhando livros, microfilmes, registros antigos ou arquivos online, você encontra uma Pista extra, mesmo na falha. <em>(Marque no diálogo do Meddling Move.)</em></p>"
  },
  {
    id: "paLkDancedDevil1", name: "Have You Ever Danced with the Devil", img: "icons/svg/fire.svg",
    system: { ...none, grantsItems: { en: "Candles\nGrimoire\nSmall Brazier\nAthame\nPoppet", pt: "Velas\nGrimório\nPequeno braseiro\nAthame\nBoneco de vodu" } },
    en: "<p>You brought tools for black magic to Deep Lake. They are added to Your Corner of the House automatically.</p>",
    pt: "<p>Você trouxe ferramentas de magia negra para Deep Lake. Elas são adicionadas ao seu Canto da Casa automaticamente.</p>"
  },
  {
    id: "paLkCircleK00001", name: "Strange Things are Afoot at the Circle K", img: "icons/svg/item-bag.svg",
    system: { ...none, addsGear: true },
    en: "<p>You believe in the goodness and power of convenience stores. If something you'd typically find at one would help and you take the time to go get it, say what it is and add it to Your Corner of the House. <em>(Using the move asks for the item and adds it.)</em></p>",
    pt: "<p>Você acredita na bondade e no poder das lojas de conveniência. Se algo que normalmente se encontra numa delas ajudaria e você tira um tempo para buscar, diga o que é e adicione ao seu Canto da Casa. <em>(Usar o move pede o item e o adiciona.)</em></p>"
  },
  {
    id: "paLkJustSayNo001", name: "Just Say No", img: "icons/svg/shield.svg",
    system: {
      ...none,
      hook: { move: "any", effect: "advantage", note: { en: "Dealing with the police", pt: "Lidando com a polícia" } }
    },
    en: "<p>Something in your past makes you good at handling cops and their bullshit. What is it? Whenever you're harassed by the police or need to get out of a sticky situation with law enforcement, all related rolls have <strong>advantage</strong> <em>(tick it in the roll dialog)</em>.</p>",
    pt: "<p>Algo no seu passado te deixa bom em lidar com policiais e suas babaquices. O quê? Sempre que for importunado pela polícia ou precisar sair de uma enrascada com a lei, todas as rolagens relacionadas têm <strong>vantagem</strong> <em>(marque no diálogo de rolagem)</em>.</p>"
  },
  {
    id: "paLkNintendont01", name: "What Nintendon't", img: "icons/svg/dice-target.svg",
    system: {
      ...none, ...once("session"),
      hook: { move: "any", effect: "critical", note: { en: "Done with cockiness or style", pt: "Feito com marra ou estilo" } }
    },
    en: "<p><strong>Once per session</strong>, take a 12+ on a single roll, as long as you act with cockiness or style. <em>(Tick it in the roll dialog for an automatic 12+.)</em></p>",
    pt: "<p><strong>Uma vez por sessão</strong>, considere um único resultado como 12+, desde que você aja com marra ou estilo. <em>(Marque no diálogo de rolagem para um 12+ automático.)</em></p>"
  },
  {
    id: "paLkNextSunday01", name: "Next Sunday A.D.", img: "icons/svg/clockwork.svg",
    system: { ...none, ...once("day") },
    en: "<p><strong>Once per Day phase</strong>, you and at least one other player can narrate an upcoming scene out of character, like movie-riffing commentary. At least one thing from that narration will be true in the scene: tell the Keeper what. The Keeper may make other parts true too. <em>(Refreshed when the phase changes to Day.)</em></p>",
    pt: "<p><strong>Uma vez por fase Day</strong>, você e pelo menos outro jogador podem narrar fora do personagem uma cena que está por vir, como quem comenta um filme. Pelo menos uma coisa dessa narração será verdade na cena: diga ao Keeper qual. O Keeper pode tornar outras partes verdadeiras também. <em>(Renovado quando a fase muda para Day.)</em></p>"
  }
];

/**
 * Source data for the "Mysteries" compendiums (Actor type "mystery").
 * Texts are summaries written for this system; the Keeper can paste the official wording into each field.
 * Each string is either plain or { en, pt }.
 */

export const MYSTERIES = [
  {
    id: "paMyEscondido001",
    name: { en: "The House on Escondido Street", pt: "The House on Escondido Street (A Casa da Rua Escondido)" },
    img: "icons/svg/house.svg",
    system: {
      status: "inactive",
      presentation: {
        en: "<p><em>Casey Wilcox, a young man who heard about your TV Odyssey investigation, comes to the house on Rodenbecker Street with another Deep Lake mystery. 18 Escondido Street has stood empty since 1994, when the family living there — the Rappaports: Hugh, Cheri and their kids Abigail and Elliott — vanished without a trace. Casey was ten and Elliott's friend; he remembers nothing odd about the family, which makes it all the stranger.</em></p><p><em>In the years since, the house became Deep Lake's local haunted house. People keep away and say it has bad energy. Apart from some vandalism, it is still as the Rappaports left it.</em></p>",
        pt: "<p><em>Casey Wilcox, um jovem que ouviu falar da investigação de vocês sobre a TV Odyssey, aparece na casa da Rodenbecker Street com outro mistério de Deep Lake. O número 18 da Escondido Street está abandonado desde 1994, quando a família que morava lá — os Rappaport: Hugh, Cheri e os filhos Abigail e Elliott — sumiu sem deixar rastro. Casey tinha dez anos e era amigo de Elliott; ele não se lembra de nada estranho na família, o que torna tudo ainda mais bizarro.</em></p><p><em>Desde então a casa virou a casa mal-assombrada oficial de Deep Lake. As pessoas evitam o lugar e dizem que ele tem uma energia ruim. Tirando um pouco de vandalismo, está do jeito que os Rappaport deixaram.</em></p>"
      },
      hook: {
        en: "Ask a Latchkey: something in Casey's story convinces you 18 Escondido Street is evil. What is it?",
        pt: "Pergunte a um Latchkey: algo na história de Casey te convence de que o número 18 da Escondido Street é maligno. O quê?"
      },
      questions: [
        {
          text: { en: "What happened to the Rappaports?", pt: "O que aconteceu com os Rappaport?" },
          complexity: 6,
          opportunity: {
            en: "Resolve the mystery by telling Casey Wilcox the truth. Then, optionally, destroy the house OR perform a ritual to banish the evil within it.",
            pt: "Resolva o mistério contando a verdade para Casey Wilcox. Depois, se quiserem, destruam a casa OU realizem um ritual para banir o mal que habita nela."
          }
        },
        {
          text: { en: "How can we lure Elliott to us?", pt: "Como podemos atrair Elliott até nós?" },
          complexity: 2,
          opportunity: { en: "Unlock Elliott as a Reward (only after he has entered play).", pt: "Desbloqueia Elliott como Recompensa (só depois que ele entrar em jogo)." }
        }
      ],
      key: {
        title: "The Key of the Cave-Dweller",
        text: {
          en: "Every Latchkey narrates a flashback of a fun thing they used to do at home with their family.",
          pt: "Cada Latchkey narra um flashback de uma atividade divertida que fazia em casa com a família."
        }
      },
      moments: [
        { en: "Kids laughing over the squeak of bicycle wheels.", pt: "Risadas de crianças misturadas ao rangido de rodas de bicicleta." },
        { en: "Backyard barbecue smells: burnt meat, beer, chlorine-soaked kids.", pt: "Cheiro de churrasco no quintal: carne tostando, cerveja, crianças com cheiro de cloro." },
        { en: "Three girls jumping double dutch on the sidewalk.", pt: "Três meninas pulando corda dupla na calçada." },
        { en: "Silence falls the moment you step inside, as if the outside world was left behind.", pt: "Um silêncio repentino ao entrar na casa, como se o mundo lá fora tivesse ficado para trás." },
        { en: "A shelf of forgotten stuffed animals, staring with dead eyes.", pt: "Uma prateleira de bichos de pelúcia esquecidos, encarando com olhos mortos." },
        { en: "Timbers creak and something shudders in the walls — the house is waking up.", pt: "A madeira range e algo estremece dentro das paredes — a casa está acordando." }
      ].map(text => ({ text })),
      threat: {
        name: { en: "The House", pt: "A Casa" },
        description: {
          en: "<p>A 1960s ranch house, renovated several times, on a half-acre lot ringed by ponderosa pines, with a fenced backyard and a pool. It is utterly evil. Its nature and origin are for the Latchkeys to discover, but this much is true: it knows who is inside and reads their minds, it can move things telekinetically, and it can make people see things that aren't there.</p>",
          pt: "<p>Uma casa térrea dos anos 60, reformada várias vezes, num terreno de meio acre cercado de pinheiros ponderosa, com quintal cercado e piscina. Ela é completamente maligna. A natureza e a origem desse mal cabem aos Latchkeys descobrir, mas algumas coisas são certas: ela sabe quem está lá dentro e lê mentes, move coisas por telecinese e faz as pessoas verem coisas que não existem.</p>"
        },
        ifIgnored: {
          en: "<p>Dormant for ten years, the house wakes up when the Latchkeys first set foot inside, and it is hungry and destructive. It lures people in — including Side Characters the Latchkeys care about — and tries to destroy them. If the mystery is resolved but the house is left standing, it stays a recurring nuisance and the Keeper gains a new reaction: <strong>Lure a Side Character to the house on Escondido Street</strong>.</p>",
          pt: "<p>Adormecida há dez anos, a casa desperta quando os Latchkeys entram nela pela primeira vez, faminta e destrutiva. Ela atrai pessoas — inclusive Side Characters que os Latchkeys querem proteger — e tenta destruí-las. Se o mistério for resolvido mas a casa ficar de pé, ela continua um incômodo recorrente e o Keeper ganha uma nova reação: <strong>Atrair um Side Character para a casa da Escondido Street</strong>.</p>"
        }
      },
      dangers: [
        {
          name: { en: "Telekinetic attacks", pt: "Ataques telecinéticos" },
          text: { en: "Throws objects around and can set things ablaze — though fire only when desperate, since it could burn itself down.", pt: "Arremessa objetos e pode fazer coisas pegarem fogo — mas só recorre ao fogo em desespero, pois pode acabar se queimando." },
          rule: ""
        },
        {
          name: { en: "Phantasms", pt: "Fantasmagorias" },
          text: { en: "Hyper-realistic illusions that lure and torment, usually confined to the room where they appear. Mind-reading makes them especially scary or tempting.", pt: "Ilusões hiper-realistas que atraem e atormentam, geralmente restritas ao cômodo onde surgem. A leitura de mentes as torna especialmente assustadoras ou sedutoras." },
          rule: { en: "If a phantasm plays on a Latchkey's Conditions, related rolls are at disadvantage as usual AND inflict a new Condition: Haunted.", pt: "Se uma fantasmagoria explorar as Conditions de um Latchkey, as rolagens relacionadas têm desvantagem como de costume E causam uma nova Condition: Assombrado." }
        },
        {
          name: "Patience Head",
          text: { en: "Helmet hair, striped polyester blouse, chunky jewelry. HOA president who watches everything on Escondido Street and has spent years trying to get the house condemned. Not dangerous, just very annoying — if she decides the Latchkeys are trouble, she calls the police.", pt: "Cabelo armado, blusa listrada de poliéster, bijuterias enormes. Presidente da associação de moradores, vigia tudo na Escondido Street e tenta há anos fazer a casa ser condenada. Não é perigosa, só muito irritante — se achar que os Latchkeys são encrenca, chama a polícia." },
          rule: { en: "Voice: sugary, nosy and self-important; always \"just doing her duty as a good neighbor\".", pt: "Voz: melosa, enxerida e cheia de si; sempre \"só cumprindo seu dever de boa vizinha\"." }
        }
      ],
      locations: [
        {
          name: { en: "Stand of trees", pt: "Bosque de pinheiros" },
          description: { en: "Tall ponderosa pines, yellowing grass, sticky needles on your shoes.", pt: "Pinheiros ponderosa altos, grama amarelada, agulhas grudentas nos sapatos." },
          paint: { en: "What about the trees makes you think the evil here is in the land itself?", pt: "O que nas árvores te faz pensar que o mal deste lugar está na própria terra?" }
        },
        {
          name: { en: "Backyard", pt: "Quintal" },
          description: { en: "A pool with a thin layer of green muck, faded cracked patio furniture, big overturned planters.", pt: "Piscina com uma camada rasa de água verde e lodosa, móveis de área desbotados e rachados, vasos grandes tombados." },
          paint: { en: "The Rappaports had one last fun day in the sun before they vanished. What do you see that shows it?", pt: "Os Rappaport tiveram um último dia de diversão ao sol antes de sumirem. O que você vê aqui que mostra isso?" }
        },
        {
          name: { en: "Kitchen and dining room", pt: "Cozinha e sala de jantar" },
          description: { en: "Small kitchen with a pass-through to the dining room; a Wedgwood blue table set for dinner; oak cabinets, speckled formica.", pt: "Cozinha pequena com passa-pratos para a sala de jantar; mesa azul Wedgwood posta para o jantar; armários de carvalho, fórmica salpicada." },
          paint: { en: "From what was left out, name one dish on the menu the day they disappeared.", pt: "Pelo que ficou sobre a mesa, diga um prato do cardápio no dia em que eles sumiram." }
        },
        {
          name: { en: "TV room", pt: "Sala de TV" },
          description: { en: "Maroon sectional, a wall-sized entertainment center, a working VCR on a huge tube TV — its clock blinks 12:00 though the house has no power.", pt: "Sofá de canto bordô, um rack do tamanho da parede, um videocassete funcionando ligado a uma TV de tubo enorme — o relógio pisca 12:00 mesmo sem energia na casa." },
          paint: { en: "How can you tell this was the most-used room in the house?", pt: "Olhando em volta, como você sabe que este era o cômodo mais frequentado da casa?" },
          rule: { en: "The TV and VCR work without power. Watching an Odyssey tape here lets the Latchkeys jointly define a Clue inspired by it, usable for any mystery (it can't answer a Question alone). Repeatable, even after the mystery is resolved, while they have access to the house.", pt: "A TV e o videocassete funcionam sem energia. Assistir a uma fita Odyssey aqui permite que os Latchkeys definam juntos uma Pista inspirada nela, válida para qualquer mistério (não responde uma Pergunta sozinha). Pode ser repetido, mesmo após resolver o mistério, enquanto tiverem acesso à casa." }
        },
        {
          name: { en: "Master bedroom", pt: "Quarto do casal" },
          description: { en: "Teal and mauve seaside decor, brass queen bed, a faint trace of Estée Lauder perfume.", pt: "Decoração praiana em verde-água e malva, cama queen de latão, um leve cheiro de perfume Estée Lauder." },
          paint: { en: "What here suggests Hugh and Cheri cared more about their kids than themselves?", pt: "O que aqui sugere que Hugh e Cheri se preocupavam mais com os filhos do que consigo mesmos?" }
        },
        {
          name: { en: "Elliott's room", pt: "Quarto do Elliott" },
          description: { en: "Twin bed with Ninja Turtle sheets, a big Bill Nye poster, Matchbox cars strewn across the floor.", pt: "Cama de solteiro com lençol das Tartarugas Ninja, pôster grande do Bill Nye, carrinhos Matchbox espalhados pelo chão." },
          paint: { en: "(Only if they open the closet) The room's energy shifts when the closet opens. What makes you feel Elliott is still somewhere in the house?", pt: "(Só se abrirem o armário) A energia do quarto muda quando o armário é aberto. O que te faz sentir que Elliott ainda está em algum lugar da casa?" },
          rule: { en: "Once this Paint the Scene is answered, Elliott Rappaport enters play (see Side Characters).", pt: "Depois que este Paint the Scene for respondido, Elliott Rappaport entra em jogo (veja Side Characters)." }
        },
        {
          name: { en: "Abigail's room", pt: "Quarto da Abigail" },
          description: { en: "My Little Pony wallpaper, Pink Power Ranger sheets, a faint smell of strawberry-scented plastic.", pt: "Papel de parede de My Little Pony, lençol da Power Ranger Rosa, leve cheiro de plástico com aroma de morango." },
          paint: { en: "How can you tell her friends were what mattered most to Abigail (after family)?", pt: "Como você sabe que os amigos eram o mais importante para Abigail (depois da família)?" }
        },
        {
          name: { en: "Basement", pt: "Porão" },
          description: { en: "Sawdust and rat droppings, piles of U-Haul boxes, a disassembled Christmas tree in a corner.", pt: "Cheiro de serragem e fezes de rato, pilhas de caixas da U-Haul, uma árvore de Natal desmontada num canto." },
          paint: { en: "What about the basement tells you the kids were terrified of coming down here?", pt: "O que no porão te diz que as crianças morriam de medo de descer aqui?" }
        }
      ],
      sideCharacters: [
        {
          name: "Casey Wilcox", role: { en: "a friend", pt: "um amigo" },
          details: { en: "Blond fauxhawk · JNCOs and flame prints · cleft palate scar", pt: "Moicano falso loiro · calça JNCO e estampa de chamas · cicatriz de lábio leporino" },
          description: { en: "A nice guy, and quietly Deep Lake's most desirable bachelor. Elliott's disappearance marked him deeply; he never got over it.", pt: "Um cara legal e, discretamente, o solteiro mais cobiçado de Deep Lake. O sumiço de Elliott o marcou profundamente; ele nunca superou." },
          quote: { en: "Voice: warm but haunted; hints that Deep Lake got its hooks in him during his worst years.", pt: "Voz: calorosa mas assombrada; insinua que Deep Lake o agarrou nos seus piores anos." }
        },
        {
          name: "Bill Hanscom", role: { en: "the sheriff", pt: "o xerife" },
          details: { en: "Square jaw, handsome · smells of Old Spice and Big Red gum · uniform shirt tight across the chest", pt: "Queixo quadrado, bonitão · cheiro de Old Spice e chiclete Big Red · camisa do uniforme justa no peito" },
          description: { en: "Sheriff of Degoya County, raised in nearby La Fresca; knows things get strange around here. Won't stop the Latchkeys unless someone might get hurt.", pt: "Xerife do Condado de Degoya, criado na vizinha La Fresca; sabe que as coisas ficam estranhas por aqui. Não atrapalha os Latchkeys a menos que alguém possa se machucar." },
          quote: { en: "Voice: nostalgic small-town jock; will look the other way, but wants a call if anyone gets in trouble.", pt: "Voz: ex-atleta nostálgico de cidade pequena; faz vista grossa, mas quer uma ligação se alguém se meter em encrenca." }
        },
        {
          name: "Chuck Terrio", role: { en: "a landscaper", pt: "um jardineiro" },
          details: { en: "Five o'clock shadow · plastic goggles · heavy gloves and boots", pt: "Barba por fazer · óculos de proteção de plástico · luvas e botas pesadas" },
          description: { en: "Tends almost every yard on Escondido Street and knew the Rappaports. Pressed, he has some very… interesting ideas about Deep Lake.", pt: "Cuida de quase todos os jardins da Escondido Street e conhecia os Rappaport. Se pressionado, tem ideias bem… interessantes sobre Deep Lake." },
          quote: { en: "Voice: insists his job matters because he's in communion with the land — and with what lives in the earth.", pt: "Voz: insiste que seu trabalho importa porque ele está em comunhão com a terra — e com o que vive nela." }
        },
        {
          name: { en: "A gang of kids", pt: "Uma turma de crianças" }, role: "",
          details: "Sophia, Kelsey, Tyler, Chase, Kyle, Maria",
          description: { en: "Kids playing in the street. Curious about the Latchkeys and may share what they've seen, but won't go into the house without a really good reason.", pt: "Crianças brincando na rua. Curiosas sobre os Latchkeys e podem contar o que viram, mas não entram na casa sem um motivo muito bom." },
          quote: ""
        },
        {
          name: "Debbie Rappaport", role: { en: "a relative", pt: "uma parente" },
          details: { en: "Red hair with gray roots · defensive body language · raspy smoker's voice", pt: "Cabelo ruivo com raiz grisalha · linguagem corporal defensiva · voz rouca de fumante" },
          description: { en: "Hugh's sister, living down the street. Wants answers more than anyone but refuses to go inside. Fiercely protective of the property; long-running feud with Patience Head.", pt: "Irmã de Hugh, mora na mesma rua. Quer respostas mais do que ninguém, mas se recusa a entrar. Protege o imóvel com unhas e dentes; briga há anos com Patience Head." },
          quote: { en: "Voice: the house was always wrong, even before — but it's still their home, and maybe they'll come back if it's left alone.", pt: "Voz: a casa sempre foi errada, mesmo antes — mas ainda é o lar deles, e talvez voltem se ninguém mexer." }
        },
        {
          name: "Elliott Rappaport", role: { en: "a phantom", pt: "um fantasma" },
          details: { en: "Bowl cut · neon green t-shirt · peeks around corners", pt: "Cabelo tigelinha · camiseta verde neon · espia pelos cantos" },
          description: { en: "Maybe an illusion of the house that gained a will of its own, maybe a real ghost. Very shy; runs the first time he's seen. Can't speak, only gestures. Can be befriended by answering \"How can we lure Elliott to us?\". Enters play only after the Paint the Scene in his bedroom.", pt: "Talvez uma ilusão da casa que ganhou vontade própria, talvez um fantasma de verdade. Muito tímido; foge na primeira vez que é visto. Não fala, só gesticula. Pode virar amigo se responderem \"Como podemos atrair Elliott até nós?\". Só entra em jogo depois do Paint the Scene no quarto dele." },
          quote: "", hidden: true
        }
      ],
      clues: [
        { en: "Scorch marks in an odd shape (spiral / pentagram / antlers / other).", pt: "Marcas de queimado num formato estranho (espiral / pentagrama / chifres / outro)." },
        { en: "Threatening answering-machine messages for Hugh about (money owed / trouble at work / an affair / other).", pt: "Mensagens ameaçadoras para Hugh na secretária eletrônica sobre (dívida / conflito no trabalho / um caso extraconjugal / outro)." },
        { en: "A string of numbers scrawled somewhere unusual.", pt: "Uma sequência de números rabiscada num lugar incomum." },
        { en: "Gardening tools crusted with dirt and blood.", pt: "Ferramentas de jardinagem cobertas de terra e sangue." },
        { en: "A lifelike door painted on a wall.", pt: "Uma porta realista pintada numa parede." },
        { en: "Candy wrappers of one brand all over the house (Reese's / Snickers / Smarties / other).", pt: "Embalagens de um mesmo doce pela casa toda (Reese's / Snickers / Smarties / outro)." },
        { en: "Height marks on a door frame for one child — one year is missing.", pt: "Marcas de altura de uma das crianças num batente — falta a marca de um ano." },
        { en: "A family photo showing a third child.", pt: "Uma foto de família mostrando uma terceira criança." },
        { en: "An empty \"Summer Camp '93\" album except the last page: photos of (dead animals / the night sky / empty hospital beds / other).", pt: "Um álbum \"Summer Camp '93\" vazio, exceto a última página: fotos de (animais mortos / o céu noturno / leitos de hospital vazios / outro)." },
        { en: "A Candyland board with characters you don't remember (the Toffee Duke, the Ravenous Sugarpig, the Licorice Beastie…).", pt: "Um tabuleiro de Candyland com personagens que você não lembra (o Toffee Duke, o Ravenous Sugarpig, o Licorice Beastie…)." },
        { en: "A well-preserved hopscotch with a picture where the 10 should be (devil / crying eye / hand pointing east / other).", pt: "Uma amarelinha bem conservada com um desenho no lugar do 10 (diabo / olho chorando / mão apontando para o leste / outro)." },
        { en: "A smashed mirror somewhere it shouldn't be.", pt: "Um espelho quebrado num lugar inesperado." },
        { en: "A tidy medicine cabinet where every pill bottle is empty.", pt: "Um armário de remédios organizado, com todos os frascos vazios." },
        { en: "A strange residue that (glows / changes color / makes you dizzy to touch / other).", pt: "Um resíduo estranho que (brilha / muda de cor / dá tontura ao tocar / outro)." },
        { en: "Signs of a forced entry, carefully hidden afterward.", pt: "Sinais de arrombamento, cuidadosamente disfarçados depois." },
        { en: "A copy of The Lion, the Witch and the Wardrobe somewhere unusual.", pt: "Um exemplar de As Crônicas de Nárnia: O Leão, a Feiticeira e o Guarda-Roupa num lugar incomum." },
        { en: "Last page of Cheri's dream journal: she found how to save her family — they have to sleep in order to wake up.", pt: "Última página do diário de sonhos de Cheri: ela descobriu como salvar a família — é preciso dormir para acordar." },
        { en: "A hastily scribbled number for (a cab company / a lawyer / a priest / other).", pt: "Um telefone anotado às pressas de (uma empresa de táxi / um advogado / um padre / outro)." },
        { en: "A chess game in progress.", pt: "Uma partida de xadrez em andamento." },
        { en: "A hidden stash of comics with sweet notes between two people in the margins.", pt: "Um esconderijo de gibis com recadinhos carinhosos entre duas pessoas nas margens." }
      ].map(text => ({ text })),
      rewards: [
        { text: { en: "Elliott Rappaport becomes a recurring Side Character, found only at 18 Escondido (or at Rodenbecker if the house is destroyed). Only if he was befriended by answering his Question.", pt: "Elliott Rappaport vira um Side Character recorrente, encontrado só no número 18 da Escondido (ou na Rodenbecker se a casa for destruída). Só se ele virou amigo ao responderem a Pergunta dele." }, gear: "" },
        { text: { en: "Casey Wilcox becomes a recurring Side Character: +1 Clue on the Meddling Move when you consult him about Deep Lake's young people.", pt: "Casey Wilcox vira um Side Character recorrente: +1 Pista no Meddling Move quando você o consulta sobre os jovens de Deep Lake." }, gear: "" },
        { text: { en: "Bill Hanscom's personal cell number.", pt: "O celular pessoal de Bill Hanscom." }, gear: { en: "Bill Hanscom's cell number", pt: "Celular do Bill Hanscom" } },
        { text: { en: "A memento from the investigation — another Latchkey says what it is.", pt: "Uma lembrança da investigação — outro Latchkey diz o que é." }, gear: "?" },
        { text: { en: "A memento from the investigation — another Latchkey says what it is.", pt: "Uma lembrança da investigação — outro Latchkey diz o que é." }, gear: "?" },
        { text: { en: "A memento from the investigation — another Latchkey says what it is.", pt: "Uma lembrança da investigação — outro Latchkey diz o que é." }, gear: "?" }
      ],
      notes: ""
    }
  }
];

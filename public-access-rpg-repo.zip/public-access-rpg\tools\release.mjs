/**
 * Builds the release assets for a manual GitHub release:
 *   dist/system.json       (manifest with the download URL of this version)
 *   dist/public-access.zip (the installable system, files at the zip root)
 *
 * Usage:  npm run release            (uses the version in system.json)
 *         npm run release -- 1.4.0   (bumps system.json + package.json first)
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import archiver from "archiver";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const REPO = "https://github.com/fernandowrpg/public-access-rpg";
const ZIP_NAME = "public-access.zip";

/** What goes into the installable zip (runtime files only). */
const INCLUDE = ["system.json", "module", "templates", "styles", "lang", "packs", "README.md", "LICENSE", "CHANGELOG.md"];

const readJSON = f => JSON.parse(fs.readFileSync(path.join(root, f), "utf8"));
const writeJSON = (f, data) => fs.writeFileSync(path.join(root, f), JSON.stringify(data, null, 2) + "\n");

const manifest = readJSON("system.json");
const version = process.argv[2] ?? manifest.version;
if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Error(`Invalid version "${version}" (use x.y.z)`);

// Keep the repo manifest pointing at "latest"; the download URL is pinned to this version's tag.
Object.assign(manifest, {
  version,
  url: REPO,
  manifest: `${REPO}/releases/latest/download/system.json`,
  download: `${REPO}/releases/download/v${version}/${ZIP_NAME}`,
  bugs: `${REPO}/issues`,
  readme: `${REPO}/blob/main/README.md`,
  changelog: `${REPO}/blob/main/CHANGELOG.md`,
  license: `${REPO}/blob/main/LICENSE`
});
writeJSON("system.json", manifest);
const pkg = readJSON("package.json");
pkg.version = version;
writeJSON("package.json", pkg);

const dist = path.join(root, "dist");
fs.rmSync(dist, { recursive: true, force: true });
fs.mkdirSync(dist);
fs.copyFileSync(path.join(root, "system.json"), path.join(dist, "system.json"));

const missing = INCLUDE.filter(p => !fs.existsSync(path.join(root, p)));
if (missing.length) throw new Error(`Missing files: ${missing.join(", ")}`);

await new Promise((resolve, reject) => {
  const out = fs.createWriteStream(path.join(dist, ZIP_NAME));
  const zip = archiver("zip", { zlib: { level: 9 } });
  out.on("close", resolve);
  zip.on("error", reject);
  zip.pipe(out);
  for (const entry of INCLUDE) {
    const full = path.join(root, entry);
    if (fs.statSync(full).isDirectory()) {
      // LevelDB lock files must not ship.
      zip.glob("**/*", { cwd: full, ignore: ["**/LOCK"], dot: false }, { prefix: entry });
    } else zip.file(full, { name: entry });
  }
  zip.finalize();
});

const size = (fs.statSync(path.join(dist, ZIP_NAME)).size / 1024).toFixed(0);
console.log(`Release v${version} ready in dist/:
  system.json      manifest -> ${manifest.manifest}
  ${ZIP_NAME} (${size} KB) download -> ${manifest.download}

Next: commit & push, create the tag v${version} on GitHub and attach BOTH files from dist/ to the release.`);
